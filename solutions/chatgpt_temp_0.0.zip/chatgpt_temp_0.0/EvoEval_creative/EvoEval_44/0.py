def fairy_tale_transport(q, w, e):
    total_capacity = w + 2 * e
    total_weight = sum(q)
    return total_capacity >= total_weight