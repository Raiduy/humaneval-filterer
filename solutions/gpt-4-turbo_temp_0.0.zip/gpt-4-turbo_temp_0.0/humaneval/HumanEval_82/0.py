
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise."""
    return is_prime(len(string))
