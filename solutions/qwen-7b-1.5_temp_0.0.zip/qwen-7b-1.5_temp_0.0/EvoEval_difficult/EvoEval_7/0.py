from typing import List, Optional


def filter_by_substring(strings: List[str], substring: str, start: Optional[int]=None, end: Optional[int]=None) -> List[str]:
    """
    Filter an input list of strings only for ones that contain the given substring. If 'start' and 'end' are provided, consider the substring between these indices in each string for filtering.

    Parameters:
    - strings (List[str]): The list of strings to filter.
    - substring (str): The substring to look for in the strings.
    - start (Optional[int]): The starting index (inclusive) to consider in each string. Default is None, which means the beginning of the string.
    - end (Optional[int]): The ending index (exclusive) to consider in each string. Default is None, which means the end of the string.

    Returns:
    - List[str]: A filtered list of strings containing the given substring within the specified indices.

    Examples:
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a', 1)
    ['bacd', 'array']
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a', 1, 2)
    ['bacd']
    """
    filtered_strings = [s for s in strings if substring in s]
    if start is not None and end is not None:
        filtered_strings = [s[start:end] for s in filtered_strings if substring in s[start:end]]
    return filtered_strings