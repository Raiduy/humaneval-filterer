def numerical_letter_grade_with_weightage(grades):
    """The academic year is coming to an end and grades need to be assigned to the students. Due to the uniqueness of this year, the school has decided to use a weighted GPA system for grading. Each student's final grade is not only determined by the GPA but also a certain 'weightage' factor (second element in the tuple) which is unique for each student. This function calculates the weighted GPA and assigns a letter grade based on the provided table.

    Parameters:
    grades (list of tuples): A list of tuples containing the GPA and weightage factor for each student.

    Returns:
    list: A list of letter grades corresponding to the calculated weighted GPAs.

    Example:
    >>> numerical_letter_grade_with_weightage([(4.0, 0.8), (3, 1.2), (1.7, 0.9), (2, 1), (3.5, 1.1)])
    ['B+', 'A-', 'C-', 'C', 'A']
    """
    letter_grades = []
    for grade in grades:
        weighted_gpa = grade[0] * grade[1]
        if weighted_gpa >= 4.0:
            letter_grades.append('A+')
        elif weighted_gpa > 3.7:
            letter_grades.append('A')
        elif weighted_gpa > 3.3:
            letter_grades.append('A-')
        elif weighted_gpa > 3.0:
            letter_grades.append('B+')
        elif weighted_gpa > 2.7:
            letter_grades.append('B')
        elif weighted_gpa > 2.3:
            letter_grades.append('B-')
        elif weighted_gpa > 2.0:
            letter_grades.append('C+')
        elif weighted_gpa > 1.7:
            letter_grades.append('C')
        elif weighted_gpa > 1.3:
            letter_grades.append('C-')
        elif weighted_gpa > 1.0:
            letter_grades.append('D+')
        elif weighted_gpa > 0.7:
            letter_grades.append('D')
        else:
            letter_grades.append('D-')
    return letter_grades