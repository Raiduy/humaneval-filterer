from typing import List, Optional, Tuple


def longest_substring(strings: List[str]) -> Tuple[Optional[str], Optional[int]]:
    """Out of a list of strings, find the longest substring that starts with a vowel.
    Returns the string and its index in the original list.
    If no such substring exists, returns (None, None).

    Case-insensitive vowels are considered:
    - 'A' and 'a'
    - 'E' and 'e'
    - 'I' and 'i'
    - 'O' and 'o'
    - 'U' and 'u'

    Examples:
    >>> longest_substring([])
    (None, None)

    >>> longest_substring(['apple', 'banana', 'cherry'])
    ('apple', 0)

    >>> longest_substring(['grape', 'blueberry', 'strawberry'])
    ('ueberry', 1)
    """
    vowels = {'a', 'e', 'i', 'o', 'u'}
    if not strings:
        return (None, None)
    longest_substring_info = (None, -1)
    for (idx, string) in enumerate(strings):
        for i in range(len(string)):
            if string[i].lower() in vowels:
                substring = string[i:]
                substring_index = idx + i
                substring_length = len(substring)
                if substring_length > longest_substring_info[1] or (substring_length == longest_substring_info[1] and substring_index < longest_substring_info[0]):
                    longest_substring_info = (substring, substring_index)
    return longest_substring_info