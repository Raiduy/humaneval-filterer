def advanced_anti_shuffle(s, n):
    """
    A function that takes a string `s` and an integer `n`, and returns an ordered version of the string with a twist. It replaces each word by its characters rearranged in ascending ASCII order and then cyclically shifts the characters within the word by `n` positions (1 <= n <= 50). If a word has fewer than `n` characters, the shift wraps around to the start of the word. The order of words and blank spaces is preserved, and punctuation remains at the end of the word.

    Example:
    >>> advanced_anti_shuffle('Hi', 1)
    'iH'
    >>> advanced_anti_shuffle('hello', 2)
    'loehl'
    >>> advanced_anti_shuffle('Hello World!!!', 3)
    'lloHe lorWd!!!'

    Args:
        s (str): The input string.
        n (int): The number of positions to shift the characters within each word.

    Returns:
        str: The ordered and shifted string.
    """
    words = s.split() + ['']
    words = [word.strip('!?.') for word in words]
    shifted_words = []
    for word in words:
        shifted_word = ''.join(sorted(word))
        shift_amount = min(len(shifted_word), n)
        shifted_word = shifted_word[shift_amount:] + shifted_word[:shift_amount]
        shifted_words.append(shifted_word)
    return ' '.join(shifted_words)