def incr_list_conditionally(l: list, ignore: list) -> Union[list, str]:
    """Return a list where elements are incremented by 1 if they are not present in the 'ignore' list. Elements that are present in the 'ignore' list should be left unchanged. Raise an error if any element in the 'ignore' list is not an integer."""
    if any((not isinstance(i, int) for i in ignore)):
        return 'Ignore list should only contain integers'
    incremented_list = [i + 1 if i not in ignore else i for i in l]
    return incremented_list