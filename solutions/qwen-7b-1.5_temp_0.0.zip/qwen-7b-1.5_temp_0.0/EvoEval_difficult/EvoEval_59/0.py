def largest_prime_factor(n: int, m: int) -> int:
    """ Given an integer n and a prime number m, this function returns the largest prime factor of n when m is prime,
    and the smallest prime factor when m is not.

    Examples:
    >>> largest_prime_factor(13195, 3)
    29
    >>> largest_prime_factor(13195, 4)
    5
    >>> largest_prime_factor(2048, 7)
    2
    >>> largest_prime_factor(2048, 4)
    2
    """
    if is_prime(m):
        for i in range(n, 1, -1):
            if n % i == 0 and is_prime(i):
                return i
    else:
        for i in range(2, n + 1):
            if n % i == 0 and is_prime(i):
                return i
    return abs(n)