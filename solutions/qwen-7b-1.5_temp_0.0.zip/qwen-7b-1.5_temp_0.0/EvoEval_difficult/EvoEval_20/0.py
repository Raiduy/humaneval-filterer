from typing import List, Tuple

def find_subset_closest_elements(numbers: List[float], subset_size: int) -> Tuple[float, ...]:
    """
    Given a list of numbers and a subset size, this function selects a tuple of `subset_size` elements from the list,
    where the elements are closest to each other. The closeness is measured by the difference between the highest and lowest
    elements in the subset. The subset is returned in ascending order.

    If multiple subsets have the same minimum distance, the one with the smallest sum is chosen. In case of a tie for both
    the minimum distance and sum, the subset with the smallest first element is returned after sorting.

    Example usage:
    ```python
    >>> find_subset_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2], 2)
    (2.0, 2.2)
    >>> find_subset_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0, 2.5, 2.7], 3)
    (2.0, 2.0, 2.5)
    >>> find_subset_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 4.5, 4.6, 4.7], 4)
    (4.5, 4.6, 4.7, 5.0)
    ```
    """
    sorted_numbers = sorted(numbers)
    closest_subsets = []
    for i in range(subset_size, len(sorted_numbers)):
        subset = sorted_numbers[i - subset_size:i]
        min_distance = max(subset) - min(subset)
        subset_sum = sum(subset)
        closest_subsets.append((min_distance, subset, subset_sum))
    closest_subset = min(closest_subsets, key=lambda x: (x[0], x[1].sum(), x[1][0]))
    return tuple(closest_subset[1])