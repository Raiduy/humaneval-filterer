from typing import List, Tuple

def has_close_elements_in_range(numbers: List[Tuple[float, float]], threshold: float) -> bool:
    """Check if in a given list of pairs of numbers, any two consecutive pairs have a close difference between their elements.

    Args:
        numbers (List[Tuple[float, float]]): A list of tuples, where each tuple contains two floating-point numbers.
        threshold (float): The maximum allowed difference between the first elements and the second elements of consecutive pairs.

    Returns:
        bool: True if there are consecutive pairs with a difference less than the threshold, False otherwise.

    Examples:
        >>> has_close_elements_in_range([(1.0, 2.0), (2.0, 3.0), (3.0, 4.0)], 0.5)
        False
        >>> has_close_elements_in_range([(1.0, 2.8), (2.9, 3.0), (4.0, 5.0), (2.0, 2.1)], 0.3)
        False
    """
    numbers.sort(key=lambda pair: pair[0])
    for i in range(1, len(numbers)):
        diff_first = abs(numbers[i][0] - numbers[i - 1][0])
        diff_second = abs(numbers[i][1] - numbers[i - 1][1])
        if diff_first < threshold and diff_second < threshold:
            return True
    return False