def fib4_memo(n: int, m: int) -> str:
    if n < 0 or m > n:
        return 'Invalid input'
    memo = {0: 0, 1: 0, 2: 2, 3: 0}

    def fib4(n):
        if n not in memo:
            memo[n] = fib4(n - 1) + fib4(n - 2) + fib4(n - 3) + fib4(n - 4)
        return memo[n]
    fib_n = fib4(n)
    if m <= len(memo) - n:
        return fib_n - (len(memo) - n - m + 1)
    else:
        return 'Invalid input'