def fib(n: int, x: int, operation: str) -> int:
    """Return the n-th Fibonacci number, but modify every x-th Fibonacci number with an operation.

    Args:
        n (int): The index of the Fibonacci number to calculate.
        x (int): The index at which to apply the operation.
        operation (str): The type of operation to perform. Can be "square", "add_two", or "skip".

    Returns:
        int: The modified n-th Fibonacci number.

    Examples:
        >>> fib(10, 5, "square")
        46225
        >>> fib(12, 3, "skip")
        0
        >>> fib(15, 4, "add_two")
        946

    """
    fib_sequence = [0, 1]
    for _ in range(2, n + 1):
        fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
    modified_sequence = fib_sequence.copy()
    for (i, num) in enumerate(modified_sequence):
        if i % x == 0:
            if operation == 'square':
                modified_sequence[i] = num ** 2
            elif operation == 'add_two':
                modified_sequence[i] = num + 2