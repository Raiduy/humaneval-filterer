def is_happy_advanced(s, n):
    """
    Check if a given string `s` is n-happy or not. A string is n-happy if it meets the following conditions:
    - Length of the string is at least n.
    - Every n consecutive letters are distinct.
    - The string contains at least one alphanumeric character.

    Examples:
    ```python
    assert is_happy_advanced('a', 3) == False
    assert is_happy_advanced('aa', 2) == False
    assert is_happy_advanced('abcd123', 4) == True
    assert is_happy_advanced('aabb', 3) == False
    assert is_happy_advanced('adb123', 3) == True
    assert is_happy_advanced('xyy', 3) == False
    ```

    Args:
        s (str): The input string.
        n (int): The length of consecutive letters to check for distinctness.

    Returns:
        bool: True if the string is n-happy, False otherwise.
    """
    if len(s) < n:
        return False
    if not any((c.isalnum() for c in s)):
        return False
    for i in range(0, len(s), n):
        if len(set(s[i:i + n])) != n:
            return False
    return True