def get_row(lst, x, y):
    """
    This function takes a 3-dimensional nested list `lst`, an integer `x` to find, and another integer `y` as a depth condition. It returns a list of tuples representing the coordinates of `x` in the list, sorted according to the specified rules.

    Parameters:
    lst (list): The 3D nested list with varying row lengths and column depths.
    x (int): The integer to locate within the list.
    y (int): The depth at which to exclude coordinates.

    Returns:
    list: A list of tuples `(row, columns, depth)` where `(row, columns, depth)` is the location of `x`, excluding those with depth `y`.

    Examples:
    >>> get_row([
      [[1,2,3,4,5,6], [1,2,3,4,1,6], [1,2,3,4,5,1]],
      [[1,2,3,4,5,1], [1,2,3,4,1,6], [1,2,3,4,5,6]],
      [[1,2,3,4,5,6], [1,2,3,4,1,1], [1,2,3,4,5,1]]
    ], 1, 2)
    [(0, 2, 0), (0, 2, 5), (0, 1, 0), (0, 1, 4), (0, 0, 0), (1, 2, 0), (1, 1, 0), (1, 1, 4), (1, 0, 0), (1, 0, 5), (2, 2, 0), (2, 2, 5), (2, 1, 0), (2, 1, 4), (2, 1, 5), (2, 0, 0)]

    >>> get_row([], 1, 2)
    []

    >>> get_row([[[], [1], [1, 2, 3]], [[1,2,3,4,5,1], [], [1,2,3,4,5,6]], [[1,2,3,4,5,6], [1,2,3,4,1,1], [1,2,3,4,5,1]]], 3, 1)
    [(0, 2, 2), (1, 2, 2), (1, 0, 2), (2, 2, 2), (2, 1, 2), (2, 0, 2)]
    """
    result = []
    for (i, row) in enumerate(lst):
        for (j, col) in enumerate(row):
            if x in col:
                if col.index(x) != y:
                    result.append((i, j, col.index(x)))
    result.sort(key=lambda x: (x[0], -x[1], x[2]))
    return result