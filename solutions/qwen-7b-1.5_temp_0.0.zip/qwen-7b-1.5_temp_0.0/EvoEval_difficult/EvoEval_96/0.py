def prime_sequences(n, m):
    if n == 0 or m == 0:
        return []
    primes = [2]
    for num in range(3, n + 1, 2):
        is_prime = True
        for prime in primes:
            if prime * prime > num:
                break
            if num % prime == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(num)
    result = []
    for i in range(n):
        sub_sequence = primes[i:i + m]
        if sub_sequence:
            result.append(sub_sequence)
    return result