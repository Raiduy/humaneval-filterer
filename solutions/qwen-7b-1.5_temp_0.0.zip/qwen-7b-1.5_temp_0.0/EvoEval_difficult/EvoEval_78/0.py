def hex_key_primes(num):

    def is_hex_prime(digit):
        if digit == '2' or digit == '3' or digit == '5' or (digit == '7'):
            return True
        elif digit.upper() in ['B', 'D']:
            decimal_value = int(digit, 16)
            if decimal_value > 1 and all((decimal_value % i != 0 for i in range(2, decimal_value))):
                return True
        else:
            return False
    prime_count = 0
    prime_sum = 0
    digits = list(num)
    for digit in digits:
        if is_hex_prime(digit):
            prime_count += 1
            prime_sum += int(digit, 16)
    if prime_count > len(digits) // 2:
        result = (prime_count, 'Dominant', prime_sum)
    else:
        result = (prime_count, 'Non-dominant', prime_sum)
    return result