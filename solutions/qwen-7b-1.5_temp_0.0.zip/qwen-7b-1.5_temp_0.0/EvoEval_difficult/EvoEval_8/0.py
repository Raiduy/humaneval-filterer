from typing import List, Tuple


def sum_product_odd_even(numbers: List[int]) -> Tuple[int, int, int, int]:
    """
    Given a list of integers, this function calculates the sum and product of odd and even integers separately.
    
    Args:
        numbers (List[int]): A list of integers, where the absolute value determines oddness or evenness.

    Returns:
        Tuple[int, int, int, int]: A tuple containing the sum and product of:
            - Sum of all odd integers
            - Product of all odd integers
            - Sum of all even integers
            - Product of all even integers

    Examples:
        >>> sum_product_odd_even([])
        (0, 1, 0, 1)
        >>> sum_product_odd_even([-1, -2, 3, 4])
        (2, -3, 2, -8)

    """
    odd_sum = 0
    odd_product = 1
    even_sum = 0
    even_product = 1
    for num in numbers:
        if abs(num) % 2 == 1:
            odd_sum += num
            odd_product *= num
        else:
            even_sum += num
            even_product *= num
    return (odd_sum, odd_product, even_sum, even_product)