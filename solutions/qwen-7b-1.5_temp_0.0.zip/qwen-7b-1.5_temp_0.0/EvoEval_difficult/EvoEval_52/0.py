def below_above_threshold(l: list, t1: int, t2: int, s: str):
    """
    Given a list of integers `l`, a threshold `t1`, and a threshold `t2`, this function checks if the elements in the list satisfy the condition specified by the string `s`:

    - If `s` is 'below', it returns True if all numbers in `l` are less than `t1`.
    - If `s` is 'above', it returns True if all numbers in `l` are greater than `t2`.
    - If any number does not meet the condition, it returns the index of the first element that violates the condition. If no violation occurs, it returns -1.
    - If `s` is neither 'below' nor 'above', it also returns -1.

    The input list `l` should have a length between 1 and 1000, and its elements should be within the range of -1000 to 1000.

    Examples:
    >>> below_above_threshold([1, 2, 4, 10], 100, 0, 'below')
    True
    >>> below_above_threshold([1, 20, 4, 10], 5, 0, 'below')
    1
    >>> below_above_threshold([1, 20, 4, 10], 5, 0, 'above')
    True
    >>> below_above_threshold([10, 20, 30, 40], 5, 15, 'above')
    0

    """
    if s == 'below':
        if all((num < t1 for num in l)):
            return True
        else:
            for (i, num) in enumerate(l):
                if num >= t1:
                    return i
    elif s == 'above':
        if all((num > t2 for num in l)):
            return True
        else:
            for (i, num) in enumerate(l):
                if num <= t2:
                    return i
    else:
        return -1