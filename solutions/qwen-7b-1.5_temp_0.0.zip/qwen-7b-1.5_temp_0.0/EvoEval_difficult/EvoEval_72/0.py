def will_it_fly_advanced(q, w, r):
    """
    Determine if an object `q` can fly based on given conditions.
    
    Parameters:
    - q (list): The object to check, which should be a palindrome if balanced.
    - w (int): The maximum possible weight for the object.
    - r (list): A list of indices to potentially remove from `q`.

    Returns:
    - bool: True if `q` is balanced and within weight limit, False if unbalanced or uncertain, and None if uncertain due to removed elements.
    
    Examples:
    >>> will_it_fly_advanced([1, 2], 5, [])
    False
    >>> will_it_fly_advanced([3, 2, 3], 1, [])
    False
    >>> will_it_fly_advanced([3, 2, 3], 9, [])
    True
    >>> will_it_fly_advanced([3], 5, [])
    True
    >>> will_it_fly_advanced([3, 2, 3], 9, [0])
    None
    """
    if q != q[::-1]:
        return False
    total_sum = sum(q)
    if total_sum > w:
        return False
    if r:
        q = [q[i] for i in range(len(q)) if i not in r]
        if q != q[::-1]:
            return None
    else:
        pass
    return True