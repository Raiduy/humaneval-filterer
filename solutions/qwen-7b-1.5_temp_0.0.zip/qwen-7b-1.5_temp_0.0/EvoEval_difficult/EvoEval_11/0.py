from typing import List, Tuple

def string_xor_advanced(a: str, b: str, c: str, rotation: Tuple[int, int]) -> str:
    """ 
    Perform binary XOR on three input strings `a`, `b`, and `c` after left rotation. The strings consist only of 1s and 0s, with a length no more than 10^5 characters. The rotation tuple `(rotation_1, rotation_2)` specifies the number of times to rotate `a`, `b`, and `c` respectively.

    Args:
        a (str): First input string.
        b (str): Second input string.
        c (str): Third input string.
        rotation (Tuple[int, int]): A tuple containing the number of rotations for `a` and `b` (in that order).

    Returns:
        str: The result of the XOR operation on the rotated strings.

    Example:
        >>> string_xor_advanced('1010', '1101', '1001', (2, 1))
        '0010'
    """
    a_rotated = a[rotation[0]:] + a[:rotation[0]]
    b_rotated = b[rotation[1]:] + b[:rotation[1]]
    c_rotated = c[rotation[1]:] + c[:rotation[1]]
    xor_result_a_b = ''.join((str(int(a_rotated[i]) ^ int(b_rotated[i])) for i in range(len(a_rotated))))
    xor_result_c = xor_result_a_b ^ c_rotated
    return xor_result_c