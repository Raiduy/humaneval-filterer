def vowels_count(s, l=None):
    """
    A function to count the occurrences of vowels in a given word, considering case insensitivity and custom vowel rules.

    Parameters:
    s (str): The word for which to count vowels.
    l (list, optional): An optional list of custom vowels. If not provided, defaults to 'a', 'e', 'i', 'o', 'u', and 'y' (if at the end of the word).

    Returns:
    int: The number of vowel occurrences in the word.

    Examples:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    >>> vowels_count("ACEDY", ['A', 'E', 'D'])
    3
    >>> vowels_count("ACEDY", ['a', 'e', 'd'])
    3

    Note: 'y' is considered a vowel only if it appears at the end of the word, unless specified in the custom vowels list.
    """
    default_vowels = ['a', 'e', 'i', 'o', 'u']
    if l is not None:
        custom_vowels = [v.lower() for v in l]
    else:
        custom_vowels = default_vowels
    s = s.lower()
    vowel_count = sum((1 for char in s if char in custom_vowels or (char == 'y' and s[-1] == 'y')))
    return vowel_count