def is_multiply_prime(a, b):
    """
    Check if a number is the multiplication of exactly b prime numbers and return the list of those primes in increasing order.
    If it's impossible to obtain the number with the given primes, return an empty list.

    Args:
    a (int): The number to check if it can be formed by multiplying b prime numbers.
    b (int): The count of prime factors required.

    Returns:
    tuple: A tuple containing two values:
        - bool: Whether `a` can be expressed as the product of exactly `b` prime numbers.
        - list: The list of prime numbers used, in increasing order, if possible, or an empty list if not.

    Examples:
    >>> is_multiply_prime(30, 3)
    (True, [2, 3, 5])
    30 = 2 * 3 * 5

    >>> is_multiply_prime(100, 2)
    (False, [])
    """

    def is_prime(n):
        """Helper function to check if a number is prime."""
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    def find_factors(num, primes):
        """Find all prime factors of a number using the given primes."""
        factors = []
        for prime in primes:
            while num % prime == 0:
                factors.append(prime)
                num //= prime
        if num > 1:
            factors.append(num)
        return factors
    prime_factors = find_factors(a, [2, 3, 5])
    if len(prime_factors) == b:
        result_primes = sorted(prime_factors)
        return (True, result_primes)
    else:
        return (False, [])