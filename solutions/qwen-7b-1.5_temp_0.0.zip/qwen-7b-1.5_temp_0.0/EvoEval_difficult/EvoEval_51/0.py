def remove_vowels_and_count(text):
    """
    Remove vowels from a given string and return a tuple containing the modified string and a dictionary with vowel counts.

    Args:
        text (str): The input string to remove vowels from.

    Returns:
        tuple: A tuple with two elements:
            1. The string with vowels removed.
            2. A dictionary containing the count of each removed vowel. The keys are lowercase vowels only.

    Examples:
        >>> remove_vowels_and_count('')
        ('', {})
        >>> remove_vowels_and_count("abcdef
ghijklm")
        ('bcdf
ghjklm', {'a': 1, 'e': 1, 'i': 1})
        >>> remove_vowels_and_count('abcdef')
        ('bcdf', {'a': 1, 'e': 1})
        >>> remove_vowels_and_count('aaaaa')
        ('', {'a': 5})
        >>> remove_vowels_and_count('aaBAA')
        ('B', {'A': 2, 'a': 2})
        >>> remove_vowels_and_count('zbcd')
        ('zbcd', {})

    """
    vowels = {'a', 'e', 'i', 'o', 'u'}
    modified_text = ''
    vowel_counts = {}
    for char in text.lower():
        if char not in vowels:
            modified_text += char
    for vowel in vowels:
        if vowel in modified_text:
            vowel_counts[vowel] = modified_text.count(vowel)
    return (modified_text, vowel_counts)