def derivative(xs: list, x: float) -> float:
    """Calculates the derivative of a polynomial given its coefficients and a point.

    The polynomial is represented by the coefficients in the list `xs`, where `xs[0]` is the constant term and `xs[i] * x^i` represents the coefficient of `x^i`.
    
    Args:
        xs (list): Coefficients of the polynomial, starting from the constant term.
        x (float): The value at which to calculate the derivative.

    Returns:
        float: The derivative of the polynomial at the given point.

    Examples:
        >>> derivative([3, 1, 2, 4, 5], 2)
        217
        >>> derivative([1, 2, 3], -1)
        -4
        >>> derivative([4, -2, 0, 1], 0)
        -2
        >>> derivative([1, 1, 1, 1, 1], 10)
        4321
    """
    derivative_function = sum((i * x ** (len(xs) - 1 - i) for i in range(1, len(xs))))
    return derivative_function