def encode_complex(message, shift, key):
    """
    Encodes a message by swapping case, replacing vowels, and substituting consonants with key values.

    Parameters:
    message (str): The input message to be encoded.
    shift (int): A positive integer representing the shift for vowels.
    key (str): A string containing unique characters used as replacements for consonants.

    Returns:
    str: The encoded message with the specified transformations applied.
    
    Examples:
    >>> encode_complex('test', 2, 'abcdefghijklmnopqrstuvwxyz')
    'TGST'
    >>> encode_complex('This is a message', 4, 'zyxwvutsrqponmlkjihgfedcba')
    'gSMH MH E NIHHETI'
    """
    encoded_message = ''
    for char in message:
        if char.isalpha():
            if char.islower():
                encoded_char = char.upper()
            elif char.isupper():
                encoded_char = char.lower()
            if char in 'aeiou':
                new_position = (ord(char) - ord('a') + shift) % 26 + ord('a')
                encoded_char = chr(new_position)
            else:
                index = ord(char) - ord('a')
                encoded_char = key[index]
        encoded_message += encoded_char
    return encoded_message