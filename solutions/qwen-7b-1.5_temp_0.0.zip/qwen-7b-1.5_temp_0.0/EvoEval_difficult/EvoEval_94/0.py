def complexity_increased(lst, n):
    """
    This function takes a list of integers `lst` and an integer `n` as inputs. It aims to find all prime numbers in the list and calculate the sum of the nth power of their digits. If there are no prime numbers, it returns -1. If the prime number's digits are less than `n`, it considers only the nth power of the existing digits.

    First, we check if the list contains at least one positive integer. If not, we return -1.

    Steps:
    1. Filter out positive integers from the list.
    2. Iterate through the filtered list to find prime numbers.
    3. For each prime number, calculate the nth power of its digits and add it to the sum.
    4. Return the sum or -1 if no primes are found.

    Examples:
    ```python
    # Test cases
    assert complexity_increased([0, 3, 2, 1, 3, 5, 7, 4, 5, 5, 5, 2, 181, 32, 4, 32, 3, 2, 32, 324, 4, 3], 2) == 263
    assert complexity_increased([1, 0, 1, 8, 2, 4597, 2, 1, 3, 40, 1, 2, 1, 2, 4, 2, 5, 1], 3) == 1453
    assert complexity_increased([1, 3, 1, 32, 5107, 34, 83278, 109, 163, 23, 2323, 32, 30, 1, 9, 3], 4) == 11226
    assert complexity_increased([0, 724, 32, 71, 99, 32, 6, 0, 5, 91, 83, 0, 5, 6], 1) == 29
    assert complexity_increased([0, 81, 12, 3, 1, 21], 0) == 1
    assert complexity_increased([0, 8, 1, 2, 1, 7], 3) == 351
    ```

    :param lst: List of integers
    :param n: Integer for calculating the nth power of digits
    :return: Sum of nth power of prime numbers' digits or -1 if no primes are found
    """
    if not any((num > 0 for num in lst)):
        return -1
    primes = []
    for num in lst:
        if num > 1 and all((num % i != 0 for i in range(2, int(num ** 0.5) + 1))):
            primes.append(num)
    digit_sum = 0
    for prime in primes:
        if len(str(prime)) >= n:
            digit_power = sum((int(digit) ** n for digit in str(prime)))
            digit_sum += digit_power
    return digit_sum if primes else -1