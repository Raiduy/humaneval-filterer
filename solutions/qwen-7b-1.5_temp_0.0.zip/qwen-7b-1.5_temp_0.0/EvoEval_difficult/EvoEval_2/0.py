def truncate_number(number: float, digit_limit: int) -> str:
    """Given a positive floating point number, this function truncates the decimal part to the specified digit limit.

    It separates the number into its integer part (largest integer less than or equal to the given number) and the decimals (remaining portion always less than 1).
    
    If the decimal part has fewer digits than the digit_limit, zeros are appended to make the total length equal to the limit.

    Examples:
    >>> truncate_number(3.5, 2)
    '0.50'
    >>> truncate_number(4.12345, 3)
    '0.123'
    """
    number_str = str(number)
    decimal_index = number_str.index('.') + 1 if '.' in number_str else len(number_str)
    decimal_part = number_str[decimal_index:]
    truncated_decimal = decimal_part[:digit_limit] + '0' * (digit_limit - len(decimal_part)) if len(decimal_part) < digit_limit else decimal_part
    return truncated_decimal