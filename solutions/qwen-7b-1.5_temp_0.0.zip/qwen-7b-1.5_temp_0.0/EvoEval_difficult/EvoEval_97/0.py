def multiplyComplex(a, b):
    (a_real, a_imag) = map(int, a.replace('+', '').replace('-', '').split())
    (b_real, b_imag) = map(int, b.replace('+', '').replace('-', '').split())
    product_real = a_real * b_real - a_imag * b_imag
    product_imag = a_real * b_imag + a_imag * b_real
    result = {'real': product_real, 'imaginary': product_imag}
    return result