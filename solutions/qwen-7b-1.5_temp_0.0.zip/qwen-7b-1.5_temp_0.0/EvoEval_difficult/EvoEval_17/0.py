from typing import List, Tuple


def parse_music_advanced(music_string: str) -> Tuple[List[int], List[str]]:
    """
    Parse a musical notes and rests string into a tuple containing beat durations and note/rest types.

    Args:
        music_string (str): A string representing musical notes and rests in a special ASCII format.

    Returns:
        Tuple[List[int], List[str]]:
            - First list: A list of integers representing the duration of each note or rest in beats.
            - Second list: A list of strings indicating whether the item is a note ('note') or a rest ('rest').

    Legend:
    - 'o' - whole note, lasts 4 beats
    - 'o|' - half note, lasts 2 beats
    - '.|' - quarter note, lasts 1 beat
    - 'r' - whole rest, lasts 4 beats
    - 'r|' - half rest, lasts 2 beats
    - 'r.' - quarter rest, lasts 1 beat

    Invalid items are treated as resting for the same duration as the previous note/rest.

    Example:
    >>> parse_music_advanced('o o| .| o| o| .| .| .| .| o o r r| r. r| o o|')
    ([4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4, 4, 2, 1, 2, 4, 2], ['note', 'note', 'note', 'note', 'note', 'note', 'note', 'note', 'note', 'note', 'note', 'rest', 'rest', 'rest', 'rest', 'note', 'note'])
    """
    beat_durations = []
    note_rest_types = []
    current_duration = 0
    is_note = False
    for char in music_string:
        if char == 'o':
            current_duration = 4
        elif char == 'o|':
            current_duration = 2
        elif char == '.|':
            current_duration = 1
        elif char == 'r':
            current_duration = 4
        elif char == 'r|':
            current_duration = 2
        elif char == 'r.':
            current_duration = 1
        elif char != ' ':
            current_duration += current_duration if is_note else 4
            note_rest_types.append('rest' if is_note else 'note')
            is_note = not is_note
        beat_durations.append(current_duration)
    if is_note:
        beat_durations.append(current_duration)
        note_rest_types.append('note')
    return (beat_durations, note_rest_types)