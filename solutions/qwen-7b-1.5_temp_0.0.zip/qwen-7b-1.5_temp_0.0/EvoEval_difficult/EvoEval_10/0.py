def is_palindrome(string: str) -> bool:
    """ 
    Test if given string is a palindrome.
    """

    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ 
    Generate the shortest palindrome that begins with the input string and is case-insensitive.

    Algorithm idea:
    1. Find the longest postfix of the input string that is a palindrome.
    2. Append to the end of the string the reversed prefix before the palindromic suffix.
    3. Handle the special case where the string itself is a palindrome.

    Examples:
    >>> make_palindrome('')
    ''
    >>> make_palindrome('Cat')
    'CataC'
    >>> make_palindrome('cAta')
    'cAtac'
    """
    if is_palindrome(string):
        return string
    for i in range(len(string), 0, -1):
        if is_palindrome(string[i - 1:]):
            palindrome_suffix = string[i - 1:]
            break
    prefix = string[:i]
    return string + prefix[::-1]