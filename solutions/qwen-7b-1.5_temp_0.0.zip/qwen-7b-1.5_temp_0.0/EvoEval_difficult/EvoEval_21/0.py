from typing import List, Optional

def rescale_to_unit(numbers: List[Optional[float]]) -> List[Optional[float]]:
    """ Given a list of numbers (at least two elements), this function applies a linear transformation to the list such that the smallest number becomes 0 and the largest becomes 1. It handles None values by ignoring them and preserving their positions in the list. The result is rounded to two decimal places.

    Example:
    >>> rescale_to_unit([1.0, 2.0, 3.0, None, 4.0, 5.0])
    [0.0, 0.25, 0.5, None, 0.75, 1.0]

    Args:
    - numbers: A list of optional floats, where None values are allowed.

    Returns:
    - A new list with the rescaled numbers, rounded to two decimal places.
    """
    numbers = [num for num in numbers if num is not None]
    numbers.sort()
    max_value = max(numbers)
    min_value = min(numbers)
    scaled_range = (max_value - min_value) / (1 - 0)
    rescaled_numbers = [round(num * scaled_range, 2) if num is not None else None for num in numbers]
    return rescaled_numbers