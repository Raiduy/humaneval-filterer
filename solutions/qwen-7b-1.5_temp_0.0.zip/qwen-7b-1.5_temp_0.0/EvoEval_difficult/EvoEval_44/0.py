def change_base(x: str, base: int, new_base: int) -> str:
    """Change numerical base of input number x from base to new_base.

    Parameters:
    - x (str): A positive string representation of an integer in the specified base.
    - base (int): The base of the input number, between 2 and 36.
    - new_base (int): The new base to convert the number to, between 2 and 36.

    Returns:
    String representation of the input number converted to the new base, using uppercase letters for digits above 9.
    Raises:
    - ValueError: If the input base or new base is not between 2 and 36.

    Examples:
    >>> change_base('8', 10, 3)
    '22'
    >>> change_base('8', 10, 2)
    '1000'
    >>> change_base('7', 10, 2)
    '111'
    >>> change_base('1A', 16, 10)
    '26'
    >>> change_base('Z', 36, 16)
    '23'

    """
    if not 2 <= base <= 36 or not 2 <= new_base <= 36:
        raise ValueError('Invalid base')
    decimal_number = int(x, base)
    new_string = ''
    while decimal_number > 0:
        remainder = decimal_number % new_base
        if remainder > 9:
            new_string = chr(65 + remainder - 10) + new_string
        else:
            new_string = str(remainder) + new_string
        decimal_number //= new_base
    return new_string.upper()