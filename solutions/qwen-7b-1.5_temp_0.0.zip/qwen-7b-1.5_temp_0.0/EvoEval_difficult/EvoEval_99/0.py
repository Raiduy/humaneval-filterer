def closest_integer(value, base):
    """
    Create a function that finds the closest integer to a given number in a specified base number system. It rounds away from zero if the number is equidistant from two integers.

    If the number is fractional, it converts it to decimal, rounds, and then converts back to the base provided.

    Examples:
    >>> closest_integer("10", 2)
    "10"
    >>> closest_integer("15.3", 10)
    "15"
    >>> closest_integer("1011.11", 2)
    "1100"

    Note:
    Rounding towards the nearest integer with a tie broken by being away from zero:
    - closest_integer("14.5", 10) returns "15"
    - closest_integer("-14.5", 10) returns "-15"

    Function handles bases from 2 to 16 inclusively. Returns the closest integer as a string in the original number system without using built-in base conversion functions.
    """
    if base < 2 or base > 16:
        raise ValueError('Base must be between 2 and 16 inclusive.')
    decimal_value = float(value)
    rounded_decimal = round(decimal_value)
    closest_integer_str = ''
    while rounded_decimal > 0:
        remainder = rounded_decimal % base
        closest_integer_str = str(remainder) + closest_integer_str
        rounded_decimal //= base
    return closest_integer_str