def car_race_collision(n: int, speeds: list):
    """
    Imagine a road with infinite straight lanes for a car race. There are two sets of `n` cars, one moving left to right and the other moving right to left, each with distinct speeds provided in the `speeds` list. A collision occurs when:
    
    1. A car moving left to right hits a car moving right to left.
    2. A car moving left to right hits a stationary (zero-speed) car.

    The function returns the total number of collisions.

    Parameters:
    - n (int): Number of cars in each set.
    - speeds (list): List of speeds for the left-to-right and right-to-left cars, in the same order.

    Returns:
    - int: The number of collisions.
    """
    collisions = 0
    for i in range(n):
        for j in range(n):
            if speeds[i] == speeds[j]:
                collisions += 1
            elif speeds[i] == 0:
                collisions += 1
    return collisions