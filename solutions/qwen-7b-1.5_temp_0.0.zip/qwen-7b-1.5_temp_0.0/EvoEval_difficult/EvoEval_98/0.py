def count_spec_chars(s, m, n):
    """
    Given a string `s`, this function counts the number of uppercase vowels in even indices and lowercase consonants in odd indices. It ignores non-alphabetic characters. The output is a tuple with the sum of ASCII values of the vowels and consonants, respectively.

    Parameters:
    s (str): The input string.
    m (int): The minimum required length of the string (inclusive).
    n (int): The maximum required length of the string (inclusive).

    Returns:
    tuple: A tuple containing two elements:
        - The sum of ASCII values of uppercase vowels in even indices.
        - The sum of ASCII values of lowercase consonants in odd indices. If the length of the string is outside the specified range, it returns -1.

    Examples:
    >>> count_spec_chars('aB.CdEf', 2, 10)
    (0, 0)
    >>> count_spec_chars('abcde!fg', 3, 8)
    (0, 301)
    >>> count_spec_chars('dBB.E', 1, 4)
    -1
    >>> count_spec_chars('a123@#$', 2, 10)
    (0, 0)

    """
    vowel_sum = 0
    consonant_sum = 0
    if len(s) < m or len(s) > n:
        return -1
    for i in range(len(s)):
        if not s[i].isalpha():
            continue
        if i % 2 == 0:
            if s[i].isupper():
                vowel_sum += ord(s[i])
        elif s[i] not in ['a', 'e']:
            consonant_sum += ord(s[i])
    return (vowel_sum, consonant_sum)