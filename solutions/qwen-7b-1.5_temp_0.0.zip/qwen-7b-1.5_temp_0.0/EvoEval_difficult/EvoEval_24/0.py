def largest_prime_divisor(n: int, k: int) -> int:

    def is_prime(num: int) -> bool:
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True
    divisors = [i for i in range(2, n) if n % i == 0]
    prime_divisors = [d for d in divisors if is_prime(d)]
    if k > len(prime_divisors):
        return -1
    else:
        sorted_prime_divisors = sorted(prime_divisors, reverse=True)
        return sorted_prime_divisors[k - 1]