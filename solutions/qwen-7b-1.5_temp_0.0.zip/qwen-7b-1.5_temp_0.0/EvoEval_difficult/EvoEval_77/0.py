def iscube(a, b):
    """
    Check if 'a' is a cube of some integer and 'b' is a perfect square of some integer,
    while ensuring the sum of 'a' and 'b' is even. The function returns True for valid inputs and False otherwise.

    Parameters:
    a (int): An integer to check if it's a cube.
    b (int): An integer to check if it's a perfect square.

    Returns:
    bool: True if all conditions are met, False otherwise.
    
    Examples:
    >>> iscube(8, 16)
    True
    >>> iscube(1, 2)
    False
    >>> iscube(-8, -16)
    False
    >>> iscube(0, 64)
    False
    >>> iscube(180, 16)
    False
    """
    if a < 0 or b < 0:
        return False
    if int(a ** (1 / 3)) ** 3 != a:
        return False
    if int(b ** 0.5) ** 2 != b:
        return False
    if (a + b) % 2 != 0:
        return False
    return True