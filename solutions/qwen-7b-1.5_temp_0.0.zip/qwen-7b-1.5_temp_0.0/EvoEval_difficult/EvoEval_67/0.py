def advanced_fruit_distribution(s, n, m):
    """
    Given a string describing a fruit distribution in a basket, determine the number of mangoes in the basket while meeting the following conditions:
    - The total number of fruits (apples and oranges combined) is `n`.
    - The minimum requirement for mangoes is `m`.
    - If it's not possible to have at least `m` mangoes with `n` fruits and the given apple and orange counts, return `-1`.

    Examples:
    - advanced_fruit_distribution("5 apples and 6 oranges", 19, 10) -> -1
    - advanced_fruit_distribution("0 apples and 1 oranges", 3, 1) -> 2
    - advanced_fruit_distribution("2 apples and 3 oranges", 100, 50) -> 95
    - advanced_fruit_distribution("100 apples and 1 oranges", 120, 15) -> 19

    Args:
        s (str): A string representing the distribution of fruits, with format "X apples and Y oranges".
        n (int): The total number of fruits in the basket.
        m (int): The minimum requirement for mangoes.

    Returns:
        int: The number of mangoes in the basket if possible, `-1` otherwise.
    """
    (apples, oranges) = map(int, s.split()[:-1])
    remaining_fruits = n - apples - oranges
    if remaining_fruits < m:
        return -1
    else:
        return remaining_fruits