def sort_array(array, pivot):
    """
    Given an array of non-negative integers and a pivot index, return a copy of the array after sorting.
    First, rearranges the array so that elements less than the pivot come before it and elements greater than the pivot come after. 
    Then, sorts the part before the pivot based on the sum of the first index value and the pivot being odd or even.
    The part after the pivot is sorted in the opposite order of the first part (default to ascending).

    Note:
    - Does not modify the original array.
    - Pivot index is always valid.

    Examples:
    - sort_array([], 0) => []
    - sort_array([5], 0) => [5]
    - sort_array([2, 4, 3, 0, 1, 5], 2) => [0, 1, 2, 3, 5, 4]
    - sort_array([2, 4, 3, 0, 1, 5, 6], 3) => [0, 1, 2, 3, 4, 5, 6]

    Args:
    array (List[int]): The input array of non-negative integers.
    pivot (int): The index of the pivot element.

    Returns:
    List[int]: A sorted copy of the input array.
    """
    sorted_array = array.copy()
    pivot_value = sorted_array.pop(pivot)
    less_than_pivot = [num for num in sorted_array if num < pivot_value]
    equal_to_pivot = [num for num in sorted_array if num == pivot_value]
    greater_than_pivot = [num for num in sorted_array if num > pivot_value]
    if sum(array[0:1]) % 2 == 1:
        less_than_pivot.sort(reverse=True)
    else:
        less_than_pivot.sort()
    sorted_array[:pivot] = less_than_pivot + equal_to_pivot
    sorted_array[pivot + 1:] = greater_than_pivot
    return sorted_array