def is_palindrome_sentence(sentence: str) -> bool:
    """
    Checks if the given sentence is a palindrome, considering only alphanumeric characters and ignoring punctuation and whitespace.

    Args:
        sentence (str): The input sentence to be checked.

    Returns:
        bool: `True` if the sentence is a palindrome, otherwise `False`.
    
    Examples:
        >>> is_palindrome_sentence('')
        True
        >>> is_palindrome_sentence('Able , was I saw Elba')
        True
        >>> is_palindrome_sentence('A man, a plan, a canal, Panama')
        True
        >>> is_palindrome_sentence('This is not a palindrome')
        False
    """
    sentence = ''.join((c.lower() for c in sentence if c.isalnum()))
    return sentence == sentence[::-1]