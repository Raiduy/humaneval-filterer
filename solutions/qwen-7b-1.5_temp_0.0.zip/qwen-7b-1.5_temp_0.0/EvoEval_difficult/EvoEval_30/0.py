def get_positive_and_index(l: list) -> list:
    """Return only positive numbers and their index within the list, if the index is also a prime number."""
    positive_numbers = [(i, num) for (i, num) in enumerate(l) if num > 0]
    result = []
    for (index, num) in positive_numbers:
        if is_prime(index):
            result.append((num, index))
    return result