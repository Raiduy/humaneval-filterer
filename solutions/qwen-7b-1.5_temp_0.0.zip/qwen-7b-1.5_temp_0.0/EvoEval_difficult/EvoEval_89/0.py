def advanced_encrypt(s, n):
    """Create a function advanced_encrypt that encrypts a string using a shifted alphabet.

    Args:
        s (str): The input string to be encrypted.
        n (int): The number of positions to shift the alphabet. If n is even, shift to the right, and if n is odd, shift to the left.

    Returns:
        str: The encrypted string, maintaining case and ignoring non-alphabetic characters.

    Examples:
        >>> advanced_encrypt('hi', 2)
        'lm'
        >>> advanced_encrypt('asdfghjkl', 3)
        'gyjlmnpqr'
        >>> advanced_encrypt('GF', 1)
        'IH'
        >>> advanced_encrypt('eT!', 2)
        'iX!'
        >>> advanced_encrypt('2ab&', 3)
        '2gh&'

    Note: The function can handle large positive values of 'n'.
    """
    encrypted = ''
    for char in s:
        if char.isalpha():
            shift = n % 26
            if char.islower():
                encrypted += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            elif char.isupper():
                encrypted += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        else:
            encrypted += char
    return encrypted