import math
from typing import Tuple


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n.
    The coefficients xs are integers and -10^6 <= xs[i] <= 10^6 where 0 <= i <= n.
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zeros_interval(xs: list, interval: Tuple[float, float]) -> float:
    """
    Given a polynomial with coefficients `xs`, find one x within the interval (inclusive) where the polynomial equals zero.
    If the polynomial has opposite signs at the interval endpoints, returns a zero point rounded to two decimal places.
    Otherwise, returns None.

    Args:
        xs (list): List of coefficients for the polynomial.
        interval (Tuple[float, float]): A tuple representing the interval (start, end) with -10^6 <= start < end <= 10^6.

    Returns:
        float: The zero point (rounded to two decimal places) if found, otherwise None.
    """
    poly_start = poly(xs, interval[0])
    poly_end = poly(xs, interval[1])
    if poly_start * poly_end < 0:
        zero_point = (interval[1] - interval[0]) / (poly_end - poly_start)
        return round(zero_point, 2)
    else:
        return None