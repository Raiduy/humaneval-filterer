def starts_one_ends(n, x, y):
    """
    Given three positive integers n, x, and y, this function calculates the count of n-digit positive integers that either start with digit x or end with digit y. It checks for inputs where n is up to 5. If there's no valid n-digit number meeting the criteria, or if x or y is not a digit, it returns -1.

    Parameters:
    n (int): A positive integer representing the number of digits in the integers.
    x (int): A positive integer representing the starting digit.
    y (int): A positive integer representing the ending digit.

    Returns:
    int: The count of valid n-digit integers or -1 if the input is invalid.
    """
    if n < 1 or n > 5:
        return -1
    if not str(x).isdigit() or not str(y).isdigit():
        return -1
    count = 0
    for num in range(10 ** (n - 1), 10 ** n):
        if str(num)[0] == str(x) or str(num)[-1] == str(y):
            count += 1
    return count