from typing import List, Tuple

def all_prefix_suffix_pairs(string: str, min_length: int) -> List[Tuple[str, str]]:
    """Return a list of all prefix-suffix pairs from the input string that meet the specified criteria.

    Criteria:
    - Prefix and suffix do not overlap in any characters.
    - Each prefix and suffix must be at least 'min_length' characters long.
    - Pairs are sorted first by length in increasing order, then lexicographically if lengths are equal.

    Example usage:
    >>> all_prefix_suffix_pairs('abcadg', 2)
    [('ab', 'dg'), ('abc', 'dg'), ('abca', 'dg')]

    :param string: The input string from which to extract the pairs.
    :param min_length: The minimum length for both prefix and suffix.
    :return: A list of tuples, where each tuple contains a prefix and its corresponding suffix.
    """
    pairs = []
    for i in range(len(string) - min_length + 1):
        prefix = string[i:i + min_length]
        suffix = string[-(i + min_length):]
        if len(prefix) >= min_length and len(suffix) >= min_length and (prefix != suffix):
            pairs.append((prefix, suffix))
    pairs.sort(key=lambda x: (len(x[0]), x[0]))
    return pairs