def decimal_to_binary(decimal, padding_length):
    """Convert a decimal number to binary format with padding and extra characters.

    Parameters:
    decimal (int): Positive integer to convert to binary.
    padding_length (int): Positive integer specifying the desired length of the binary string including padding.

    Returns:
    str: "db" followed by the binary representation of the decimal number padded with zeros, if valid. An error message is returned for invalid inputs or when the padding length is too small.

    Examples:
    >>> decimal_to_binary(15, 5)
    "db01111db"
    >>> decimal_to_binary(32, 5)
    "Padding length is too small"
    >>> decimal_to_binary(32, 10)
    "db0000100000db"

    Raises:
    ValueError: If the input decimal number is not a positive integer or the padding length is not a positive integer.
    """
    if not isinstance(decimal, int) or decimal < 0:
        return 'Invalid Input'
    if not isinstance(padding_length, int) or padding_length < 0:
        return 'Invalid Input'
    binary = bin(decimal)[2:]
    while len(binary) < padding_length:
        binary = '0' + binary
    binary = 'db' + binary + 'db'
    if len(binary) <= padding_length:
        return binary
    else:
        return 'Padding length is too small'