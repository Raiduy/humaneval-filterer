def pluck_and_replace(arr, replacement):
    """
    Given an array that has non-negative integer nodes,
    this function plucks one of the nodes with the smallest even value (excluding the replacement),
    replaces it with the given replacement value, and returns it in a list format.

    Parameters:
    arr (list): A non-empty list of non-negative integers
    replacement (int): The value to replace the plucked node with

    Returns:
    list: A list containing the smallest even value, its initial index, replacement value, and new index,
           or [] if there are no even values, the array is empty, or the replacement value is already in the array.
    Example:

    - Input: [4, 2, 3], 5
    Output: [2, 1, 5, 1]

    - Input: [1, 2, 3], 4
    Output: [2, 1, 4, 1]

    - Input: [], 6
    Output: []

    - Input: [5, 0, 3, 0, 4, 2], 0
    Output: [-1, -1, 0, -1]
    """
    if not arr or all((num % 2 != 0 for num in arr)):
        return []
    smallest_even = None
    smallest_index = -1
    for (i, num) in enumerate(arr):
        if num % 2 == 0 and (smallest_even is None or num < smallest_even):
            smallest_even = num
            smallest_index = i
    if smallest_even is None:
        return [-1, -1, replacement, -1]
    new_arr = arr[:smallest_index] + [replacement] + arr[smallest_index + 1:]
    new_index = arr.index(replacement)
    return [smallest_even, smallest_index, replacement, new_index]