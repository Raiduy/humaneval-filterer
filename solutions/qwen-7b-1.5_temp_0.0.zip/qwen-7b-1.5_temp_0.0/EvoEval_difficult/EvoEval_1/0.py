from typing import List, Tuple

def separate_paren_groups(paren_string: str, remove_unbalanced: bool=False) -> Tuple[List[str], int]:
    """ 
    Separates groups of nested parentheses from a given string, ensuring they are balanced and not nested. Returns a tuple containing the list of separated groups and the count of removed unbalanced groups.

    Args:
        paren_string (str): The input string containing nested parentheses and spaces.
        remove_unbalanced (bool, optional): If True, removes unbalanced groups. Defaults to False.

    Returns:
        Tuple[List[str], int]: A tuple with two elements:
            1. A list of separate groups of balanced parentheses.
            2. An integer representing the count of removed unbalanced groups (if `remove_unbalanced` is True, otherwise 0).

    Examples:
        >>> separate_paren_groups('() (()) (()())', True)
        (['()', '(())', '(()())'], 0)
        >>> separate_paren_groups('() (()) (()()) )', True)
        (['()', '(())', '(()())'], 1)
    """
    paren_string = ''.join(paren_string.split())
    stack = []
    count = 0
    result = []
    for char in paren_string:
        if char in ['(', ')']:
            if stack and stack[-1] == char:
                stack.pop()
            else:
                stack.append(char)
        elif stack:
            result.append(''.join(stack))
            stack.clear()
    if remove_unbalanced and stack:
        count += 1
    return (result, count)