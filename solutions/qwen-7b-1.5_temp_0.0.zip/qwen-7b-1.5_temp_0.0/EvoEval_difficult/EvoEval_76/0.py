def complex_power(x, n, m):
    """Check if a number x is a complex power of n and m
    
    Args:
        x (complex): The number to test as a power
        n (int): The base number
        m (int): The exponent

    Returns:
        bool: True if x is a complex power of n and m (with the same integer exponent), False otherwise. Also returns False if n or m is 1.
    
    Examples:
        >>> complex_power(16, 2, 2)
        True
        >>> complex_power(3, 1, 2)
        False
        >>> complex_power(8, 2, 2)
        False
        >>> complex_power(3, 2, 2)
        False
        >>> complex_power(9, 3, 2)
        True
        >>> complex_power(27, 3, 3)
        True
        >>> complex_power(125, 5, 3)
        True
    """
    if n == 1 or m == 1:
        return False
    if int(n) ** int(m) != x:
        return False
    return True