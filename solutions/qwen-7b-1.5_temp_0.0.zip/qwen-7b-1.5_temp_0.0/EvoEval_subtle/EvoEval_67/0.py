def fruit_distribution(s, n):
    """
    This function takes a string representing the number of apples and oranges in a basket,
    along with an integer representing the total number of fruits in the basket (minus one).
    It calculates and returns the number of mango fruits in the basket.

    Parameters:
    s (str): A string in the format "X apples, Y oranges" where X and Y are integers.
    n (int): The total number of fruits in the basket (excluding mangoes).

    Returns:
    int: The number of mango fruits in the basket.

    Examples:
    >>> fruit_distribution("5 apples, 6 oranges", 19)
    9
    >>> fruit_distribution("0 apples, 1 oranges", 3)
    3
    >>> fruit_distribution("2 apples, 3 oranges", 100)
    96
    >>> fruit_distribution("100 apples, 1 oranges", 120)
    20
    """
    (apples, oranges) = map(int, s.split(', ')[0].split(' '))
    total_oranges_apples = apples + oranges
    mango_count = n - total_oranges_apples - 1
    return mango_count