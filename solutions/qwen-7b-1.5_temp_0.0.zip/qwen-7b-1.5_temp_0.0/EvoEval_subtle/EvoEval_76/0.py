
def is_simple_power(x, n):
    """
    Check if a number `x` is a simple power of `n` and return the result along with the smallest power if it's a simple power.

    Args:
        x (int): The number to be checked.
        n (int): The base for the power.

    Returns:
        tuple: A tuple containing:
            - bool: Whether `x` is a simple power of `n`.
            - int or None: The smallest power (if exists) that makes `x` a simple power of `n`. If not a simple power, returns `None`.
    """
    if n == 1:
        return (False, None)
    power = 0
    while x % n == 0:
        x //= n
        power += 1
    if x == 1:
        return (True, power)
    else:
        return (False, None)