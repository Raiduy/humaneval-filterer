
def will_it_fly(q, w):
    """
    Determine if an object `q` will fly based on given conditions.
    A list `q` is considered balanced if it's a palindrome, the sum of its elements is even, and the sum is less than or equal to the maximum weight `w`.

    Examples:
    >>> will_it_fly([1, 2], 5)
    False
    # The sum is 3, which is odd and exceeds the maximum weight.

    >>> will_it_fly([3, 2, 3], 1)
    False
    # Balanced, but the sum 6 is greater than the maximum weight.

    >>> will_it_fly([3, 2, 3], 9)
    True
    # Balanced and the sum 6 is within the maximum weight.

    >>> will_it_fly([3], 5)
    False
    # Balanced with a sum of 3, which is odd.

    """
    if q == q[::-1] and sum(q) % 2 == 0 and (sum(q) <= w):
        return True
    else:
        return False