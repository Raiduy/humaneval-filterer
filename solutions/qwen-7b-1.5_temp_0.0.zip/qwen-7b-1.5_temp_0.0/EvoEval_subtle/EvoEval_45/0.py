

def triangle_perimeter(a, b, c):
    """Given length of three sides, calculate and return the perimeter for a triangle.
    
    Example usage:
    >>> triangle_perimeter(5, 3, 3)
    11
    """
    perimeter = a + b + c
    return perimeter