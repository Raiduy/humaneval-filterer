from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings `a` and `b` consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return the result as a string with its bits reversed.

    Example:
    >>> string_xor('010', '110')
    '001'
    """
    xor_result = ''.join((str(int(a[i]) ^ int(b[i])) for i in range(len(a))))
    reversed_xor = xor_result[::-1]
    return reversed_xor