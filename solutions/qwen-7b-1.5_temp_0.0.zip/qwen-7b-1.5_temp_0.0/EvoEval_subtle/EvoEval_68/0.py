
def pluck(arr):
    """
    Given an array representing a branch of a tree with non-negative integer nodes,
    this function plucks one of the nodes with the smallest odd value and returns it in a list `[index, smallest_value]`.

    If multiple nodes have the same smallest odd value, it will return the one with the smallest index.

    If there are no odd values or the array is empty, it returns an empty list `[]`.

    Examples:
    - Input: [4, 3, 5]
    - Output: [1, 3]
    - Explanation: Node 3 with value 3 is the smallest odd node and has the smallest index.

    - Input: [1, 2, 3]
    - Output: [0, 1]
    - Explanation: Node 1 with value 1 is the smallest odd node and has the smallest index.

    - Input: []
    - Output: []
    - Explanation: An empty array indicates no odd values to pluck.

    - Input: [5, 1, 3, 0, 4, 2]
    - Output: [1, 1]
    - Explanation: Both nodes with value 1 are the smallest odd ones, but the first one has the smallest index.

    Constraints:
    - 1 <= nodes.length <= 10000
    - 0 <= node.value
    """
    odd_nodes = [(i, val) for (i, val) in enumerate(arr) if val % 2 != 0]
    if not odd_nodes:
        return []
    smallest_odd = min(odd_nodes, key=lambda x: (x[1], x[0]))
    return [smallest_odd[0], smallest_odd[1]]