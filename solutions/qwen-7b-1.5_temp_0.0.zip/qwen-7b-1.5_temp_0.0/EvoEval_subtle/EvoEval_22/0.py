
from typing import List, Any


def filter_even_integers(values: List[Any]) -> List[int]:
    """Filter given list of any python values only for even integers.

    Example usage:
    >>> filter_even_integers(['a', 3.14, 5, 6])
    [6]
    >>> filter_even_integers([1, 2, 3, 'abc', {}, []])
    [2]

    Args:
        values: A list of any Python values, including integers, floats, strings, and more.

    Returns:
        A new list containing only the even integers from the input.
    """
    return [i for i in values if isinstance(i, int) and i % 2 == 0]