
def prime_fib(n: int):
    """
    **prime_fib** function calculates the n-th number that is both a Fibonacci number and a prime number. If the number is even, it returns None.

    Example:
    >>> prime_fib(1)
    None
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89

    Args:
        n (int): The position of the desired Fibonacci-prime number in the sequence.

    Returns:
        int or None: The n-th Fibonacci-prime number if found, otherwise None for even numbers.
    """

    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True

    def fibonacci_sequence(n):
        fib_sequence = [0, 1]
        while len(fib_sequence) < n:
            fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
        return fib_sequence
    fib_sequence = fibonacci_sequence(n)
    for num in fib_sequence:
        if num > 1 and is_prime(num) and (num % 2 != 0):
            return num
    return None