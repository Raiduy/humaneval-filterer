from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Separate groups of balanced parentheses from a given string into separate strings and return them in ascending alphabetical order.

    Args:
        paren_string (str): A string containing nested parentheses, with spaces ignored.

    Returns:
        List[str]: A list of separate strings representing the balanced groups, in ascending alphabetical order.

    Example:
        >>> separate_paren_groups('( ) (( )) (( )( ))')
        ['(()())', '(())', '()']
    """
    paren_string = paren_string.replace(' ', '')
    groups = []
    stack = []
    for char in paren_string:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack:
                return []
            else:
                last_open_brace = stack.pop()
                if last_open_brace != '(':
                    return []
                else:
                    groups.append(''.join(stack) + char)
    if stack:
        return []
    groups.sort()
    return groups