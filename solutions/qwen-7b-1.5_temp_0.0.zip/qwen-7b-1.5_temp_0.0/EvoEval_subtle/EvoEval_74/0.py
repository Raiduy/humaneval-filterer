
def total_match(lst1, lst2):
    """
    A function that compares two lists of strings based on the total number of characters in their strings. It returns the list with more characters or, if they have the same count, the second list.

    Parameters:
    lst1 (list of str): The first list of strings.
    lst2 (list of str): The second list of strings.

    Returns:
    list: The list with the greater total number of characters or lst2 if they have the same count.

    Examples:
    >>> total_match([], [])
    []
    >>> total_match(['hi', 'admin'], ['hI', 'Hi'])
    ['hi', 'admin']
    >>> total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project'])
    ['hi', 'hi', 'admin', 'project']
    >>> total_match(['hi', 'admin'], ['hI', 'hi', 'hi'])
    ['hi', 'admin']
    >>> total_match(['4'], ['1', '2', '3', '4', '5'])
    ['1', '2', '3', '4', '5']
    """
    total_chars_lst1 = sum((len(s) for s in lst1))
    total_chars_lst2 = sum((len(s) for s in lst2))
    if total_chars_lst1 > total_chars_lst2:
        return lst1
    elif total_chars_lst1 < total_chars_lst2:
        return lst2
    else:
        return lst2