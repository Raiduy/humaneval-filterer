
def is_bored(S):
    """
    This function takes a string `S` as input and counts the number of boredoms in it. A boredom is defined as a sentence that starts with the word "I" and ends with the word "boredom". Sentences are separated by periods (.), question marks (?), or exclamation marks (!).

    Example usage:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I am experiencing boredom")
    1

    Args:
        S (str): The input string containing sentences.

    Returns:
        int: The count of boredoms in the input string.
    """
    boredom_count = 0
    sentences = S.split('.!?')
    for sentence in sentences:
        if sentence.startswith('I') and sentence.endswith('boredom'):
            boredom_count += 1
    return boredom_count