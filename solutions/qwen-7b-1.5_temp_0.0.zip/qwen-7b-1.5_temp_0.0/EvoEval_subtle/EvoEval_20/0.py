from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """From a supplied list of numbers (of length at least two) select and return two adjacent numbers that are the closest to each other and return them in reverse order (larger number, smaller number).

    Example:
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 1.0)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 4.5])
    (5.0, 4.5)

    Args:
        numbers (List[float]): A list of floating-point numbers.

    Returns:
        Tuple[float, float]: A tuple containing the two closest adjacent numbers in reverse order.
    """
    if len(numbers) < 2:
        raise ValueError('The list must have at least two elements.')
    closest_pair = (numbers[0], numbers[1])
    min_diff = abs(numbers[1] - numbers[0])
    for i in range(1, len(numbers) - 1):
        diff = abs(numbers[i] - numbers[i - 1])
        if diff < min_diff:
            closest_pair = (numbers[i - 1], numbers[i])
            min_diff = diff
    return closest_pair[::-1]