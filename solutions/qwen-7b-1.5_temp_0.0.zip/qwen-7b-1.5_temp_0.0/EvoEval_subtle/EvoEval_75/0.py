
def is_multiply_prime(a):
    """
    Check if a given number less than 100 is the product of 4 prime numbers. Return True if it is, False otherwise.

    Args:
        a (int): The number to be checked.

    Returns:
        bool: True if a is the multiplication of 4 prime numbers, False otherwise.
    """
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
    for i in range(len(primes)):
        for j in range(i + 1, len(primes)):
            for k in range(j + 1, len(primes)):
                for l in range(k + 1, len(primes)):
                    product = primes[i] * primes[j] * primes[k] * primes[l]
                    if product == a and len(set(primes)) == 4:
                        return True
    return False