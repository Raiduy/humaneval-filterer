
def sum_to_n(n: int, m: int=1) -> int:
    """Sums numbers from m to n.

    Args:
        n (int): The upper limit of the range to sum.
        m (int, optional): The lower limit of the range. Defaults to 1.

    Returns:
        int: The sum of numbers from m to n.

    Example usages:
        >>> sum_to_n(30, 10)
        420
        >>> sum_to_n(100, 50)
        3825
        >>> sum_to_n(5, 2)
        14
        >>> sum_to_n(10, 5)
        45
        >>> sum_to_n(1, 1)
        1
    """
    return sum(range(m, n + 1))