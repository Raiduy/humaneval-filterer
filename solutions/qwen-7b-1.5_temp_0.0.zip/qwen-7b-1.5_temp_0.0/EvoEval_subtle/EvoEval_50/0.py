
def encode_shift(s: str, shift: int = 5):
    """
    returns encoded string by shifting every character by 'shift' in the alphabet.
    """
    return "".join([chr(((ord(ch) + shift - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str, shift: int=5):
    """
    Decodes a string that was encoded using the `encode_shift` function by reversing the shift.

    Args:
        s (str): The encoded string to be decoded.
        shift (int, optional): The original shift used for encoding. Defaults to 5.

    Returns:
        str: The decoded string.
    """
    return ''.join([chr((ord(ch) - shift - ord('a')) % 26 + ord('a')) for ch in s])