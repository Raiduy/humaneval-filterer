
def string_sequence(n: int) -> str:
    """Return a string containing space-delimited numbers starting from 1 up to n inclusive."""
    sequence = ''
    for i in range(1, n + 1):
        sequence += str(i) + ' '
    return sequence.strip()