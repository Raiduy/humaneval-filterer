def get_row(lst, x):
    """
    This function takes a 2-dimensional list (matrix-like structure) `lst` and an integer `x`, and returns a list of tuples representing the coordinates of `x` in the list. The coordinates are sorted first by rows in descending order and then by columns in ascending order.

    **Examples:**

    ```python
    # Example 1
    lst = [
        [1, 2, 3, 4, 5, 6],
        [1, 2, 3, 4, 1, 6],
        [1, 2, 3, 4, 5, 1]
    ]
    x = 1
    result = get_row(lst, x)
    assert result == [(2, 0), (2, 5), (1, 0), (1, 4), (0, 0)], "Expected [(2, 0), ..., (0, 0)]"

    # Example 2
    lst = []
    x = 1
    result = get_row(lst, x)
    assert result == [], "Expected [] when lst is empty"

    # Example 3
    lst = [[], [1], [1, 2, 3]]
    x = 3
    result = get_row(lst, x)
    assert result == [(2, 2)], "Expected [(2, 2)] for x=3"
    ```

    Parameters:
    lst (list): A 2D list with varying column counts.
    x (int): The integer to find in the list.

    Returns:
    list: A list of tuples representing the coordinates of `x` in the form `(row, column)`.
    """
    return sorted([(i, j) for (i, row) in enumerate(lst, reverse=True) for (j, value) in enumerate(row, start=0) if value == x], key=lambda x: (-x[0], x[1]))