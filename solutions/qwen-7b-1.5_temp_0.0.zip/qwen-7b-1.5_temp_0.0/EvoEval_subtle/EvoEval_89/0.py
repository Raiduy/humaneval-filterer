
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift up by two multiplied to two places.
    For example:
    encrypt('lm') returns 'hi'
    encrypt('ewhjklnop') returns 'asdfghjkl'
    encrypt('kj') returns 'gf'
    encrypt('ix') returns 'et'
    """
    shifted_alphabet = 'abcdefghijklmnopqrstuvwxyz'.translate(str.maketrans('', '', shifted_alphabet[2:])) + shifted_alphabet[:2]
    encrypted_string = ''
    for char in s:
        if char.isalpha():
            shifted_index = (ord(char.lower()) - ord('a') + 2 * 2) % 26
            encrypted_char = shifted_alphabet[shifted_index].upper() if char.isupper() else shifted_alphabet[shifted_index]
        else:
            encrypted_char = char
        encrypted_string += encrypted_char
    return encrypted_string