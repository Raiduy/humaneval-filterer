
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits left by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    """
    x_str = str(x)
    effective_shift = shift % len(x_str)
    shifted_str = x_str[effective_shift:] + x_str[:effective_shift]
    if effective_shift == 0:
        return shifted_str
    else:
        return shifted_str[::-1]