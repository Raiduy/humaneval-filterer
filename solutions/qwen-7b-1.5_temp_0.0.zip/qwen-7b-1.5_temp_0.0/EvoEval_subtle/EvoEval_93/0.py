

def encode(message):
    """
    Function to encode a message by swapping case and replacing vowels
    according to their position three places ahead in the English alphabet.

    Args:
    message (str): The input message to be encoded.

    Returns:
    str: The encoded message.
    
    Examples:
    >>> encode('test')
    'THST'
    >>> encode('This is a message')
    'tHLS LS D MHSSDGH'
    """
    encoded_message = ''
    for char in message.lower():
        if char.isalpha():
            if char in 'aeiou':
                vowel_index = ord(char) - ord('a') + 3
                if vowel_index > 25:
                    vowel_index -= 26
                encoded_message += chr(vowel_index)
            else:
                encoded_message += char.upper()
        else:
            encoded_message += char
    return encoded_message