
def prime_length(string):
    """Write a function that takes a string and returns True if the string length (excluding white spaces) is a prime number or False otherwise.
    
    Examples:
    >>> prime_length('Hello')
    True
    >>> prime_length(' a b c d c b a ')
    True
    >>> prime_length('kittens')
    True
    >>> prime_length('orange')
    False
    """
    string_without_spaces = ''.join(string.split())
    length = int(string_without_spaces)

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    return is_prime(length)