
def pairs_sum_to_one(l):
    """
    Given a list of integers, this function checks if there are two distinct elements whose sum equals 1. It returns True if such a pair exists and False otherwise.

    Examples:
    >>> pairs_sum_to_one([1, 3, 5, 0])
    True
    >>> pairs_sum_to_one([1, 3, -2, 1])
    True
    >>> pairs_sum_to_one([1, 2, 3, 7])
    False
    >>> pairs_sum_to_one([2, 4, -5, 3, 5, 7])
    False
    >>> pairs_sum_to_one([1])
    False
    """
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            if l[i] + l[j] == 1:
                return True
    return False