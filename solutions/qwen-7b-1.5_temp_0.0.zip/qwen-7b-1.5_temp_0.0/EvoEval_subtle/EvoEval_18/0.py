
def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring can be found in the original string. Do not count overlapping cases.

    Args:
        string (str): The main string from which to count occurrences.
        substring (str): The substring to search within the string.

    Returns:
        int: The number of times the substring appears in the string, excluding overlapping instances.

    Example usage:
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    2
    """
    count = 0
    index = 0
    while index < len(string):
        if string[index:].startswith(substring):
            count += 1
            index += len(substring)
        else:
            index += 1
    return count