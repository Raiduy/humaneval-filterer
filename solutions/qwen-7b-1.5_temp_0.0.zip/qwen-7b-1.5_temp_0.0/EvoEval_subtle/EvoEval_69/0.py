
def search(lst):
    """
    Given a non-empty list of positive integers, find the smallest integer that is greater than zero and has a frequency
    greater than or equal to its value. If no such integer exists, return -1.

    Examples:
    >>> search([4, 1, 2, 2, 3, 1]) == 1
    >>> search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 1
    >>> search([5, 5, 4, 4, 4]) == -1
    """

    def frequency(int_num):
        return lst.count(int_num)
    smallest_greater = -1
    for num in lst:
        if num > 0 and frequency(num) >= num:
            smallest_greater = num
            break
    return smallest_greater