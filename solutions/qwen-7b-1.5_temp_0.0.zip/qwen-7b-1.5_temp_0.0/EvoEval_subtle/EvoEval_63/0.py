
def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibonacci sequence, defined as:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-3) + fibfib(n-2) - fibfib(n-1).

    This function efficiently computes the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    -2
    >>> fibfib(8)
    4
    """
    fibfib_sequence = [0, 0, 1]
    for i in range(3, n + 1):
        fibfib_sequence.append(fibfib_sequence[i - 3] + fibfib_sequence[i - 2] - fibfib_sequence[i - 1])
    return fibfib_sequence[n]