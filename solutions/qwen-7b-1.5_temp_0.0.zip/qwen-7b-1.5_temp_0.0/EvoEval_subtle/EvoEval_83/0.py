
def starts_one_ends(n):
    """
    Given a positive integer n, this function returns the count of the numbers
    of n-digit positive integers that start with 1 or end with 2.

    Args:
        n (int): A positive integer representing the number of digits in the integers.

    Returns:
        int: The count of the desired integers.
    """
    count = 0
    for num in range(10 ** (n - 1), 1000):
        if str(num)[0] == '1' or str(num)[-1] == '2':
            count += 1
    return count