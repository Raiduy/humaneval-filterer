
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters are arranged in
    descending order based on ASCII value. The order of words and blank spaces remains unchanged.

    Example:
    >>> anti_shuffle('Hi')
    'iH'
    >>> anti_shuffle('hello')
    'ollhe'
    >>> anti_shuffle('Hello World!!!')
    'olleH roldW!!!'
    """
    words = s.split()
    reversed_words = [word[::-1] for word in words]
    ordered_string = ' '.join(reversed_words)
    return ordered_string