
def car_race_collision(n: int) -> int:
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right, and a different set of 2*n cars are driving right to left.
    The function calculates the number of collisions between these cars, considering they move at the same speed.

    Parameters:
    n (int): The number of cars moving left to right.

    Returns:
    int: The number of collisions that occur between the left-moving and right-moving cars.

    Example:
    >>> car_race_collision(3)
    3
    >>> car_race_collision(5)
    10
    >>> car_race_collision(1)
    0
    """
    collisions = n * 2
    return collisions