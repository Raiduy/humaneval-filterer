
from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple consisting of a sum and a product of all the non-negative integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.

    Example:
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)

    Args:
    numbers (List[int]): A list of integers.

    Returns:
    Tuple[int, int]: A tuple containing the sum and product of the non-negative integers.
    """
    if not numbers:
        return (0, 1)
    non_negative_numbers = [num for num in numbers if num >= 0]
    sum_of_numbers = sum(non_negative_numbers)
    product_of_numbers = 1 if not non_negative_numbers else reduce(lambda x, y: x * y, non_negative_numbers)
    return (sum_of_numbers, product_of_numbers)