
def is_happy(s):
    """Check if a given string `s` is happy according to the provided criteria.

    Args:
        s (str): The input string.

    Returns:
        bool: True if the string is happy, False otherwise.
    """
    if len(s) < 4:
        return False
    for i in range(3, len(s) - 3, 4):
        if s[i - 1] == s[i] or s[i] == s[i + 1] or s[i + 1] == s[i + 2]:
            return False
    return True