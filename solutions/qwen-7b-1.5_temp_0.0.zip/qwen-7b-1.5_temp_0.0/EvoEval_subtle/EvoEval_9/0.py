
from typing import List, Tuple


def rolling_min(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of rolling minimum element found until a given moment in the sequence.

    Example:
    >>> rolling_min([1, 2, 3, 2, 3, 4, 2])
    [1, 1, 1, 1, 1, 1, 1]

    Args:
        numbers (List[int]): The input list of integers.

    Returns:
        List[int]: A list containing the rolling minimum elements at each index in the input list.
    """
    result = []
    current_min = numbers[0]
    for num in numbers:
        result.append(current_min)
        if num < current_min:
            current_min = num
    return result