
def flip_case(string: str, exclusive_case: str='lower') -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase,
    unless they are in the exclusive_case. This can be either 'lower' or 'upper'.

    Args:
        string (str): The input string to flip the case of.
        exclusive_case (str, optional): The type of characters to keep their original case. 
            Defaults to 'lower', meaning lowercase letters will remain unchanged.

    Returns:
        str: The flipped string with uppercase characters converted to lowercase and vice versa, except for those specified in exclusive_case.

    Example:
        >>> flip_case('Hello', 'lower')
        'hello'
    """
    flipped_string = ''
    for char in string:
        if exclusive_case == 'lower' and char.islower():
            flipped_string += char.upper()
        elif exclusive_case == 'upper' and char.isupper():
            flipped_string += char.lower()
        else:
            flipped_string += char
    return flipped_string