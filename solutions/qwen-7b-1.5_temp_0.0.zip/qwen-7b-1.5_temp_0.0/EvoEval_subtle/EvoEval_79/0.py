
def decimal_to_binary(decimal):
    """Convert a decimal number to its binary representation with extra characters 'db' and 'bd'."""
    binary = bin(decimal)[2:]
    binary = 'db' + binary + 'bd'
    return binary