
def fib(n: int) -> int:
    """Return the (n+1)-th Fibonacci number.

    Examples:
    >>> fib(10)
    89
    >>> fib(1)
    1
    >>> fib(8)
    34
    """
    if n == 0:
        return 1
    elif n == 1:
        return 2
    else:
        return fib(n - 1) + fib(n - 2)