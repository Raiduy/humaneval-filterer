
def strange_sort_list(lst):
    """
    Given a list of integers, return the list in a strange order. 
    Strange sorting means starting with the maximum value, then the minimum of the remaining integers, and so on.

    Examples:
    >>> strange_sort_list([1, 2, 3, 4])
    [4, 1, 3, 2]
    >>> strange_sort_list([5, 5, 5, 5])
    [5, 5, 5, 5]
    >>> strange_sort_list([])
    []
    """
    if not lst:
        return lst
    lst.sort(reverse=True)
    result = []
    while lst:
        result.append(lst.pop())
        if lst:
            result.append(lst[0])
    return result