
from typing import List


def intersperse(numbers: List[int], delimiter: int) -> List[int]:
    """Insert a number 'delimiter' between every two consecutive elements of the input list `numbers' and append it at the end of the list.

    Example:
    >>> intersperse([], 4)
    [4]
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3, 4]

    Args:
        numbers (List[int]): The input list to intersperse.
        delimiter (int): The number to be inserted between each element.

    Returns:
        List[int]: The list with the delimiter inserted.
    """
    result = []
    for num in numbers:
        result.append(num)
        if len(result) > 1:
            result.append(delimiter)
    return result