
from typing import List


def parse_music(music_string: str) -> List[int]:
    """Parse a string representing musical notes in a special ASCII format and return a list of unique integers indicating the number of beats for each note in descending order.

    Legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    Example usage:
    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1]

    Args:
    music_string (str): The input string containing musical notes.

    Returns:
    List[int]: A list of unique integers representing the number of beats for each note, sorted in descending order.
    """
    note_values = {'o': 4, 'o|': 2, '.|': 1}
    note_counts = []
    for note in music_string:
        if note in note_values:
            note_counts.append(note_values[note])
    unique_counts = list(set(note_counts))
    unique_counts.sort(reverse=True)
    return unique_counts