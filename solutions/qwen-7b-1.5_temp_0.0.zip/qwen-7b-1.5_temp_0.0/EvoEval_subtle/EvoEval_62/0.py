

def derivative(xs: list) -> list:
    """ xs represents coefficients of a polynomial in ascending order of the power of x.
    The function returns the derivative of the polynomial in the same form, but in descending order of the power of x.

    Example:
    >>> derivative([3, 1, 2, 4, 5])
    [20, 12, 4, 1]
    >>> derivative([1, 2, 3])
    [6, 2]
    """
    derivative_coefficients = []
    n = len(xs) - 1
    for i in range(n, 0, -1):
        derivative_coefficients.append(i * xs[i])
    return derivative_coefficients