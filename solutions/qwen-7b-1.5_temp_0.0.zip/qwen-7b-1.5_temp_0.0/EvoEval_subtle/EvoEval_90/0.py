
def next_largest(lst):
    """
    Given a list of integers, this function returns the 2nd largest element of the list. If there is no such element (the list is either empty or contains only one unique value), it returns None.

    Examples:
    >>> next_largest([1, 2, 3, 4, 5])
    4
    >>> next_largest([5, 1, 4, 3, 2])
    4
    >>> next_largest([])
    None
    >>> next_largest([1, 1])
    None
    """
    if len(lst) < 2:
        return None
    lst.sort(reverse=True)
    try:
        return lst[1]
    except IndexError:
        return None