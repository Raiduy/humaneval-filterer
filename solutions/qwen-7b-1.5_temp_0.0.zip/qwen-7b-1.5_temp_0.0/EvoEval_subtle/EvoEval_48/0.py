

def is_palindrome(text: str, case_sensitive: bool=True) -> bool:
    """
    Checks if given string is a palindrome considering case sensitivity according to the provided parameter.

    Examples:
    >>> is_palindrome('', True)
    True
    >>> is_palindrome('aba', True)
    True
    >>> is_palindrome('Aba', False)
    True
    >>> is_palindrome('aaaaa', True)
    True
    >>> is_palindrome('zbcd', True)
    False

    Args:
        text (str): The input string to check for palindrome.
        case_sensitive (bool, optional): Whether to consider case sensitivity or not. Defaults to True.

    Returns:
        bool: True if the string is a palindrome, False otherwise.
    """
    if not case_sensitive:
        text = text.replace(' ', '').lower()
    return text == text[::-1]