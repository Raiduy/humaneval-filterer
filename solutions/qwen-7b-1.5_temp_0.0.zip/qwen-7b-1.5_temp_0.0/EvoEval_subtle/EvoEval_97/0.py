
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the sum of their unit digits.
    Assume the input is always valid.
    Examples:
    >>> multiply(148, 412)
    10
    >>> multiply(19, 28)
    17
    >>> multiply(2020, 1851)
    1
    >>> multiply(14, -15)
    9
    """
    product = a * b
    unit_digits_sum = sum((int(digit) for digit in str(product) if digit != '0'))
    return unit_digits_sum