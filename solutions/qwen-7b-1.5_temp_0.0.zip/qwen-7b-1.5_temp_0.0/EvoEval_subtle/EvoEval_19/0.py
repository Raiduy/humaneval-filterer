
from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'. 
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', and 'nine'.
    This function returns the string with numbers sorted from largest to smallest.

    Example:
    >>> sort_numbers('three one five')
    'five three one'

    :param numbers: The input string containing numerical digits separated by spaces
    :return: The sorted string of numbers
    """
    number_list = [int(num) for num in numbers.split()]
    sorted_list = sorted(number_list, reverse=True)
    return ' '.join((str(num) for num in sorted_list))