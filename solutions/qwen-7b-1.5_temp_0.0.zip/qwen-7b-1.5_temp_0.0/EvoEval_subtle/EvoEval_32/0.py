import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """Finds the zero of a polynomial given its coefficients.

    The polynomial is of the form:
    xs[0] + xs[1] * x^1 + xs[2] * x^3 + ... + xs[n] * x^(2*n-1)

    This function returns only the first zero point, even if there are multiple.
    It assumes the list has at least two coefficients and the largest non-zero coefficient to guarantee a solution.

    Examples:
    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-2, -3, 1]), 2)  # (x + 1) (x + 1) (x - 2) = -2 - 3x + x^3
    -1.0
    """
    if len(xs) < 2 or not any((coeff != 0 for coeff in xs)):
        raise ValueError('The list must have at least two non-zero coefficients.')
    degree = len(xs) // 2 - 1
    if abs(xs[-1]) > abs(xs[degree]):
        potential_roots = [i / j for (i, j) in enumerate(xs[:-1]) if j != 0 and gcd(i, j) == 1]
    else:
        potential_roots = [i for i in range(-abs(xs[degree]), abs(xs[degree]) + 1) if gcd(abs(i), abs(xs[-1])) == 1]
    for root in potential_roots:
        if poly(xs, root) == 0:
            return root
    return None