
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers (at least two elements), apply a linear transform to the list such that the smallest number becomes 0 and the largest becomes 1. Return the list in descending order.

    Example:
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [1.0, 0.75, 0.5, 0.25, 0.0]

    Args:
    - numbers: A list of float numbers

    Returns:
    - The rescaled list in descending order
    """
    min_num = min(numbers)
    max_num = max(numbers)
    scaled_numbers = [(num - min_num) / (max_num - min_num) for num in numbers]
    return sorted(scaled_numbers, reverse=True)