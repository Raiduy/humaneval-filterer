
def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of four characters.
    """
    n = 4
    # split string to groups. Each of length 4.
    groups = [s[(n * i):min((n * i + n), len(s))] for i in range((len(s) + n - 1) // n)]
    # cycle elements in each group. Unless group has fewer elements than 4.
    groups = [(group[1:] + group[0]) if len(group) == n else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    Decodes a string that was encoded with the `encode_cyclic` function.
    """
    decoded_groups = [group[::-1] if len(group) == n else group for group in s.split()]
    decoded_str = ''.join(decoded_groups)
    return decoded_str