
def any_int(x, y, z):
    """
    Create a function that checks if one number is equal to the sum of the absolute values of the other two, and all numbers are integers.

    Args:
        x (int): The first number.
        y (int): The second number.
        z (int): The third number.

    Returns:
        bool: True if the condition is met, False otherwise.

    Examples:
        >>> any_int(5, 2, 7)
        True
        >>> any_int(3, 2, 2)
        False
        >>> any_int(3, -2, 1)
        True
        >>> any_int(3.6, -2.2, 2)
        False

    """
    if not (isinstance(x, int) and isinstance(y, int) and isinstance(z, int)):
        return False
    sum_abs = abs(x) + abs(y) + abs(z)
    if x == sum_abs or y == sum_abs or z == sum_abs:
        return True
    else:
        return False