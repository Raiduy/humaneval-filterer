
def hex_key(num):
    """Count the number of hexadecimal digits that are not primes.

    Args:
        num (str): A hexadecimal number as a string.

    Returns:
        int: The count of non-prime hexadecimal digits.

    Notes:
        - Assumes the input is always correct or an empty string.
        - Hexadecimal digits include 0-9, A-F (upper case).
        - Prime numbers considered: 2, 3, 5, 7, 11, 13, 17,...

    Examples:
        >>> hex_key("AB")
        1
        >>> hex_key("1077E")
        3
        >>> hex_key("ABED1A33")
        4
        >>> hex_key("123456789ABCDEF0")
        9
        >>> hex_key("2020")
        2

    """
    count = 0
    decimal_num = int(num, 16)
    for digit in num:
        if digit.lower() not in ['0', '1', '4', '6', '8', '9', 'a', 'c', 'e']:
            count += 1
    return count