
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string representing multiple groups for nested parentheses separated by spaces.
    For each group, it calculates the deepest level of nesting and returns the list in descending order.

    Example:
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [3, 3, 2, 1]

    :param paren_string: The string with nested parentheses
    :return: A list of integers representing the depths of nesting in descending order
    """
    depths = []
    groups = paren_string.split()
    for group in groups:
        depth = count_nested_parens(group)
        depths.append(depth)
    depths.sort(reverse=True)
    return depths