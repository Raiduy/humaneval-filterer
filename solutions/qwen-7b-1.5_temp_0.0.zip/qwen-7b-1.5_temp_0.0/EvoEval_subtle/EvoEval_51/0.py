
def remove_consonants(text):
    """
    remove_consonants is a function that takes a string and returns a string without consonants. It removes all characters from the input except for vowels.

    Example Usage:
    >>> remove_consonants('')
    ''
    >>> remove_consonants("abcdef
ghijklm")
    'ae
i'
    >>> remove_consonants('abcdef')
    'ae'
    >>> remove_consonants('aaaaa')
    'aaaaa'
    >>> remove_consonants('aaBAA')
    'aaAA'
    >>> remove_consonants('zbcd')
    ''

    :param text: The input string to remove consonants from
    :return: The string with consonants removed
    """
    vowels = 'aeiouAEIOU'
    result = ''
    for char in text:
        if char in vowels:
            result += char
    return result