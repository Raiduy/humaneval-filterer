
from typing import List


def median_absolute_deviation(numbers: List[float]) -> float:
    """For a given list of input numbers, calculate Median Absolute Deviation
    around the median of this dataset.

    Median Absolute Deviation is the median absolute difference between each
    element and a centerpoint (median in this case):
    MAD = median(|x - x_median|)

    Example usage:
    >>> median_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    middle_index = n // 2
    median = sorted_numbers[middle_index]
    abs_differences = [abs(num - median) for num in sorted_numbers]
    mad = sorted(abs_differences)[middle_index]
    return mad