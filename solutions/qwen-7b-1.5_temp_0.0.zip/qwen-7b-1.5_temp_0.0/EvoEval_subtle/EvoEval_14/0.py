
from typing import List


def all_prefixes(string: str) -> List[str]:
    """Return list of all prefixes from longest to shortest of the input string.

    Example:
    >>> all_prefixes('abc')
    ['abc', 'ab', 'a']

    """
    prefixes = []
    for i in range(len(string)):
        prefixes.append(string[:i + 1])
    prefixes.sort(reverse=True)
    return prefixes