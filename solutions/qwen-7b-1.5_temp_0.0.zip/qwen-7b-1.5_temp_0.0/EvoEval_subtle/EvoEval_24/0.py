
def smallest_divisor(n: int) -> int:
    """For a given number n, find the smallest number that divides n evenly, larger than 1
    
    Example usage:
    >>> smallest_divisor(15)
    3
    """
    for divisor in range(2, n + 1):
        if n % divisor == 0:
            return divisor
    return n