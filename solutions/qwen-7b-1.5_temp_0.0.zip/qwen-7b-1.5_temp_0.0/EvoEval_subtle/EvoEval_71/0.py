
def triangle_area(a, b, c):
    """
    Given the lengths of the three sides of a triangle, this function calculates the area of the triangle and returns it rounded to 3 decimal points.
    If the three sides form a valid triangle (i.e., the sum of any two sides is greater than the third side), it will return the area. Otherwise, it returns -1.

    Example:
    >>> triangle_area(3, 4, 5)
    6.000
    >>> triangle_area(1, 2, 10)
    -1
    """
    if a + b > c and a + c > b and (b + c > a):
        s = (a + b + c) / 2
        area = round((s * (s - a) * (s - b) * (s - c)) ** 0.5, 3)
    else:
        area = -1
    return area