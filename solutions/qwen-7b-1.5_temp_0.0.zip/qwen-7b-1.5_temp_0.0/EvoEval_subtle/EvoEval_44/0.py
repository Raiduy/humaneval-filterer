

def change_base(x: int, base: int) -> int:
    """Change numerical base of input number x to base.
    Return integer representation after the conversion.
    Base numbers must be less than 10.
    
    Examples:
    >>> change_base(8, 3)
    22
    >>> change_base(8, 2)
    1000
    >>> change_base(7, 2)
    111
    """
    if base < 10:
        converted_number = int(str(x)[::-1].zfill(len(str(x)) - len(str(base))) + str(x))
        return converted_number
    else:
        raise ValueError('Base number must be less than 10.')