
from typing import List


def filter_by_suffix(strings: List[str], suffix: str) -> List[str]:
    """Filter an input list of strings only for ones that end with a given suffix.

    Example usage:
    >>> filter_by_suffix([], 'a')
    []
    >>> filter_by_suffix(['abc', 'bcd', 'cde', 'array'], 'c')
    ['abc']

    Args:
        strings (List[str]): The list of strings to filter.
        suffix (str): The suffix to look for at the end of the strings.

    Returns:
        List[str]: A new list containing only the strings that end with the specified suffix.
    """
    return [string for string in strings if string.endswith(suffix)]