
def check_dict_case(dict):
    """
    Given a dictionary, this function checks if all keys are either in lower case or upper case and have at least 3 keys. It returns True if the conditions are met, and False otherwise.

    Examples:
    - **False**: `check_dict_case({"a":"apple", "b":"banana"})` because it has less than 3 keys.
    - **False**: `check_dict_case({"a":"apple", "A":"banana", "B":"banana"})` because it contains both lower and upper case keys.
    - **False**: `check_dict_case({"a":"apple", 8:"banana", "a":"apple"})` because it contains a non-string key.
    - **False**: `check_dict_case({"Name":"John", "Age":"36", "City":"Houston"})` because it contains mixed case keys.
    - **True**: `check_dict_case({"STATE":"NC", "ZIP":"12345", "CITY": "New York" })` because all keys are in upper case and there are at least 3.

    Args:
        dict (dict): The dictionary to be checked.

    Returns:
        bool: True if all keys are in lower or upper case and meet the minimum key count, False otherwise.
    """
    if not dict or len(dict) < 3:
        return False
    key_case = all((key.islower() for key in dict)) or all((key.isupper() for key in dict))
    return key_case