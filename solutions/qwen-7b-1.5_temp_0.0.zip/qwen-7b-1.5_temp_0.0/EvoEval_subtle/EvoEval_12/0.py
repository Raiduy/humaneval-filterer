
from typing import List, Optional


def shortest(strings: List[str]) -> Optional[str]:
    """Out of a list of strings, return the shortest one. If there are multiple strings of the same length, return the first one. Return None if the input list is empty."""
    if not strings:
        return None
    shortest_string = min(strings, key=len)
    return shortest_string