
def is_bored(S):
    """
    This function takes a string `S` as input and counts the number of boredoms, which are sentences that start with the word "I". Sentences are considered separate by periods (.), question marks (?), or exclamation marks (!).

    Example usage:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1

    Args:
        S (str): The input string containing sentences.

    Returns:
        int: The count of boredoms in the input string.
    """
    # Split the string into sentences using punctuation marks as delimiters
    sentences = S.split('.!?')
    
    # Initialize a counter for boredoms
    boredom_count = 0
    
    # Iterate through each sentence
    for sentence in sentences:
        # Check if the sentence starts with "I"
        if sentence.startswith('I'):
            boredom_count += 1
            
    return boredom_count
