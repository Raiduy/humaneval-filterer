
def by_length(arr):
    """
    Given an array of integers, sort the integers between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    Parameters:
    arr (list of integers): The input array to be processed.

    Returns:
    list: A new list with the sorted, reversed, and digit-replaced integers.

    Examples:
    >>> arr = [2, 1, 1, 4, 5, 8, 2, 3]
    >>> result = by_length(arr)
    >>> result == ['Eight', 'Five', 'Four', 'Three', 'Two', 'Two', 'One', 'One']
    True

    >>> arr = []
    >>> result = by_length(arr)
    >>> result == []
    True

    >>> arr = [1, -1, 55]
    >>> result = by_length(arr)
    >>> result == ['One']
    True

    """
    # Filter out numbers outside the range 1-9 and ignore negative numbers
    filtered_arr = [num for num in arr if 1 <= num <= 9 and num >= 0]

    # Sort the filtered array
    sorted_arr = sorted(filtered_arr)

    # Reverse the sorted array
    reversed_arr = sorted_arr[::-1]

    # Replace digits with their names
    digit_names = ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
    result = [digit_names[num] for num in reversed_arr]

    return result
