

def string_sequence(n: int) -> str:
    """Return a string containing space-delimited numbers starting from 0 up to n inclusive."""
    if n == 0:
        return '0'
    else:
        sequence = '0 ' + ' '.join(str(i) for i in range(1, n+1))
        return sequence
