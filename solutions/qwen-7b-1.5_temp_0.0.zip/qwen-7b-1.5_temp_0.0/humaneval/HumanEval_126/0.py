
def is_sorted(lst):
    """
    Given a list of numbers, determine if they are sorted in ascending order.
    Returns True if the list is sorted, False otherwise. Also checks for duplicates,
    where having more than one occurrence of the same number results in False.
    Assumptions: No negative numbers and only integers.

    Examples:
    >>> is_sorted([5])
    ➞ True
    >>> is_sorted([1, 2, 3, 4, 5])
    ➞ True
    >>> is_sorted([1, 3, 2, 4, 5])
    ➞ False
    >>> is_sorted([1, 2, 3, 4, 5, 6])
    ➞ True
    >>> is_sorted([1, 2, 3, 4, 5, 6, 7])
    ➞ True
    >>> is_sorted([1, 3, 2, 4, 5, 6, 7])
    ➞ False
    >>> is_sorted([1, 2, 2, 3, 3, 4])
    ➞ True
    >>> is_sorted([1, 2, 2, 2, 3, 4])
    ➞ False
    """
    # Check if list is empty or has only one element
    if len(lst) < 2:
        return True
    
    # Iterate through the list to find duplicates
    duplicates = [num for num, count in Counter(lst).items() if count > 1]
    
    # If duplicates exist, return False
    if duplicates:
        return False
    
    # Compare adjacent elements to check ascending order
    for i in range(1, len(lst)):
        if lst[i] < lst[i-1]:
            return False
    
    return True
