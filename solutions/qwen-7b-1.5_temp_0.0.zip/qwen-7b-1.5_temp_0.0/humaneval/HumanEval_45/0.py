

def triangle_area(a, h):
    """Given length of a side and high, return the area for a triangle.
    
    Example usage:
    >>> triangle_area(5, 3)
    7.5
    """
    # Calculate the area using the formula: 0.5 * base * height
    area = 0.5 * a * h
    return area
