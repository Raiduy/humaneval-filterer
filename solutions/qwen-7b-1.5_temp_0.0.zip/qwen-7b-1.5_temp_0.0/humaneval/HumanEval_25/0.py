from typing import List


def factorize(n: int) -> List[int]:
    """Return a list of prime factors of the given integer, arranged in ascending order and each factor repeated according to its frequency.

    Given that the input number is the product of all its factors, this function calculates the prime factors and their multiplicities.

    Examples:
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]

    """
    factors = []
    # Start with 2 as the smallest prime factor
    i = 2
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
            factors.append(i)  # Add the factor and its multiplicity (1 for now, will update later if it appears again)

    # If there's a remaining factor, it must be a prime greater than square root of n
    if n > 1:
        factors.append(n)

    # Count the occurrences of each factor and return the list with multiplicities
    result = {}
    for factor in factors:
        result[factor] = factors.count(factor)

    return [factor for factor, count in result.items()]
