
def bf(planet1, planet2):
    """
    This function takes two planet names as strings, planet1 and planet2, and returns a tuple containing all planets whose orbits are located between the orbits of planet1 and planet2, sorted by proximity to the Sun. It checks if the input planets are valid and returns an empty tuple if either is not correct.

    Parameters:
    planet1 (str): The name of the first planet.
    planet2 (str): The name of the second planet.

    Returns:
    tuple: A tuple containing the planets in the specified order, or an empty tuple if the input planets are invalid.
    
    Examples:
    >>> bf("Jupiter", "Neptune") == ("Saturn", "Uranus")
    >>> bf("Earth", "Mercury") == ("Venus")
    >>> bf("Mercury", "Uranus") == ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    """

    # Define the order of the planets in the solar system
    solar_system = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]

    # Check if planet1 and planet2 are valid planet names
    if planet1 not in solar_system or planet2 not in solar_system:
        return []

    # Find the index range for the planets between planet1 and planet2
    start_index = solar_system.index(planet1) + 1
    end_index = solar_system.index(planet2)

    # Return the planets within the range, excluding the endpoints
    planets_between = solar_system[start_index:end_index]
    planets_between.sort()

    return planets_between
