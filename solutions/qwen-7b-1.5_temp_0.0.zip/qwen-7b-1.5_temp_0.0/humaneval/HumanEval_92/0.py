
def any_int(x, y, z):
    """
    Create a function that checks if one of the numbers is equal to the sum of the other two, and all numbers are integers.

    Args:
        x (int): The first number.
        y (int): The second number.
        z (int): The third number.

    Returns:
        bool: True if the condition is met, False otherwise.

    Examples:
        >>> any_int(5, 2, 7)
        True
        >>> any_int(3, 2, 2)
        False
        >>> any_int(3, -2, 1)
        True
        >>> any_int(3.6, -2.2, 2)
        False

    """
    # Check if all numbers are integers
    if not (isinstance(x, int) and isinstance(y, int) and isinstance(z, int)):
        return False
    
    # Check if any number is equal to the sum of the other two
    for num in [x, y, z]:
        if num == x + y or num == y + z or num == z + x:
            return True
    
    # If none of the conditions are met, return False
    return False
