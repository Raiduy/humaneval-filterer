
def find_max(words):
    """Function to find the word with the maximum number of unique characters, considering both the count and lexicographical order
    
    Args:
        words (list): A list of strings containing different words

    Returns:
        str: The word with the maximum number of unique characters, or an empty string if no unique characters are found
    
    Examples:
        >>> find_max(["name", "of", "string"])
        "string"
        >>> find_max(["name", "enam", "game"])
        "enam"
        >>> find_max(["aaaaaaa", "bb", "cc"])
        "aaaaaaa"
    """
    # Initialize a variable to store the word with max unique characters and a counter for unique characters
    max_unique_word = ""
    max_unique_count = 0

    # Iterate through each word in the list
    for word in words:
        # Count the unique characters in the word
        unique_chars = set(word)
        # If the current word has more unique characters than the current max, update max and word
        if len(unique_chars) > max_unique_count:
            max_unique_word = word
            max_unique_count = len(unique_chars)
        # If the counts are equal, compare lexicographically
        elif len(unique_chars) == max_unique_count and word < max_unique_word:
            max_unique_word = word

    # Return the word with max unique characters or an empty string if none found
    return max_unique_word or ""
