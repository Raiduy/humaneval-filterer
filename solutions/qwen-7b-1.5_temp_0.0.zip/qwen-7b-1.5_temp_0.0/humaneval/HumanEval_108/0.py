
def count_nums(arr):
    """
    This function takes an array of integers and returns the number of elements
    whose sum of digits is greater than 0. If a number is negative, its first signed digit
    is considered. For example, -123 has signed digits -1, 2, and 3.

    Args:
        arr (list of integers): The input array to check.

    Returns:
        int: The count of numbers with a sum of digits > 0.

    Examples:
        >>> count_nums([]) == 0
        >>> count_nums([-1, 11, -11]) == 1
        >>> count_nums([1, 1, 2]) == 3
    """
    count = 0
    for num in arr:
        # Convert negative numbers to their first signed digit
        if num < 0:
            num = abs(num)
            # Check if the sum of digits is > 0
            if sum(int(digit) for digit in str(num)) > 0:
                count += 1
    return count
