
def is_multiply_prime(a):
    """Check if a number less than 100 is the product of exactly 3 prime numbers.

    Args:
        a (int): The number to be checked.

    Returns:
        bool: True if a is the multiplication of 3 prime numbers, False otherwise.
    """
    
    # Check if the number is less than 100
    if a < 100:
        primes = [2]  # Start with the smallest prime number (2)
        i = 3  # Skip even numbers since they are not prime (except 2)

        while len(primes) < 3 and i * i <= a:  # Continue until we have 3 primes or reach the square root of a
            if a % i == 0:  # If i divides a, it's a potential prime factor
                if i > 2:  # Skip 2 (already added as a prime)
                    primes.append(i)
                i += 2  # Move to the next odd number for further checking
            else:
                i += 1  # Increment to the next number

        # If we found exactly 3 primes, return True; otherwise, return False
        if len(primes) == 3:
            product = primes[0] * primes[1] * primes[2]
            if a == product:
                return True
        else:
            return False
