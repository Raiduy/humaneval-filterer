
def do_algebra(operator, operand):
    """
    Given two lists: `operator` containing basic algebra operations and `operand` a list of integers,
    this function builds an algebraic expression and evaluates it.

    Basic algebra operations:
    - Addition (+)
    - Subtraction (-)
    - Multiplication (*)
    - Floor division (//)
    - Exponentiation (**)

    Example usage:
    ```python
    operator = ['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    assert result == 9, "Expected result: 9"
    ```

    Note:
    - The length of `operator` list is equal to the length of `operand` list minus one.
    - `Operand` is a list of non-negative integers.
    - `Operator` list must have at least one operator, and `operand` list must have at least two operands.

    Args:
    - operator (list): A list of algebraic operators.
    - operand (list): A list of integers representing the operands.

    Returns:
    The evaluation of the algebraic expression.
    """
    
    # Check if the lengths are valid for the operation
    if len(operator) != len(operand) - 1 or len(operand) < 2 or len(operator) < 1:
        raise ValueError("Invalid input lengths. Must have at least two operands and one operator.")

    # Initialize the result variable
    result = operand[0]

    # Iterate through the operator list and perform the operations
    for i in range(len(operator)):
        if operator[i] == '+':
            result += operand[i + 1]
        elif operator[i] == '-':
            result -= operand[i + 1]
        elif operator[i] == '*':
            result *= operand[i + 1]
        elif operator[i] == '//':
            result //= operand[i + 1]
        elif operator[i] == '**':
            result **= operand[i + 1]

    return result
