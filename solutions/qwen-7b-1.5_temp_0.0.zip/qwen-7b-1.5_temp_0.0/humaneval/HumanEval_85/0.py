
def add(lst):
    """Given a non-empty list of integers lst, add the even elements that are at odd indices.

    Examples:
        >>> add([4, 2, 6, 7])
        2
    """
    # Check if the list is non-empty
    if not lst:
        return "Error: List must be non-empty"
    
    # Iterate through the list starting from index 0 (which is considered odd)
    result = 0
    for i in range(0, len(lst), 2):  # Step by 2 to reach odd indices
        # If the current index is odd and the element is even, add it to the result
        if lst[i] % 2 == 0:
            result += lst[i]
    
    return result
