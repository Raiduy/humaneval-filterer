

def car_race_collision(n: int) -> int:
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right, and a separate set of n cars are driving right to left.
    The function calculates the number of collisions between these two groups of cars.

    Parameters:
    n (int): The number of cars in each group.

    Returns:
    int: The number of collisions that occur.

    Example:
    >>> car_race_collision(3)
    0
    >>> car_race_collision(4)
    2
    >>> car_race_collision(5)
    4
    """

    # Since the road is infinite and the cars move at the same speed,
    # a collision will only occur if there's a car from both groups at the same position
    collisions = 0

    # For each car on the left, check if there's a car on the right at the same position
    for i in range(n):
        collisions += i  # Each left-moving car counts for its position

    return collisions
