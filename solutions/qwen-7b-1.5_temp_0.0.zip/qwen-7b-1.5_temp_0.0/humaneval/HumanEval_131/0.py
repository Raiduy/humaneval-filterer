
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    # Convert the integer to a string to iterate over its digits
    str_n = str(n)
    
    # Initialize a variable to store the product and check if all digits are even
    product = 1
    all_even = True
    
    # Iterate through each digit
    for digit in str_n:
        # If the digit is odd (not 0 or 2), multiply it with the product
        if int(digit) % 2 != 0:
            product *= int(digit)
            # If any odd digit is found, set all_even to False
            all_even = False
    
    # Return the product if there were odd digits, otherwise return 0
    return product if not all_even else 0
