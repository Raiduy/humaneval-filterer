import math

def max_fill(grid, capacity):
    """
    Given a rectangular grid of wells with water represented by 1s and empty wells represented by 0s, and buckets with a specific capacity, this function calculates the minimum number of times buckets need to be lowered to empty all the wells.

    Args:
        grid (list(list[int])): A 2D list representing the wells, where 1 indicates a unit of water and 0 is empty.
        capacity (int): The capacity of each bucket.

    Returns:
        int: The number of times buckets need to be lowered.

    Examples:
        >>> grid = [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
        >>> capacity = 1
        >>> max_fill(grid, capacity) # Output: 6
        >>> grid = [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
        >>> capacity = 2
        >>> max_fill(grid, capacity) # Output: 5
        >>> grid = [[0,0,0], [0,0,0]]
        >>> capacity = 5
        >>> max_fill(grid, capacity) # Output: 0

    Constraints:
        * Wells have the same length.
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] is either 0 or 1.
        * 1 <= capacity <= 10

    """
    # Calculate the total number of units of water
    total_water = sum(sum(row) for row in grid)

    # Calculate the number of buckets needed to empty the grid
    num_buckets = total_water // capacity if total_water % capacity == 0 else total_water // capacity + 1

    # Return the number of times buckets need to be lowered
    return num_buckets
