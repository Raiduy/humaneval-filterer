from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers (at least two elements), apply a linear transform to the list so that the smallest number becomes 0 and the largest becomes 1.

    Example:
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]

    Args:
    - numbers: A list of float values

    Returns:
    - The input list with the numbers rescaled to the range [0, 1].
    """
    # Calculate the minimum and maximum values in the list
    min_val = min(numbers)
    max_val = max(numbers)

    # Apply the linear transformation
    scaled_numbers = [(num - min_val) / (max_val - min_val) for num in numbers]

    return scaled_numbers
