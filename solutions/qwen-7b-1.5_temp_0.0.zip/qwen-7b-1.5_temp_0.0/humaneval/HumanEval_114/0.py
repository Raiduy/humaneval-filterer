
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.

    Example:
    >>> minSubArraySum([2, 3, 4, 1, 2, 4])
    == 1
    >>> minSubArraySum([-1, -2, -3])
    == -6
    """
    # Initialize two variables: current_min and total_sum
    current_min = float('inf')
    total_sum = 0

    # Iterate through each number in the array
    for num in nums:
        # Add the current number to the total sum
        total_sum += num
        # If the total sum becomes negative, reset it to the current minimum
        # as a negative sum will always be smaller than the current minimum
        if total_sum < current_min:
            current_min = total_sum
        # Update the current minimum if the current sum is smaller
        if total_sum < current_min:
            current_min = total_sum

    # Return the minimum sum
    return current_min
