
def encode(message):
        encoded_message = ""
        vowels = {'a': 'c', 'e': 'g', 'i': 'k', 'o': 'q', 'u': 'w', 'A': 'C', 'E': 'G', 'I': 'K', 'O': 'Q', 'U': 'W'}

        for char in message:
            if char.isalpha():
                if char.lower() in vowels:
                    encoded_message += vowels[char.lower()]
                else:
                    encoded_message += char.upper() if char.islower() else char.lower()
            else:
                encoded_message += char

        return encoded_message
    ```
    """ 
