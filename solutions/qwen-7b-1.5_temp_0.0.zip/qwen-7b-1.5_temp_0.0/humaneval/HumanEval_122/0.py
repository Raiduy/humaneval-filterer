
def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.

    Example:
        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)

    Function implementation:
    Iterate through the first k elements of the array and check if each element has at most two digits.
    If it does, add it to the sum. Return the final sum.
    """
    # Initialize the sum
    sum_digits_two = 0
    
    # Iterate through the first k elements
    for num in arr[:k]:
        # Convert the number to string to check its length
        num_str = str(num)
        # If the length is 1 or 2, add to the sum
        if len(num_str) <= 2:
            sum_digits_two += num
    
    return sum_digits_two

