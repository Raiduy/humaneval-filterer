
def Strongest_Extension(class_name, extensions):
    """Find the strongest extension for a given class and its list of extensions.

    Args:
        class_name (str): The name of the class.
        extensions (list[str]): A list of extensions to load with their respective strengths.

    Returns:
        str: The formatted string with the class name and the strongest extension name.

    Example:
        >>> Strongest_Extension('Slices', ['SErviNGSliCes', 'Cheese', 'StuFfed'])
        'Slices.SErviNGSliCes'
    """
    # Calculate the strength for each extension
    strengths = [(len(name) - name.countlower(), name) for name in extensions]

    # Sort extensions by strength in descending order
    sorted_extensions = sorted(strengths, reverse=True)

    # Find the strongest extension with the highest strength or the first one if ties
    strongest_extension = sorted_extensions[0][1] if strengths else extensions[0]

    # Format the result as ClassName.StrongestExtensionName
    return f"{class_name}.{strongest_extension}"
