

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    
    Examples:
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)  # This number is actually not prime, it's 17 * 823
    False
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    # Prime numbers are greater than 1
    if n <= 1:
        return False
    # Check for divisibility from 2 to the square root of n (inclusive)
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
