
def match_parens(lst):
    def is_valid_string(s):
        stack = []
        for char in s:
            if char == '(':
                stack.append(char)
            elif char == ')':
                if not stack:
                    return False
                stack.pop()
        return not stack  # If stack is empty, all parentheses are balanced

    # Check both strings individually
    string1 = lst[0]
    string2 = lst[1]
    
    # Concatenate and check validity
    possibilities = [string1 + string2, string2 + string1]
    for s in possibilities:
        if is_valid_string(s):
            return 'Yes'
    
    # If none of the concatenations work, return 'No'
    return 'No'
