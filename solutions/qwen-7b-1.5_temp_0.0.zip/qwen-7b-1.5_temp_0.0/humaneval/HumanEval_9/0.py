from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of rolling maximum element found until a given moment in the sequence.

    Example:
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]

    Args:
        numbers (List[int]): The input list of integers.

    Returns:
        List[int]: A list containing the rolling maximum elements at each index.
    """
    result = []
    for i, num in enumerate(numbers):
        result.append(max(numbers[:i+1]))
    return result
