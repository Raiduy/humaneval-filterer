
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters are arranged in
    ascending order based on ASCII value. The order of words and blank spaces remains intact.

    Example:
    >>> anti_shuffle('Hi')
    'Hi'
    >>> anti_shuffle('hello')
    'ehllo'
    >>> anti_shuffle('Hello World!!!')
    'Hello !!!Wdlor'
    """
    # Split the string into words and sort each word character-wise
    words = s.split()
    sorted_words = [sorted(word) for word in words]

    # Join the sorted words back with spaces to form the ordered string
    ordered_string = ' '.join(sorted_words)

    return ordered_string
