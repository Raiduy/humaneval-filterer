

def derivative(xs: list) -> list:
    """ xs represents coefficients of a polynomial.
    The function calculates the derivative of the polynomial in the same form:
    f(x) = xs[0] + xs[1] * x + xs[2] * x^2 + ...
    Returns the derivative polynomial.
    
    Examples:
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    derivative_poly = []
    n = len(xs) - 1  # Number of terms in the polynomial
    
    for i in range(1, n+1):  # Iterate from the second term (since constant is not derivable)
        derivative_poly.append(xs[i-1] * i)  # Multiply coefficient by its exponent and add to the derivative list

    return derivative_poly

