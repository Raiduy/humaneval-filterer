
def is_happy(s):
    """Check if a given string `s` is happy according to the provided criteria.

    Args:
        s (str): The input string.

    Returns:
        bool: True if the string is happy, False otherwise.
    """
    
    # Check if the length of the string is at least 3
    if len(s) < 3:
        return False
    
    # Iterate over every 3 consecutive letters in the string
    for i in range(len(s) - 2):
        # If any 3 consecutive letters are not distinct, return False
        if s[i] == s[i+1] == s[i+2]:
            return False
    
    # If no consecutive duplicates found, the string is happy
    return True
