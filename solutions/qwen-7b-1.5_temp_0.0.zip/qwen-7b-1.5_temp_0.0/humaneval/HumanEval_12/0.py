from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of a list of strings, return the longest one. If there are multiple strings of the same length, return the first one. Return None if the input list is empty."""
    
    # Check if the input list is empty
    if not strings:
        return None
    
    # Find the longest string by comparing their lengths
    longest_string = max(strings, key=len)
    
    # If there are ties for the longest length, return the first one
    return longest_string if len(strings) == 1 or longest_string == strings[0] else None
