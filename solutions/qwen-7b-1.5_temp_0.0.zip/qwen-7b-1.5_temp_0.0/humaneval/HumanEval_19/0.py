from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numberals from 'zero' to 'nine'. Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', and 'nine'. This function returns the string with numbers sorted from smallest to largest.

    Example:
    >>> sort_numbers('three one five')
    'one three five'

    """
    # Convert the input string to a list of integers
    number_list = [int(num) for num in numbers.split()]

    # Sort the list in ascending order
    sorted_list = sorted(number_list)

    # Convert the sorted list back to a string and join with spaces
    sorted_numbers = ' '.join(str(num) for num in sorted_list)

    return sorted_numbers
