
def compare(game, guess):
    """Function to compare guessed scores with actual scores and return the absolute differences
    
    Parameters:
    game (list): A list of scores representing the actual results of matches
    guess (list): A list of guesses for the same matches
    
    Returns:
    list: A list of absolute differences between the guess and the score. If the guess is correct, the value is 0.
    
    Example:
    >>> compare([1,2,3,4,5,1],[1,2,3,4,2,-2])
    [0, 0, 0, 0, 3, 3]
    >>> compare([0,5,0,0,0,4],[4,1,1,0,0,-2])
    [4, 4, 1, 0, 0, 6]
    """
    result = []
    for i in range(len(game)):
        diff = abs(game[i] - guess[i])
        if diff == 0:
            result.append(0)
        else:
            result.append(diff)
    return result
