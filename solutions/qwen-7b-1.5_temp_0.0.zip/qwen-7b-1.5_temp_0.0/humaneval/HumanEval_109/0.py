
def move_one_ball(arr):
    """Function to determine if it's possible to sort an array using right shift operations
    
    Parameters:
    arr (list of integers): The given array with randomly ordered elements

    Returns:
    bool: True if it's possible to obtain a sorted array through right shift operations, False otherwise
    """
    # Check if the array is empty, which always allows for a sorted state
    if len(arr) == 0:
        return True
    
    # Iterate through the array and check if any element is greater than its next
    for i in range(1, len(arr)):
        if arr[i] < arr[i-1]:
            # If we find a violation, return False as no number of shifts can make it sorted
            return False
    
    # If we reach here, all elements are in non-decreasing order or none were out of order
    return True
