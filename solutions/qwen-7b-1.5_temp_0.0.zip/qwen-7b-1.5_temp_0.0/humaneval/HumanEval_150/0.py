
def x_or_y(n, x, y):
    """A simple program which returns the value of x if n is a prime number, and y otherwise.

    Args:
    n (int): The number to check for primality.
    x (int): The value to return if n is prime.
    y (int): The value to return if n is not prime.

    Examples:
    >>> x_or_y(7, 34, 12)
    34
    >>> x_or_y(15, 8, 5)
    5
    """
    
    # Check if n is a prime number
    if n > 1:
        for i in range(2, n):
            if n % i == 0:
                # If n is divisible by any number other than 1 and itself, it's not prime
                return y
    else:
        # Numbers less than 2 are not considered prime
        return y
    
    # If n is prime, return x
    return x
