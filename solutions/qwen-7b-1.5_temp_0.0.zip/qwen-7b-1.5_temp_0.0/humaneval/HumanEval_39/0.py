

def prime_fib(n: int) -> int:
    """
    prime_fib returns the n-th number that is both a Fibonacci number and prime.
    
    Examples:
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    # Initialize variables for Fibonacci sequence and prime check
    fib_sequence = [0, 1]
    current_num = 2
    while len(fib_sequence) < n:
        # Generate next Fibonacci number
        next_num = fib_sequence[-1] + fib_sequence[-2]
        
        # Check if the number is prime
        if next_num > 1:
            is_prime = all(next_num % i != 0 for i in range(2, next_num))
            if is_prime:
                fib_sequence.append(next_num)
                if len(fib_sequence) == n:
                    return next_num
