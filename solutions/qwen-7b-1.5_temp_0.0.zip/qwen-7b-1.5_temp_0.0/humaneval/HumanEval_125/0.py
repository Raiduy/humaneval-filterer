
def split_words(txt):
    """
    Given a string of words, this function returns a list of words split on whitespace. If there are no whitespaces or commas,
    it returns the number of lowercase letters with odd alphabetical order. The order is determined by the ASCII value, where 'a' is 0 and 'z' is 25.

    Examples:
    >>> split_words("Hello world!")
    ➞ ["Hello", "world!"]
    >>> split_words("Hello,world!")
    ➞ ["Hello", "world!"]
    >>> split_words("abcdef")
    ➞ 3
    """

    # Check for whitespaces
    if not any(char.isspace() for char in txt):
        # Split on commas if no whitespaces
        if not any(char == "," for char in txt):
            # Count lowercase letters with odd ASCII values
            odd_letters = sum(1 for char in txt if char.islower() and (ord(char) - ord('a')) % 2 != 0)
            return odd_letters
        else:
            # Split on commas and return count
            return txt.split(",")
    else:
        # Split on whitespace and return list
        return txt.split()
