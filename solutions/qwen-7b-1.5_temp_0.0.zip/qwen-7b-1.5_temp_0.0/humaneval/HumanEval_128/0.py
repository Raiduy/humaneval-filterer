
def prod_signs(arr):
    """
    Given an array `arr` of integers, this function calculates the sum of the magnitudes of the numbers multiplied by the product of their signs (1, -1, or 0). If the array is empty, it returns None.

    Example usage:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    # Check if the array is empty
    if len(arr) == 0:
        return None

    # Initialize variables
    magnitude_sum = 0
    sign_product = 1

    # Iterate through the array
    for num in arr:
        # Magnitude is the absolute value of the number
        magnitude = abs(num)
        # Sign is determined by the sign of the number (positive, negative, or zero)
        sign = num // abs(num)

        # Multiply the magnitude by the current sign and update the sign product
        magnitude_sum += magnitude * sign
        sign_product *= sign

    # Return the result
    return magnitude_sum * sign_product

