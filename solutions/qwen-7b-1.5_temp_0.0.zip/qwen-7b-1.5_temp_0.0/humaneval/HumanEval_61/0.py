

def correct_bracketing(brackets: str) -> bool:
    """Check if every opening bracket in the given string has a corresponding closing bracket.

    Args:
        brackets (str): A string containing only '(' and ')'.

    Returns:
        bool: True if all brackets are properly closed, False otherwise.

    Examples:
        >>> correct_bracketing("(")
        False
        >>> correct_bracketing("()")
        True
        >>> correct_bracketing("(()())")
        True
        >>> correct_bracketing(")(()")
        False
    """
    stack = []
    
    for bracket in brackets:
        if bracket == "(":
            stack.append(bracket)
        elif bracket == ")":
            if not stack or stack.pop() != "(":
                return False
    
    return not stack  # If stack is not empty at the end, there are unmatched brackets
