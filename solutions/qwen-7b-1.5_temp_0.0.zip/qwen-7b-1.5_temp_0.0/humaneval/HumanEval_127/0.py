
def intersection(interval1, interval2):
    """Find the intersection of two intervals and check if the length is a prime number.

    Args:
        interval1 (tuple): A pair of integers representing the start and end of the first interval.
        interval2 (tuple): A pair of integers representing the start and end of the second interval.

    Returns:
        str: "YES" if the length of the intersection is a prime number, "NO" otherwise, and "NO" if there's no intersection.
    """
    # Check if intervals overlap
    if interval1[0] > interval2[1] or interval2[0] > interval1[1]:
        return "NO"

    # Calculate intersection
    start_inter = max(interval1[0], interval2[0])
    end_inter = min(interval1[1], interval2[1])
    intersection_length = end_inter - start_inter + 1

    # Check if intersection length is prime
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    if is_prime(intersection_length):
        return "YES"
    else:
        return "NO"
