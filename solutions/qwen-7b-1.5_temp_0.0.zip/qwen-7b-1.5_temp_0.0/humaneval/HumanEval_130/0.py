
def tri(n):
    """Generate the first n+1 numbers of the Tribonacci sequence."""
    # Initialize the sequence with the first three values
    sequence = [3, 1, 3]
    
    # Generate the remaining numbers using the recurrence relation
    for _ in range(2, n + 1):
        # Check if the index is odd or even
        if _ % 2 == 0:
            sequence.append(1 + _ // 2)
        else:
            sequence.append(sequence[_ - 1] + sequence[_ - 2] + sequence[_ - 3])

    return sequence
