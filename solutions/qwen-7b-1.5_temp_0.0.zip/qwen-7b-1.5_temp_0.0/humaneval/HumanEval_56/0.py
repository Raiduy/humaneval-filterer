

def correct_bracketing(brackets: str) -> bool:
    """Check if every opening bracket in the given string of '<' and '>' has a corresponding closing bracket.

    Args:
        brackets (str): A string containing '<' and '>', representing opening and closing brackets.

    Returns:
        bool: True if all brackets are properly paired, False otherwise.

    Examples:
        >>> correct_bracketing("<")
        False
        >>> correct_bracketing("<>")
        True
        >>> correct_bracketing("<<><>>")
        True
        >>> correct_bracketing("><<>")
        False

    """
    # Initialize an empty stack to keep track of open brackets
    stack = []

    # Iterate through the input string
    for char in brackets:
        if char == '<':
            # If '<', push it onto the stack
            stack.append(char)
        elif char == '>':
            # If '>', check if the stack is not empty and if top bracket is '<'
            if stack and stack[-1] == '<':
                # If so, pop the '<' from the stack
                stack.pop()
            else:
                # If the stack is empty or top bracket is not '<', return False
                return False

    # If the stack is empty at the end, all brackets are properly closed
    return not stack

