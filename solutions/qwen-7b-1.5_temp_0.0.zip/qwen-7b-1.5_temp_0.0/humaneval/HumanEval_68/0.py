
def pluck(arr):
    """
    Given an array representing a branch of a tree with non-negative integer nodes,
    this function plucks one of the nodes with the smallest even value and returns it in a list `[smallest_value, its index]`.

    If multiple nodes have the same smallest even value, it chooses the one with the smallest index.

    If there are no even values or the array is empty, it returns `[]`.

    Examples:
    1. Input: [4, 2, 3]
    Output: [2, 1]
    Explanation: 2 is the smallest even value and has the smallest index.

    2. Input: [1, 2, 3]
    Output: [2, 1]
    Explanation: 2 is the smallest even value and has the smallest index.

    3. Input: []
    Output: []
    
    4. Input: [5, 0, 3, 0, 4, 2]
    Output: [0, 1]
    Explanation: The first zero has the smallest value, but there are duplicates,
                 so we choose the one at index 1.

    Constraints:
    - 1 <= nodes.length <= 10000
    - 0 <= node.value

    """
    even_nodes = [node for node in arr if node % 2 == 0]
    
    if not even_nodes:
        return []

    smallest_even = min(even_nodes, key=lambda x: (x, arr.index(x)))
    return [smallest_even, arr.index(smallest_even)]
