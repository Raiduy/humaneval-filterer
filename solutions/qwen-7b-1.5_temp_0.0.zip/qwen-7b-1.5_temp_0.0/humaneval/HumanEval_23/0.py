

def strlen(string: str) -> int:
    """Return length of the input string
    
    Example usage:
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)
