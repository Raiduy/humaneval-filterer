

def largest_prime_factor(n: int) -> int:
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    
    Example usage:
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    # Start with the smallest prime candidate (2) and divide by it until the quotient is 1 or a prime
    i = 2
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
    # If n is still greater than 1, it's the last prime factor
    if n > 1:
        return n
    # If n is left as 1, it means there are no prime factors greater than 1
    else:
        return None
