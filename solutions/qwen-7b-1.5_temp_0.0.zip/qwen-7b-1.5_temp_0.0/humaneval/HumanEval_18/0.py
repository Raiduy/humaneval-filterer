

def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring can be found in the original string. Count overlaping cases.

    Args:
        string (str): The main string from which we want to count occurrences.
        substring (str): The substring we are looking for within the string.

    Returns:
        int: The number of times the substring appears in the string, including overlapping occurrences.

    Examples:
        >>> how_many_times('', 'a')
        0
        >>> how_many_times('aaa', 'a')
        3
        >>> how_many_times('aaaa', 'aa')
        3
    """
    count = 0
    index = 0
    while index < len(string):
        if string[index:].startswith(substring):
            count += 1
            index += len(substring)
        else:
            index += 1
    return count
