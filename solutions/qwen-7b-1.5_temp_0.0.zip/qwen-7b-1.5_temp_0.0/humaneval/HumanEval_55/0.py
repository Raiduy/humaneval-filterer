

def fib(n: int) -> int:
    """Return the n-th Fibonacci number.
    
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    # Initialize the first two Fibonacci numbers
    fib_sequence = [0, 1]
    
    # Calculate the Fibonacci sequence up to the given number
    if n >= 2:
        for _ in range(2, n + 1):
            fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
    
    # Return the nth Fibonacci number
    return fib_sequence[n]
