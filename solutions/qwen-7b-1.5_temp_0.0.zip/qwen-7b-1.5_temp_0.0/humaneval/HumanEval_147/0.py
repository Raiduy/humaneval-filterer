
def get_max_triples(n):
    """
    Given a positive integer n, create an integer array `a` of length n where `a[i] = i * i - i + 1`.
    Return the number of triples (a[i], a[j], a[k]) such that i < j < k and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
    Input: n = 5
    Output: 1
    Explanation:
    Array a: [1, 3, 7, 13, 21]
    Valid triple: (1, 7, 13)

    Args:
    n (int): Positive integer representing the length of the array a

    Returns:
    int: The number of valid triples in the array a
    """
    # Initialize an empty set to store the numbers whose sum is divisible by 3
    multiples_of_3 = set()

    # Calculate the array a
    a = [i * i - i + 1 for i in range(1, n+1)]

    # Iterate through the array and check if the sum of three consecutive elements is divisible by 3
    for i in range(len(a) - 2):
        # Sum of current, next, and last element
        sum_ = a[i] + a[i+1] + a[i+2]
        if sum_ % 3 == 0:
            multiples_of_3.add(sum_)

    # Count the number of unique triplets (since duplicates are possible due to overlapping indices)
    count = len(multiples_of_3)

    return count

