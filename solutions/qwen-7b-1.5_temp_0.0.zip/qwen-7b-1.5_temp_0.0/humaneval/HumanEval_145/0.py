
def order_by_points(nums):
    """
    Sorts a given list of integers in ascending order, considering the sum of their digits.
    If multiple items have the same sum of digits, they will be ordered by their index in the original list.

    Example usage:
    >>> order_by_points([1, 11, -1, -11, -12])
    [-1, -11, 1, -12, 11]
    >>> order_by_points([])
    []

    Args:
    nums (List[int]): The list of integers to be sorted.

    Returns:
    List[int]: The sorted list of integers.
    """
    # Calculate the sum of digits for each number and create a dictionary to store them along with indices
    digit_sums = {num: sum(int(digit) for digit in str(abs(num))) for num in nums}
    
    # Sort the dictionary based on the sums and then convert it back to a list
    sorted_nums = sorted(nums, key=digit_sums.get, reverse=False)
    
    # If the list is empty after sorting, return it as is
    return sorted_nums if sorted_nums else []
