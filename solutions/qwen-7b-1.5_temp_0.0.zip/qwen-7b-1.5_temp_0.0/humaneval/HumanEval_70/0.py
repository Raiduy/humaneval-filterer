
def strange_sort_list(lst):
    """
    Given a list of integers, return the list in a strange order. 
    Strange sorting means starting with the minimum value, then the maximum of the remaining integers, and so on.

    Examples:
    >>> strange_sort_list([1, 2, 3, 4])
    [1, 4, 2, 3]
    >>> strange_sort_list([5, 5, 5, 5])
    [5, 5, 5, 5]
    >>> strange_sort_list([])
    []
    """
    # Check if the list is empty
    if not lst:
        return lst

    # Sort the list in ascending order
    lst.sort()

    # Initialize an empty result list
    result = []

    # Iterate through the list in reverse order
    for i in range(len(lst)):
        # If it's the first element or there are no remaining elements, append it directly
        if i == 0 or i == len(lst) - 1:
            result.append(lst[i])
        # Otherwise, append the maximum of the remaining elements
        else:
            result.append(max(lst[:i]))

    return result
