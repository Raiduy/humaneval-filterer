
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    Example usage:
    >>> choose_num(12, 15)
    14
    >>> choose_num(13, 12)
    -1
    """
    
    # Iterate through the range from x to y (inclusive)
    for num in range(x, y+1):
        # Check if the number is even and within the range
        if num % 2 == 0 and x <= num <= y:
            # Return the biggest even number found
            return num
    
    # If no even number is found in the range, return -1
    return -1
