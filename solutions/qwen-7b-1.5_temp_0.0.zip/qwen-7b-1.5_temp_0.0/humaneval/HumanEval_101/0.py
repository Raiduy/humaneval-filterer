
def words_string(s):
    """
    Split a string of words separated by commas or spaces into an array.

    Args:
        s (str): The input string with words separated by commas or spaces.

    Returns:
        list: A list containing the individual words from the input string.

    Examples:
        >>> words_string("Hi, my name is John")
        ["Hi", "my", "name", "is", "John"]
        >>> words_string("One, two, three, four, five, six")
        ["One", "two", "three", "four", "five", "six"]
    """
    # Use either comma or space as the delimiter and split the string into words
    words = s.split(",") + s.split(" ")
    return words
