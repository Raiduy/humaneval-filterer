

def modp(n: int, p: int) -> int:
    """Return 2^n modulo p."""
    # Check for edge cases
    if n == 0:
        return 1
    elif n < 0 or p == 0:
        raise ValueError("n must be non-negative and p must not be zero")

    # Perform modular exponentiation using binary exponentiation
    result = 2 ** n % p

    # Ensure the result is within the range of the modulus (if necessary)
    return result
