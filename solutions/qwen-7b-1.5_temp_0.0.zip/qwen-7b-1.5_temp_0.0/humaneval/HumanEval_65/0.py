
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    """
    # Convert the integer to a string for easier manipulation
    x_str = str(x)
    
    # Calculate the effective shift taking into account negative shifts
    effective_shift = shift % len(x_str)
    
    # Shift the digits to the right
    shifted_str = x_str[effective_shift:] + x_str[:effective_shift]
    
    # If shift is greater than the number of digits, reverse the string
    if shift > len(x_str) - 1:
        shifted_str = shifted_str[::-1]
    
    # Return the shifted string as a result
    return shifted_str
