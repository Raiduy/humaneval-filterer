from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string representing multiple groups for nested parentheses separated by spaces.
    It calculates and returns the deepest level of nesting of parentheses for each group.

    Example:
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]

    Args:
        paren_string (str): The string with nested parentheses separated by spaces.

    Returns:
        List[int]: A list containing the deepest nesting level for each group.
    """
    result = []
    current_level = 0

    for char in paren_string:
        if char == '(':
            current_level += 1
        elif char == ')':
            current_level -= 1

        # If the level reaches zero, it's a new group, so append the previous level
        if current_level == 0:
            result.append(current_level)

    return result
