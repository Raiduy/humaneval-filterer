
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise

    Examples:
    >>> prime_length('Hello')
    True
    >>> prime_length('abcdcba')
    True
    >>> prime_length('kittens')
    True
    >>> prime_length('orange')
    False
    """
    
    # Check if the length is less than 2, which is not a prime number
    if len(string) < 2:
        return False
    
    # Prime numbers are greater than 1, so we start from 2 and check for divisibility
    for i in range(2, len(string) + 1):
        if len(string) % i == 0:
            return False
    
    # If no divisors found, the length is a prime number
    return True
