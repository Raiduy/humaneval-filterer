
def reverse_delete(s, c):
    """
    Task:
    Given two strings `s` and `c`, delete all characters in `s` that are equal to any character in `c`. Then check if the resulting string is a palindrome. A string is a palindrome if it reads the same backward as forward.

    Args:
    s (str): The input string to be modified
    c (str): The set of characters to be deleted from `s`

    Returns:
    tuple: A tuple containing the modified string and a boolean value indicating whether the string is a palindrome or not.
    Example:
    >>> reverse_delete("abcde", "ae")
    ('bcd', False)
    >>> reverse_delete("abcdef", "b")
    ('acdef', False)
    >>> reverse_delete("abcdedcba", "ab")
    ('cdedc', True)
    """
    # Remove characters from s that are in c
    s = ''.join(ch for ch in s if ch not in c)

    # Check if the modified string is a palindrome
    is_palindrome = s == s[::-1]

    return s, is_palindrome
