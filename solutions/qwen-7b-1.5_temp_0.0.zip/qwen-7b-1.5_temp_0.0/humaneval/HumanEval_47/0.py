

def median(l: list):
    """Return the median of elements in the list l.
    
    Example usage:
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    # Sort the list in ascending order
    l.sort()
    
    # Calculate the length of the list
    n = len(l)
    
    # Check if the list has an even or odd number of elements
    if n % 2 == 0:
        # If even, take the average of the middle two numbers
        mid_index = n // 2
        median_value = (l[mid_index - 1] + l[mid_index]) / 2
    else:
        # If odd, the middle number is the median
        mid_index = n // 2
        median_value = l[mid_index]
    
    return median_value
