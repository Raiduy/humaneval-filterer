

def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n
    
    Example usage:
    >>> largest_divisor(15)
    5
    """
    # Iterate from n-1 down to 1 and check for divisors
    for i in range(n-1, 0, -1):
        if n % i == 0:
            return i
    # If no divisor is found, the largest divisor smaller than n is n itself
    return n
