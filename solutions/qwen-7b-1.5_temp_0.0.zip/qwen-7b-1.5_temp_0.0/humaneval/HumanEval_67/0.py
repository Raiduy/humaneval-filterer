
def fruit_distribution(s, n):
    """
    This function takes a string `s` representing the number of apples and oranges and an integer `n`, which is the total number of fruits in the basket. It calculates and returns the number of mango fruits in the basket by subtracting the sum of apples and oranges from the total number of fruits.

    Example usage:
    ```python
    >>> fruit_distribution("5 apples and 6 oranges", 19)
    8
    >>> fruit_distribution("0 apples and 1 oranges", 3)
    2
    >>> fruit_distribution("2 apples and 3 oranges", 100)
    95
    >>> fruit_distribution("100 apples and 1 oranges", 120)
    19
    ```

    Args:
        s (str): A string containing the number of apples and oranges, separated by " and ".
        n (int): The total number of fruits in the basket.

    Returns:
        int: The number of mango fruits in the basket.
    """
    # Split the string into a list of counts
    counts = s.split(' and ')

    # Convert the counts to integers and sum them
    apples, oranges = map(int, counts[0].split())
    total_oranges_apples = apples + oranges

    # Calculate the number of mangoes
    mangoes = n - total_oranges_apples

    return mangoes
