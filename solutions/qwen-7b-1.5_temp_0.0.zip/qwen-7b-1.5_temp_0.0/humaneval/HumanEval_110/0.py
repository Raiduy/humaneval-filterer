
def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.

    Parameters:
    lst1 (list): The first list of numbers.
    lst2 (list): The second list of numbers.

    Returns:
    str: "YES" if it's possible to exchange elements between lst1 and lst2 to make all elements of lst1 even, otherwise "NO".

    Example:
    >>> exchange([1, 2, 3, 4], [1, 2, 3, 4])
    "YES"
    >>> exchange([1, 2, 3, 4], [1, 5, 3, 4])
    "NO"
    
    Assumption: The input lists will be non-empty.
    """
    # Check if both lists are non-empty
    if not lst1 or not lst2:
        return "Both lists must be non-empty."

    # Count the number of odd elements in lst1
    odd_count = sum(1 for num in lst1 if num % 2 != 0)

    # Check if there are any odd elements in lst1
    if odd_count > 0:
        # If there are odd elements, return "NO" as it's not possible to make all even
        return "NO"
    else:
        # If all elements in lst1 are even, return "YES"
        return "YES"
