
def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list that has the odd numbers in the Collatz sequence.

    The Collatz conjecture is a mathematical conjecture about a sequence where:
    - Start with any positive integer n.
    - If the previous term is even, the next term is one-half of the previous term.
    - If the previous term is odd, the next term is 3 times the previous term plus 1.
    - The conjecture states that the sequence will always reach 1.

    Note:
        - Collatz(1) is [1].
        - The returned list is sorted in increasing order.

    Example:
    >>> get_odd_collatz(5)
    [1, 5]
    """
    # Initialize an empty list to store odd numbers
    odd_numbers = []

    # Generate the Collatz sequence for the given number
    while n != 1:
        if n % 2 == 1:  # If odd, append to the list
            odd_numbers.append(n)
        n = (n // 2) if n % 2 == 0 else (3 * n + 1)  # Apply the Collatz rule

    # Sort the list in increasing order
    odd_numbers.sort()

    return odd_numbers
