
def sort_array(arr):
    """
    Sort an array of non-negative integers based on the number of ones in their binary representation in ascending order,
    and for similar numbers of ones, sort based on decimal value.

    Args:
        arr (list of int): The input array to be sorted.

    Returns:
        list: The sorted array.

    Examples:
        >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
        >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
        >>> sort_array([1, 0, 2, 3, 4]) == [0, 1, 2, 3, 4]
    """
    # Sort the array first by the count of ones in binary representation (using bin() and count('1'))
    # Then, sort it again by the decimal value (using the built-in `sorted` with key=lambda x: (x.count('1'), x))
    sorted_arr = sorted(arr, key=lambda x: (bin(x).count('1'), x))
    return sorted_arr
