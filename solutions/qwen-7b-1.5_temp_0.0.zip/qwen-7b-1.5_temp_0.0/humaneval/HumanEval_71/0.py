
def triangle_area(a, b, c):
    """
    Given the lengths of the three sides of a triangle, this function calculates the area and returns it rounded to 2 decimal points if the triangle is valid. If the sides do not form a valid triangle (i.e., the sum of any two sides is not greater than the third side), it returns -1.

    Valid triangle conditions:
    - The sum of any two sides must be greater than the third side.

    Example:
    >>> triangle_area(3, 4, 5)
    6.00
    >>> triangle_area(1, 2, 10)
    -1
    """

    # Check if the triangle conditions are met
    if a + b > c and a + c > b and b + c > a:
        # Calculate the semi-perimeter
        s = (a + b + c) / 2
        # Apply Heron's formula to find the area
        area = round((s * (s - a) * (s - b) * (s - c)) ** 0.5, 2)
    else:
        area = -1

    return area
