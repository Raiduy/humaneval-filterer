
def valid_date(date_string):
    """Validate a given date string according to the specified rules.

    Args:
        date_string (str): The date string in the format 'mm-dd-yyyy'.

    Returns:
        bool: True if the date is valid, False otherwise.
    """
    
    # Rule 1: Date string must not be empty
    if not date_string:
        return False
    
    # Rule 2: Check the number of days for each month
    month_days = {
        '01': 31,
        '03': 31,
        '05': 31,
        '07': 31,
        '08': 31,
        '10': 31,
        '12': 31,
        '04': 30,
        '06': 30,
        '09': 30,
        '11': 30,
        '02': 28 if date_string[:2] == '02' else 29  # February can have 28 or 29 days
    }
    
    # Rule 3: Check the month value (1-12)
    if int(date_string[:2]) < 1 or int(date_string[:2]) > 12:
        return False
    
    # Rule 4: Check the date format
    if len(date_string) != 8 or date_string[2] != '-' or date_string[5] != '-':
        return False
    
    # Split the date string into month, day, and year
    month, day, year = date_string.split('-')
    
    # Combine the month and day with the year to form a datetime object
    try:
        datetime_obj = datetime.strptime(f"{month}-{day}-{year}", "%m-%d-%Y")
    except ValueError:
        return False
    
    # Check if the day is within the allowed range for the given month
    if int(day) < 1 or int(day) > month_days[month]:
        return False
    
    # If all rules pass, the date is valid
    return True

