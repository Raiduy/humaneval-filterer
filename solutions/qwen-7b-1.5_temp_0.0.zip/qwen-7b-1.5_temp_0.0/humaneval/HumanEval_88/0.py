
def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting.
    The array will be sorted in ascending order if the sum of the first and last values is odd,
    or descending order if even.

    Note:
    * The original array is not modified.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    # Create a copy of the input array to avoid modifying the original
    sorted_array = array.copy()
    
    # Calculate the sum of the first and last values
    first_last_sum = sum(sorted_array[0:2])
    
    # Sort the array based on the sum
    if first_last_sum % 2 == 0:
        sorted_array.sort(reverse=True)
    else:
        sorted_array.sort()
    
    return sorted_array
