
def rounded_avg(n, m):
    """Calculate the average of integers from n through m, round to the nearest integer, and convert it to binary. If n > m, return -1.

    Args:
        n (int): The starting integer (inclusive).
        m (int): The ending integer (inclusive).

    Returns:
        str: The rounded binary representation of the average, or -1 if n > m.
    Example:
        >>> rounded_avg(1, 5)
        '0b11'
        >>> rounded_avg(7, 5)
        -1
        >>> rounded_avg(10, 20)
        '0b1111'
        >>> rounded_avg(20, 33)
        '0b11010'
    """
    if n > m:
        return -1
    else:
        avg = (n + m) // 2
        rounded_avg = format(avg, '0b')
        return rounded_avg
