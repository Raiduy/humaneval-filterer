
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    >>> vowels_count("hello")  # Test with a non-word input
    0
    >>> vowels_count("Python")  # Test with a common word
    3
    >>> vowels_count("sky")  # Test with 'y' not at the end
    1
    >>> vowels_count("zyxwvuts")  # Test with all vowels at the end
    7
    """

    vowels = {'a', 'e', 'i', 'o', 'u', 'y'}
    count = 0
    for char in s.lower():
        if char in vowels:
            count += 1
    return count


