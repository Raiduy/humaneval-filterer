
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []

    Args:
        x (list of int): A list of positive integers

    Returns:
        list: A sorted list containing elements without any even digits
    """
    # Filter out numbers with even digits
    filtered_list = [num for num in x if not any(digit % 2 == 0 for digit in str(num))]

    # Sort the filtered list
    sorted_list = sorted(filtered_list)

    return sorted_list
