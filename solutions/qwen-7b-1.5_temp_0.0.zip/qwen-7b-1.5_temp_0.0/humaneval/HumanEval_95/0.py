
def check_dict_case(dict):
    """
    Given a dictionary, this function checks if all keys are either in lower case or upper case. If all keys are either lowercase or uppercase, it returns True. If the dictionary is empty, it also returns False.

    Examples:
    >>> check_dict_case({"a": "apple", "b": "banana"})
    True
    >>> check_dict_case({"a": "apple", "A": "banana", "B": "banana"})
    False
    >>> check_dict_case({"a": "apple", 8: "banana", "a": "apple"})
    False
    >>> check_dict_case({"Name": "John", "Age": "36", "City": "Houston"})
    False
    >>> check_dict_case({"STATE": "NC", "ZIP": "12345"})
    True

    Args:
    dict (dict): The dictionary to be checked.

    Returns:
    bool: True if all keys are either lowercase or uppercase, False otherwise.
    """
    if not dict:  # Check if the dictionary is empty
        return False
    
    key_case = all(key.islower() for key in dict) or all(key.isupper() for key in dict)
    
    return key_case
