

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibonacci sequence, defined as:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).

    This function efficiently computes the n-th element of the FibFib sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    # Initialize the sequence with the first three values
    fibfib_sequence = [0, 0, 1]
    
    # Generate the rest of the sequence using recursion
    for i in range(3, n+1):
        fibfib_sequence.append(fibfib_sequence[i-1] + fibfib_sequence[i-2] + fibfib_sequence[i-3])
    
    # Return the n-th element
    return fibfib_sequence[n]
