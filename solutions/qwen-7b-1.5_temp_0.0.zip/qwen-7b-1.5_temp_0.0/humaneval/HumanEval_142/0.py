


def sum_squares(lst):
    """
    This function takes a list of integers and modifies the entries based on their index. It squares an integer if its index is a multiple of 3 and cubes it if the index is a multiple of 4 but not a multiple of 3. Entries with non-multiple of 3 or 4 indices remain unchanged. Finally, it returns the sum of all modified and unmodified entries in the list.

    Examples:
    - For lst = [1,2,3], the output should be 6
    - For lst = [], the output should be 0
    - For lst = [-1,-5,2,-1,-5], the output should be -126

    Args:
    lst (list): A list of integers

    Returns:
    int: The sum of all modified and unmodified entries in the list
    """
    result = 0
    for i, num in enumerate(lst):
        # Check if index is a multiple of 3 or 4
        if i % 3 == 0:
            # Square if multiple of 3
            result += num ** 2
        elif i % 4 == 0 and i % 3 != 0:  # Cube if multiple of 4 but not 3
            result += num ** 3
    return result

