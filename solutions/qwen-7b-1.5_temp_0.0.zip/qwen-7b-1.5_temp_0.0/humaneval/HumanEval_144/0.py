
def simplify(x, n):
    """
    Simplify the expression `x * n` by checking if the product is a whole number. Both `x` and `n` are represented as fractions in the form `<numerator>/<denominator>`, with positive whole numbers for both numerator and denominator.

    Args:
        x (str): The first fraction, e.g., "1/5".
        n (str): The second fraction, e.g., "5/1".

    Returns:
        bool: True if the product of `x` and `n` evaluates to a whole number, False otherwise.
    
    Examples:
        >>> simplify("1/5", "5/1")
        True
        >>> simplify("1/6", "2/1")
        False
        >>> simplify("7/10", "10/2")
        False
    """
    # Convert the fractions to integers (multiplying by the least common denominator)
    x_num, x_den = map(int, x.split('/'))
    n_num, n_den = map(int, n.split('/'))

    # Calculate the product and check if it's a whole number
    product = x_num * n_num // math.gcd(x_den, n_den)

    return product == int(product)
