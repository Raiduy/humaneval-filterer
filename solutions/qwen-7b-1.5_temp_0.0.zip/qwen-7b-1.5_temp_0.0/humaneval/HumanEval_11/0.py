from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings `a` and `b` consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return the result as a string.

    Example:
    >>> string_xor('010', '110')
    '100'

    """
    # Convert the strings to integers for XOR operation
    xor_result = int(a, 2) ^ int(b, 2)
    
    # Convert the XOR result back to a string
    return format(xor_result, '0len(a)bits')  # Ensure the length of the result is same as the input strings
