

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    """
    # Check if the string is empty, in that case, it's already a palindrome
    if not string:
        return string

    # Find the longest postfix that is a palindrome
    for i in range(len(string) - 1, -1, -1):
        if is_palindrome(string[i:]):
            palindrome_suffix = string[i:]
            break

    # Calculate the prefix before the palindrome suffix
    prefix_length = len(string) - len(palindrome_suffix)

    # Append the reversed prefix to the end of the string
    return string + string[:prefix_length][::-1]

