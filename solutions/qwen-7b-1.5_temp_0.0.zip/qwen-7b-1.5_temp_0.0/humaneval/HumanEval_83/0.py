
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.

    This function calculates the number of integers between 10^(n-1) and 10^n - 1 (inclusive)
    where the first or last digit is either 1 or 9. Since we are looking for both starting and ending with 1,
    we double the count for numbers like 123, 214, etc.

    Algorithm:
    1. Calculate the range of n-digit numbers: from 10^(n-1) to 10^n - 1.
    2. For each number in the range, check if its first or last digit is 1.
    3. If it is, increment the count by 1.
    4. Return the count.

    Example:
    >>> starts_one_ends(3)
    6
    >>> starts_one_ends(4)
    12
    """

    # Calculate the range of n-digit numbers
    start = 10**(n-1)
    end = 10^n - 1

    # Count the numbers that start or end with 1
    count = 0
    for num in range(start, end + 1):
        # Check if the first or last digit is 1
        if num % 10 == 1 or (num // 10 ** (n-1)) % 10 == 1:
            count += 1

    # Since we counted both starting and ending with 1, we double the count
    count *= 2

    return count
