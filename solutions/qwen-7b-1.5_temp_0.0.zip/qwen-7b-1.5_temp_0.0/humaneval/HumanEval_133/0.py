

def sum_squares(lst):
    """Given a list of numbers, calculate the sum of the squared ceiling values of each number.
    Examples:
    - For lst = [1,2,3], the output is 14
    - For lst = [1,4,9], the output is 98
    - For lst = [1,3,5,7], the output is 84
    - For lst = [1.4,4.2,0], the output is 29
    - For lst = [-2.4,1,1], the output is 6

    Args:
    lst (list): A list of numbers

    Returns:
    int: The sum of the squared ceiling values of the elements in the list.
    """
    # Initialize the sum variable
    total_sum = 0

    # Iterate over the list and round each element to the ceiling
    for num in lst:
        # Use the math.ceil function to get the ceiling value and square it
        squared ceil = round(num ** 2)
        total_sum += squared ceil

    # Return the final sum
    return total_sum
