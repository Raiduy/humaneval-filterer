
def right_angle_triangle(a, b, c):
    """
    Given the lengths of the three sides of a triangle, this function determines if they form a right-angled triangle. A right-angled triangle is one where one angle measures 90 degrees.

    Args:
        a (float): Length of the first side of the triangle.
        b (float): Length of the second side.
        c (float): Length of the third side.

    Returns:
        bool: True if the sides form a right-angled triangle, False otherwise.

    Example:
        >>> right_angle_triangle(3, 4, 5)
        True
        >>> right_angle_triangle(1, 2, 3)
        False
    """
    # Using the Pythagorean theorem to check for a right angle
    # The theorem states that in a right-angled triangle, the square of the hypotenuse (the longest side) is equal to the sum of the squares of the other two sides
    if a**2 + b**2 == c**2:
        return True
    else:
        return False
