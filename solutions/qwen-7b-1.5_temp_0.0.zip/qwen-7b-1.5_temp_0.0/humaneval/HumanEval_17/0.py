from typing import List


def parse_music(music_string: str) -> List[int]:
    """Parse a string representing musical notes in a special ASCII format and return a list of integers indicating the number of beats for each note.

    Legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    Example usage:
    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]

    Args:
        music_string (str): The input string of musical notes.

    Returns:
        List[int]: A list of integers representing the number of beats for each note.
    """
    beats = []
    current_beat = 0
    for char in music_string:
        if char == 'o':
            current_beat += 4
        elif char == 'o|':
            current_beat += 2
        elif char == '.|':
            current_beat += 1
        beats.append(current_beat)
        current_beat = 0  # Reset current beat for next note
    # Include the last beat, if any
    if current_beat > 0:
        beats.append(current_beat)
    
    return beats
