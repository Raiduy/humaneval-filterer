

def unique(l: list):
    """Return sorted unique elements in a list

    Example:
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]

    Args:
    l (list): The input list to remove duplicates from and sort

    Returns:
    list: A new list containing only the unique elements in the original list, sorted in ascending order
    """
    # Remove duplicates using set and then convert back to list
    unique_list = list(set(l))
    # Sort the list
    unique_list.sort()
    return unique_list
