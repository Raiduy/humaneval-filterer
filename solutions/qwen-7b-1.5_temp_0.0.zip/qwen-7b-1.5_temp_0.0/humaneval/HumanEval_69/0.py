
def search(lst):
    """
    Given a non-empty list of positive integers, find the greatest integer that is greater than zero and has a frequency greater than or equal to its value. If no such integer exists, return -1.

    Examples:
    >>> search([4, 1, 2, 2, 3, 1]) == 2
    >>> search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
    >>> search([5, 5, 4, 4, 4]) == -1
    """

    def frequency(int_num):
        return lst.count(int_num)

    max_freq_int = -1
    for num in lst:
        if num > 0 and frequency(num) >= num:
            max_freq_int = num

    return max_freq_int if max_freq_int != 0 else -1
