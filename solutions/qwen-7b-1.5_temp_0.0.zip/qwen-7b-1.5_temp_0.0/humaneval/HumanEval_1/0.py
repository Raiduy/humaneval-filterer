from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses. The goal is to separate these groups into separate strings and return the list of those.

    Balanced groups (with each open brace properly closed) are separated, and they are not nested within each other. Any spaces in the input string are ignored.

    Example:
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    
    # Remove spaces from the input string
    paren_string = paren_string.replace(" ", "")
    
    # Initialize an empty list to store the separated groups
    groups = []
    
    # Create a stack to keep track of opening braces
    stack = []
    
    # Iterate through the characters in the string
    for char in paren_string:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack:  # If no open brace, it's an error
                return []
            else:
                # Pop the last open brace from the stack
                stack.pop()
                # If the stack is empty, a new group starts
                if not stack:
                    groups.append(''.join(stack))
    
    # If there are any remaining open braces, it's an error
    if stack:
        return []

    return groups
