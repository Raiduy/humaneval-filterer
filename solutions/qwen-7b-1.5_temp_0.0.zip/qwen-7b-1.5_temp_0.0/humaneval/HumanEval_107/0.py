
def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:
    Input: 3
    Output: (1, 2)
    Explanation:
    Integer palindromes are 1, 2, 3. One of them is even (2) and two are odd (1, 3).

    Example 2:
    Input: 12
    Output: (4, 6)
    Explanation:
    Integer palindromes are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. Four are even (4, 6, 8, 11) and six are odd (1, 3, 5, 7, 9, 11).

    Note:
    1. 1 <= n <= 10^3
    2. The returned tuple contains the count of even and odd integer palindromes respectively.
    """

    # Function to check if a number is palindrome
    def is_palindrome(num):
        return str(num) == str(num)[::-1]

    # Initialize counts for even and odd palindromes
    even_count = 0
    odd_count = 0

    # Iterate through numbers from 1 to n
    for i in range(1, n+1):
        # Check if the number is even and palindrome
        if i % 2 == 0 and is_palindrome(i):
            even_count += 1
        # Check if the number is odd and palindrome
        elif i % 2 != 0 and is_palindrome(i):
            odd_count += 1

    return even_count, odd_count
