

def remove_vowels(text):
    """
    remove_vowels is a function that takes a string and returns a string without vowels. It ignores spaces and punctuation.

    Args:
        text (str): The input string to remove vowels from.

    Returns:
        str: The string with vowels removed, preserving spaces and punctuation.

    Examples:
        >>> remove_vowels('')
        ''
        >>> remove_vowels("abcdef\nghijklm")
        'bcdf\nghjklm'
        >>> remove_vowels('abcdef')
        'bcdf'
        >>> remove_vowels('aaaaa')
        ''
        >>> remove_vowels('aaBAA')
        'B'
        >>> remove_vowels('zbcd')
        'zbcd'

    """
    vowels = "aeiouAEIOU"
    result = ""
    for char in text:
        if char.isalpha() and char not in vowels:
            result += char
    return result
