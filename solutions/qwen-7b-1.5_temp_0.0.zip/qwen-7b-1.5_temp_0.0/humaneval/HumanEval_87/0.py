
def get_row(lst, x):
    """
    This function takes a 2-dimensional data represented as a nested list and an integer `x`, and returns a list of tuples containing the coordinates (row, column) for the occurrences of `x` in the list. The coordinates are sorted first by rows in ascending order and then by columns in descending order.

    Examples:
    >>> get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1)
    [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]

    >>> get_row([], 1)
    []

    >>> get_row([[], [1], [1, 2, 3]], 3)
    [(2, 2)]
    """
    result = []
    for i, row in enumerate(lst):
        if x in row:
            for j, value in enumerate(row):
                if value == x:
                    result.append((i, j))
    result.sort(key=lambda coord: (coord[0], -coord[1]))  # Sort by row and column in descending order
    return result
