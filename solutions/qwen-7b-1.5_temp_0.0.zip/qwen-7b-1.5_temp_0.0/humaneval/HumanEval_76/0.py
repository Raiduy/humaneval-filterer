
def is_simple_power(x, n):
    """Check if a number x is a simple power of n
    
    Args:
        x (int): The number to be tested
        n (int): The base for comparison

    Returns:
        bool: True if x is a simple power of n (n raised to an integer power equal to x), False otherwise
    """
    
    # Check if n is 1, as any number raised to the power of 1 is the number itself
    if n == 1:
        return x == 1
    
    # Calculate the integer part of the logarithm base n of x
    power = int(math.log(x, n))
    
    # If the power is an exact match (no decimal part) and x is divisible by n^power, it's a simple power
    if power.is_integer() and x % (n ** power) == 0:
        return True
    else:
        return False
