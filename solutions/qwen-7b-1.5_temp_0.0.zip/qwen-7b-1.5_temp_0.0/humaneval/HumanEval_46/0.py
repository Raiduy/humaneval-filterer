

def fib4(n: int):
    if n <= 0:
        return 0  # Base cases: fib4(0) and fib4(1) are both 0
    elif n == 1:
        return 0  # fib4(1) is also 0
    elif n == 2:
        return 2  # fib4(2) is 2
    elif n % 4 == 0:  # If n is divisible by 4, the sum is even
        fib_sum = (fib4(n-1) + fib4(n-2) + fib4(n-3)) // 2
    else:  # If n is odd, the sum is odd
        fib_sum = fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4)

    return fib_sum
