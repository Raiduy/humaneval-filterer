
def decimal_to_binary(decimal):
    """Convert a decimal number to binary format with extra 'db' characters at the beginning and end."""
    binary = bin(decimal)[2:]  # Convert decimal to binary using built-in bin function, remove '0b' prefix
    formatted_binary = 'db' + binary + 'db'  # Append 'db' before and after the binary string
    return formatted_binary
