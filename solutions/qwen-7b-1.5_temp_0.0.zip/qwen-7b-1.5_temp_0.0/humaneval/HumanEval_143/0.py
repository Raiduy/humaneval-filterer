
def words_in_sentence(sentence):
    """
    Given a string representing a sentence, this function returns a string containing the words whose lengths are prime numbers. The order of the words remains the same as in the original sentence.

    Example:
    >>> words_in_sentence("This is a test")
    "is"
    >>> words_in_sentence("lets go for swimming")
    "go for"

    Constraints:
    - 1 <= len(sentence) <= 100
    - sentence contains only letters

    **Function Implementation:**
    1. First, we define a helper function `is_prime(n)` to check if a number is prime.
    2. Iterate through each word in the `sentence`.
    3. For each word, check its length using `is_prime()` and if it's prime, add it to the result string.
    4. Return the final result string.

    """
    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    words = sentence.split()
    result = []
    for word in words:
        if is_prime(len(word)):
            result.append(word)

    return ' '.join(result)
