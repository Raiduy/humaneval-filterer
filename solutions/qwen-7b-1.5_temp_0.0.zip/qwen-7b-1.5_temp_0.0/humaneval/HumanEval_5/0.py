from typing import List


def intersperse(numbers: List[int], delimiter: int) -> List[int]:
    """Insert a number 'delimiter' between every two consecutive elements of the input list `numbers'"""
    result = []
    for num in numbers:
        result.append(num)
        if len(result) > 1:
            result.append(delimiter)
    return result
