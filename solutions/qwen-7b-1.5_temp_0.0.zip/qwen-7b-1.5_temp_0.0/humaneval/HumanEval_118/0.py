
def get_closest_vowel(word):
    """Find the closest vowel between two consonants from the right side of the word (case sensitive)."""
    vowels = "aeiouAEIOU"  # Define the set of vowels
    
    # Convert the word to lowercase for case-insensitive comparison
    word = word.lower()
    
    # Check if the word is empty or has only one letter
    if len(word) < 2:
        return ""

    # Iterate through the word from the last character to the second
    for i in range(len(word) - 1, 0, -1):
        # Skip vowels at the beginning and end
        if word[i] in vowels:
            # Check if it's between two consonants
            if all(c not in vowels for c in word[i+1:]):
                # Return the found vowel
                return word[i]
    
    # If no vowel meets the condition, return an empty string
    return ""
