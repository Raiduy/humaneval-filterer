

def change_base(x: int, base: int) -> str:
    """Change numerical base of input number x to base.
    Return string representation after the conversion.
    Base numbers must be less than 10.
    Examples:
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    # Check if the base is less than 10
    if base < 10:
        # Convert the number to the desired base
        converted_number = format(x, f'{base}')
        return converted_number
    else:
        raise ValueError("Base numbers must be less than 10.")
