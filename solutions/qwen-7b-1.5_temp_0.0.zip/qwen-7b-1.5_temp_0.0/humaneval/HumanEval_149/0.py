
def sorted_list_sum(lst):
    """
    This function takes a list of strings as input, removes strings with odd lengths, sorts the remaining list based on the length of each word, and then sorts it alphabetically if lengths are equal. It ensures that the final list is returned in sorted order.

    Parameters:
    lst (list of str): A list containing strings, no arrays of numbers allowed.

    Returns:
    list of str: A sorted list of strings, following the specified rules.

    Examples:
    >>> assert sorted_list_sum(["aa", "a", "aaa"]) == ["aa"]
    >>> assert sorted_list_sum(["ab", "a", "aaa", "cd"]) == ["ab", "cd"]

    """
    # Remove strings with odd lengths
    filtered_lst = [word for word in lst if len(word) % 2 == 0]

    # Sort the list first by length, then alphabetically
    sorted_lst = sorted(filtered_lst, key=lambda x: (len(x), x))

    return sorted_lst
