
def file_name_check(file_name):
    """Create a function which checks the validity of a file's name based on certain criteria.

    Args:
        file_name (str): A string representing a file's name.

    Returns:
        str: 'Yes' if the file name is valid, and 'No' otherwise.
    
    Validations:
    1. No more than three digits ('0'-'9').
    2. Exactly one dot ('.').
    3. Substring before the dot should not be empty and start with a Latin alphabet letter.
    4. Substring after the dot should be one of ['txt', 'exe', 'dll'].

    Examples:
    >>> file_name_check("example.txt")
    'Yes'
    >>> file_name_check("1example.dll")
    'No'
    >>> file_name_check("invalid_file.jpg")
    'No' (contains non-allowed extension)

    """
    # Check for more than three digits
    if len(file_name) > 3 and any(char.isdigit() for char in file_name):
        return 'No'

    # Check for exactly one dot
    if '.' not in file_name:
        return 'No'

    # Split the file name into before and after the dot
    parts = file_name.split('.')
    if len(parts) != 2 or parts[0] == '':
        return 'No'

    # Check the first part (before the dot) for a valid letter
    if not parts[0].isalpha():
        return 'No'

    # Check the second part (after the dot) for allowed extensions
    allowed_extensions = ['txt', 'exe', 'dll']
    if parts[1] not in allowed_extensions:
        return 'No'

    # If all checks pass, return 'Yes'
    return 'Yes'
