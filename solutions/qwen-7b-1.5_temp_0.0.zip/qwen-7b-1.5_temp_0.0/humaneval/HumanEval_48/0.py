

def is_palindrome(text: str) -> bool:
    """
    Checks if given string is a palindrome
    
    Examples:
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    # Remove any non-alphanumeric characters and convert to lowercase for comparison
    cleaned_text = ''.join(c.lower() for c in text if c.isalnum())
    
    # Check if the cleaned text is equal to its reverse
    return cleaned_text == cleaned_text[::-1]
