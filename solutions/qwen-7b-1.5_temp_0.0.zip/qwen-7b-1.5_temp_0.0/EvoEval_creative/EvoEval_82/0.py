def zodiac_element(birthdays):
    """
    Given a list of dates representing birthdays, this function returns a dictionary with the elements as keys and the number of birthdays corresponding to each element as values.
    
    Parameters:
    birthdays (list): List of dates in the format YYYY-MM-DD, representing birthdays.

    Returns:
    dict or None: A dictionary containing the elements as keys and their count, or None if the birthdays list is empty.
    
    Example:
    >>> zodiac_element(["2000-03-21", "2001-05-21", "2002-08-23", "2003-02-19"]) == {'Fire': 1, 'Air': 1, 'Earth': 1, 'Water': 1}
    >>> zodiac_element(["2000-06-21", "2001-07-23"]) == {'Water': 1, 'Fire': 1}
    >>> zodiac_element([]) == None
    """
    if not birthdays:
        return None
    element_counts = {}
    for birthday in birthdays:
        month_day = datetime.strptime(birthday, '%Y-%m-%d').month.day
        zodiac_sign = determine_zodiac_sign(month_day)
        if zodiac_sign:
            element = get_element_for_zodiac_sign(zodiac_sign)
            if element in element_counts:
                element_counts[element] += 1
            else:
                element_counts[element] = 1
    return element_counts