def string_fairy_tale(lst):
    """Given a list of strings, where each string consists of a mix of letters and numbers, return a list.
    Each element of the output will be a fairy tale inspired story based on the input string.

    Args:
        lst (list): A list of strings containing letters and numbers.

    Returns:
        list: A list of fairy tale stories, one for each string in the input.

    Examples:
        >>> string_fairy_tale(['Dragon123', 'Unicorn45'])
        ["Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Dragon123' who was known for telling 3 tales a day",
         "Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Unicorn45' who was known for telling 2 tales a day"]

        >>> string_fairy_tale(['Mermaid7890', 'Elf111'])
        ["Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Mermaid7890' who was known for telling 4 tales a day",
         "Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Elf111' who was known for telling 3 tales a day"]
    """
    fairy_tales = []
    for (i, string) in enumerate(lst):
        name = string[:string.index(' ')].lower()
        digit_count = len(string[string.index(' '):])
        story = f"Once upon a time, in a kingdom far away, lived a magical creature with the name of '{name}' who was known for telling {digit_count} tales a day."
        fairy_tales.append(story)
    return fairy_tales