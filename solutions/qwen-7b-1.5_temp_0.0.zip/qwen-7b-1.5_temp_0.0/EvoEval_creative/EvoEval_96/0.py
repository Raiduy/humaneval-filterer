def get_magic_indices(lst):
    """
    This function takes a list of integers as input and returns a list of "magic" indices. A magic index is one where the value at that index is a multiple of the index and the product of its digits equals the index.

    Parameters:
    lst (list): A list of integers

    Returns:
    list: A list of magic indices, sorted in ascending order. If there are no magic indices, an empty list is returned.

    Example:
    >>> lst = [0, 7, -6, 12, -20, 5, -7]
    >>> get_magic_indices(lst)
    [0, 5]

    Explanation:
    - At index 0, the value 0 is a multiple of 0 and the product of its digits (0) equals 0.
    - At index 5, the value 5 is a multiple of 5 and the product of its digits (5) equals 5.

    Negative values are treated as positive ones.

    Note: Indices are 0-based.
    """
    magic_indices = []
    for (i, num) in enumerate(lst):
        num = abs(num)
        if num % i == 0 and sum((int(digit) ** i for digit in str(num))) == i:
            magic_indices.append(i)
    magic_indices.sort()
    return magic_indices