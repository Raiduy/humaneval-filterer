def recipe_converter(recipe, conversion_factor):
    """
    Convert a recipe by multiplying the quantities for each ingredient by the given conversion factor.

    Parameters:
    recipe (dict): A dictionary representing a recipe with keys as ingredients and values as quantities for one serving.
    conversion_factor (int): A positive integer representing the number of servings required.

    Returns:
    dict: A new dictionary with the quantities of each ingredient multiplied by the conversion factor.

    Examples:
    >>> recipe_converter({"flour": 500, "sugar": 200, "eggs": 3}, 2)
    {'flour': 1000, 'sugar': 400, 'eggs': 6}
    >>> recipe_converter({"milk": 250, "chocolate": 75, "butter": 50}, 3)
    {'milk': 750, 'chocolate': 225, 'butter': 150}
    """
    converted_recipe = {}
    for (ingredient, quantity) in recipe.items():
        converted_quantity = quantity * conversion_factor
        converted_recipe[ingredient] = converted_quantity
    return converted_recipe