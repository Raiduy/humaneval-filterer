def wizard_inventory(inventory_logs):
    """
    A function to simulate the inventory of a wizard's magical items cart
    
    Parameters:
    inventory_logs (list): List of dictionaries, each containing 'item' and 'quantity' keys
    
    Returns:
    dict: Final inventory with items and their quantities, excluding those with quantity <= 0
    """
    final_inventory = {}
    for log in inventory_logs:
        item = log['item']
        quantity = log['quantity']
        if quantity > 0:
            final_inventory[item] = final_inventory.get(item, 0) + quantity
        elif quantity < 0:
            final_inventory[item] = max(0, final_inventory.get(item, 0) - quantity)
    return {item: quantity for (item, quantity) in final_inventory.items() if quantity > 0}