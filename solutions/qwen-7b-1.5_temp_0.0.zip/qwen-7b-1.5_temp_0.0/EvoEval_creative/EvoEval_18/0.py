def magical_seven(n: int):
    """
    magical_seven returns the n-th number that is a multiple of 7 and its digits sum up to 7.

    >>> magical_seven(1)
    7
    >>> magical_seven(2)
    70
    >>> magical_seven(3)
    133
    >>> magical_seven(4)
    322
    >>> magical_seven(5)
    511
    """

    def digit_sum(num):
        return sum((int(digit) for digit in str(num)))

    def is_magical(num):
        return num % 7 == 0 and digit_sum(num) == 7
    for i in range(1, n + 1):
        if is_magical(i):
            return i