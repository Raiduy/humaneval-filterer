from typing import List

def count_animals(animal_string: str) -> List[int]:
    """ 
    Parse a string representing animals and their sounds in a special ASCII format and return a list of integers
    indicating the number of times each animal made a sound.

    Legend:
    - 'C' for Cat, makes sound 'meow'
    - 'D' for Dog, makes sound 'woof'
    - 'B' for Bird, makes sound 'chirp'

    Example:
    >>> count_animals('C||| D|| B| C| B||| D|||')
    [3, 2, 1, 1, 3]

    Function logic:
    1. Initialize an empty list to store counts.
    2. Iterate over the string, splitting on spaces to get individual animal-sound pairs.
    3. Check if the pair is valid (starts with 'C', 'D', or 'B') and hasn't appeared twice.
    4. If valid, increment the count for that animal and append it to the list.
    5. Keep track of the total number of animals seen so far.
    6. Stop processing after 5 animals have been counted (including invalid ones).
    """
    counts = []
    animal_count = 0
    total_animals = 0
    for pair in animal_string.split():
        if pair[0] in ['C', 'D', 'B']:
            if pair in counts and counts.count(pair) > 1:
                continue
            counts.append(1)
            total_animals += 1
            if total_animals >= 5:
                break
    return counts