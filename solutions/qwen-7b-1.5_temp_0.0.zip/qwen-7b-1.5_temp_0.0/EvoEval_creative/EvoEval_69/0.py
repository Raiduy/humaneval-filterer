def magicTrick(cards, magicNumber):
    """
    In this card trick problem, we need to find two cards whose product equals the given magic number. Given a list of card numbers and a magic number, we'll check if such pairs exist and return their indices if found, or "No magic today" if not.

    Args:
        cards (list): A list of integers representing the numbers on the cards.
        magicNumber (int): A positive integer representing the target product for the selected cards.

    Returns:
        tuple or str: If a pair of cards exists, returns a tuple with the indices (smaller index, larger index). Otherwise, returns "No magic today".

    Examples:
        >>> magicTrick([2, 3, 4, 5], 20)
        (2, 3)
        >>> magicTrick([1, 1, 1, 1], 1)
        (0, 1)
        >>> magicTrick([1, 2, 3, 4], 10)
        "No magic today"

    Assumptions:
        - The input list `cards` will not be empty.
        - The magic number `magicNumber` will be a positive integer.

    """
    for (i, card) in enumerate(cards):
        if magicNumber % card == 0:
            for j in range(i + 1, len(cards)):
                if magicNumber // card == cards[j]:
                    return (i, j)
    return 'No magic today'