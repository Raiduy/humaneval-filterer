def prime_cipher(s: str) -> str:
    """
    Given a string `s`, this function replaces each lowercase letter in the string with the corresponding prime number based on their position in the alphabet. It only operates on lowercase letters and leaves non-alphabetic characters unchanged.

    Notes:
    - The 1st prime number is 2, the 2nd is 3, the 3rd is 5, and so on.
    - The function is case sensitive.

    Examples:
    >>> prime_cipher("hello")
    '1911373747'
    >>> prime_cipher("world")
    '834761377'
    >>> prime_cipher("Python!")
    'P9771194743!'
    >>> prime_cipher("12345")
    '12345'
    >>> prime_cipher("abc")
    '235'

    Args:
        s (str): The input string to be processed.

    Returns:
        str: The modified string with prime numbers replacing lowercase letters.
    """
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]
    result = ''
    for char in s.lower():
        if char.isalpha():
            index = ord(char) - ord('a') + 1
            if 0 <= index < len(primes):
                result += str(primes[index])
            else:
                result += char
        else:
            result += char
    return result