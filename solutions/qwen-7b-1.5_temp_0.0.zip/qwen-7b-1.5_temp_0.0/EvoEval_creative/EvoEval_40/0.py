def potion_mixing(potions, target):
    """
    A function to mix potions to reach a target power level
    
    Parameters:
    potions (list[str]): List of potions, each represented as a string with power level
    target (int): The desired power level to reach
    
    Returns:
    list[str]: A list of potions to mix or an empty list if not possible
    """
    sorted_potions = sorted(potions, key=lambda x: (-int(x.split()[1]), x))
    required_potions = []
    current_power = 0
    for potion in sorted_potions:
        power_level = int(potion.split()[1])
        current_power += power_level
        if current_power == target:
            break
        if current_power > target:
            remaining_power = target - current_power
            if remaining_power < power_level:
                required_potions.pop()
            else:
                break
    return required_potions