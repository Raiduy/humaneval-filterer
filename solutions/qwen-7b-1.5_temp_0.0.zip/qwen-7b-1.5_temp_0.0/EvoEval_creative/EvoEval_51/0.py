def alien_encoding(string, list_of_alphabets):
    """Write a function that takes a string and a list of alphabets. The function should return a string where 
    each character in the input string is replaced by the corresponding character in the list of alphabets.
    
    The first character of the string should be replaced by the first character of the list, the second 
    character of the string should be replaced by the second character of the list, and so on. If the list 
    of alphabets is shorter than the string, loop back to the beginning of the list.
    
    If the string is empty, return an empty string. If the list is empty, return the original string.
    
    Examples:
    
    assert alien_encoding('Hello',['a', 'b', 'c', 'd', 'e']) == 'abcde'
    assert alien_encoding('World',['z', 'y', 'x', 'w', 'v', 'u']) == 'zyxwv'
    assert alien_encoding('HelloWorld',['a', 'b', 'c']) == 'abcabcabca'
    assert alien_encoding('', ['a', 'b', 'c']) == ''
    assert alien_encoding('Hello', []) == 'Hello'
    """
    if not list_of_alphabets:
        return string
    if not string:
        return ''
    encoded_string = ''
    for (index, char) in enumerate(string):
        if index < len(list_of_alphabets):
            encoded_string += list_of_alphabets[index]
        else:
            encoded_string += list_of_alphabets[index % len(list_of_alphabets)]
    return encoded_string