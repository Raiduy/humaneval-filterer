def word_spiral(arr):
    """Create a function which takes in a 2D array of characters and returns a 
    string which represents the words in the array read in a clockwise spiral starting
    from the top left corner. If the array is empty, return an empty string. 

    Examples:
    >>> assert word_spiral([['h','i','!'],['b','y','e']])
    'hi!eyb'
    >>> assert word_spiral([['l','o','v','e'],['i','s','i','n'],['t','h','e','a'],['i','r', '!','!!']])
    'lovena!!!ritisieh'
    >>> assert word_spiral([])
    ''
    """
    if not arr:
        return ''
    n = len(arr)
    m = len(arr[0])
    spiral = []
    top = 0
    bottom = n - 1
    left = 0
    right = m - 1
    direction = 'right'
    while top <= bottom and left <= right:
        row = []
        for j in range(left, right + 1):
            row.append(arr[top][j])
        spiral.append(''.join(row))
        if direction == 'right':
            top += 1
        elif direction == 'down':
            bottom -= 1
        elif direction == 'left':
            left += 1
        else:
            right -= 1
        if top > bottom or left > right:
            direction = {'right': 'down', 'down': 'left', 'left': 'up', 'up': 'right'}[direction]
    result = ' '.join(spiral)
    return result