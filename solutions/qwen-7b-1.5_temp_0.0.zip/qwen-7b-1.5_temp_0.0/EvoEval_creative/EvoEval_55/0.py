def treasure_map(message, shift):
    encrypted_message = ''
    for char in message:
        if char.isalpha():
            if char.islower():
                shifted_char = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            elif char.isupper():
                shifted_char = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
            else:
                shifted_char = char
        else:
            shifted_char = char
        encrypted_message += shifted_char
    return encrypted_message