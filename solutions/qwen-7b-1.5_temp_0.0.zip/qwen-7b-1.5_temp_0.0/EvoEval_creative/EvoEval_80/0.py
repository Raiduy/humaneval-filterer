def adventure_game(map, instructions):
    """
    You are building a text-based adventure game. The game map is a 2D list, where 'S' represents the start, 'E' represents the end,
    '.' represents a path, and 'X' represents a wall. A player can move in four directions: up, down, left, right.

    Given a game map and a list of instructions, return the path the player takes. If the player moves into a wall or the edge of
    the map, they should stay in their current position. If the player finds the end 'E', the game is won and no further instructions
    are processed. If the list of instructions ends before the player finds 'E', return the player's path so far.

    The player's path should be returned as a list of tuples, where each tuple represents the player's position (row, column) after
    each move.

    If the player never moves from the start 'S', return [(start_row, start_column)].

    Examples:
    >>> adventure_game([
        ['S', '.', '.'],
        ['X', 'X', '.'],
        ['.', 'X', 'E']
    ], ['right', 'right', 'down', 'down', 'right'])
    ➞ [(0, 0), (0, 1), (0, 2), (1, 2), (2, 2)]

    >>> adventure_game([
        ['.', '.', 'S'],
        ['.', 'X', 'X'],
        ['E', 'X', '.']
    ], ['left', 'left', 'up'])
    ➞ [(0, 2), (0, 1), (0, 0), (0, 0)]

    >>> adventure_game([
        ['S', 'X', 'E']
    ], ['right', 'right'])
    ➞ [(0, 0)]
    """
    (start_row, start_column) = (None, None)
    path = []
    for (i, row) in enumerate(map):
        for (j, cell) in enumerate(row):
            if cell == 'S':
                start_row = i
                start_column = j
                break
    if start_row is None:
        return [(start_row, start_column)]
    for instruction in instructions:
        (direction, _) = instruction.split()
        if direction == 'up':
            new_row = start_row - 1
            if 0 <= new_row < len(map) and map[new_row][start_column] != 'X':
                path.append((new_row, start_column))
                start_row = new_row
        elif direction == 'down':
            new_row = start_row + 1
            if 0 <= new_row < len(map) and map[new_row][start_column] != 'X':
                path.append((new_row, start_column))
                start_row = new_row
        elif direction == 'left':
            new_col = start_column - 1
            if 0 <= new_col < len(row) and row[start_row][new_col] != 'X':
                path.append((start_row, new_col))
                start_column = new_col
        elif direction == 'right':
            new_col = start_column + 1
            if 0 <= new_col < len(row) and row[start_row][new_col] != 'X':
                path.append((start_row, new_col))
                start_column = new_col
    if start_row is not None and map[start_row][start_column] == 'E':
        return path
    else:
        return path[:len(path) - 1]