def crossword_validator(grid: list, words: list) -> bool:
    """
    Determine if all the words from a provided list of words can be found in a 2D grid representing a square crossword puzzle.

    Parameters:
    grid: list of list of char (N x N) - Each cell contains a lowercase letter.
    words: list of str - Each string is a lowercase word.

    Returns:
    boolean - True if all words are found in the grid, False otherwise.

    Example:
    >>> crossword_validator([['c', 'a', 't'], ['d', 'o', 'g'], ['d', 'o', 'p']], ['cat', 'dog', 'pop'])
    False
    >>> crossword_validator([['c', 'a', 't'], ['d', 'o', 'g'], ['d', 'o', 'p']], ['cdd', 'dog', 'pod'])
    True
    """
    if len(grid) != len(grid[0]):
        raise ValueError('Grid must be a square (N x N).')
    for word in words:
        for direction in ['horizontal', 'vertical']:
            word_set = set(word.lower())
            for row in grid:
                if direction == 'horizontal':
                    for (i, char) in enumerate(row):
                        if char in word_set and (i == 0 or row[i - 1] != word[i - 1].lower()) and (i == len(row) - 1 or row[i + 1] != word[i + 1].lower()):
                            if word[i] != row[i]:
                                break
                        else:
                            word_set.remove(char)
                            if not word_set:
                                break
                else:
                    for (j, char) in enumerate(zip(*grid)):
                        if char in word_set and (j == 0 or zip(*grid)[j - 1][1] != word[j - 1].lower()) and (j == len(grid[0]) - 1 or zip(*grid)[j + 1][1] != word[j + 1].lower()):
                            if word[j] != char[1]:
                                break
                        else:
                            word_set.remove(char)
                            if not word_set:
                                break
                    if not word_set:
                        break
    return not any(word_set)