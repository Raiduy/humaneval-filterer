def transform_string(s):
    """
    Given a string `s`, perform the following operations:
    
    1. Swap the case of all alphabetic characters in odd indices.
    2. Replace all vowels (case-insensitive) with the next vowel in the sequence (a->e, e->i, i->o, o->u, u->a).
    3. Replace all consonants (case-insensitive) with the preceding consonant (b->z, c->b, ..., z->y, b->z)
    
    Assume that all characters in the input string `s` are either alphabetic characters or spaces.
    Ignore spaces while performing operations but maintain their position in the string.
    
    Example:
    >>> transform_string('Hello World')
    'GIkKu VUqKc'
    >>> transform_string('Python')
    'NXsGuM'
    >>> transform_string('Java')
    'HEtE'
    """
    result = ''
    for (i, char) in enumerate(s):
        if char.isalpha():
            if i % 2 != 0:
                char = char.lower() if char.isupper() else char.upper()
            else:
                vowels = 'aeiou'
                if char.lower() in vowels:
                    next_vowel_index = vowels.index(char.lower()) + 1
                    if next_vowel_index > len(vowels):
                        next_vowel_index = 0
                    next_vowel = vowels[next_vowel_index]
                    char = next_vowel
                elif char.isalpha() and char.lower() not in vowels:
                    prev_consonant_index = (vowels.index('a') - 1) % len(vowels)
                    prev_consonant = vowels[prev_consonant_index]
                    char = prev_consonant
        result += char
    return result