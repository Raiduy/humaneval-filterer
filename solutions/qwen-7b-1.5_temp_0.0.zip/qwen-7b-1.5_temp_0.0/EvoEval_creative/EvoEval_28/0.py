def calculate_progressive_tax(income: float, deductions=0) -> float:
    """
    Calculate the tax for a given income and deductions according to a set of progressive tax rates with deductions:

    - Tax-free income up to $10,000
    - 15% tax on income between $10,000 and $35,000 (inclusive)
    - 25% tax on income between $35,000 and $80,000 (inclusive)
    - 30% tax on income over $130,000

    Deductions are applied as follows:
        - First $1000 deducted at 1:1 ratio
        - Next $2000 deducted at 2:1 ratio
        - Any deduction over $3000 deducted at 3:1 ratio

    The function returns the calculated tax as a float.

    Examples:
    >>> calculate_progressive_tax(12000, 500)
    225.0
    >>> calculate_progressive_tax(55000, 2500)
    7750.0
    >>> calculate_progressive_tax(120000, 5000)
    23700.0
    """
    taxable_income = income - deductions
    deductions_amounts = [1000, 2000, 0]
    deductions_ratios = [1, 2, 3]
    for (i, amount) in enumerate(deductions_amounts):
        if taxable_income >= amount:
            taxable_income -= amount * deductions_ratios[i]
            break
    tax_rates = [0, 0.15, 0.25, 0.3]
    tax = 0
    for (i, income_range) in enumerate(range(10000, 130001, 25000)):
        if taxable_income >= income_range:
            tax += taxable_income * (tax_rates[i] - tax_rates[i - 1])
            break
    return tax