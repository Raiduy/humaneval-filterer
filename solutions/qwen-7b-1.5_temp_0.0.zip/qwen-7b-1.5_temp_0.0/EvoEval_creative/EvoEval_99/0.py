def musical_chairs(n, rounds, music):
    """A playful program that simulates a game of musical chairs.

    The program represents the game with a list of n players. Each round,
    the music plays for a certain number of seconds. When the music stops,
    the player at the current position gets eliminated. The next round starts
    from the next position. If the end of the list is reached, start again
    from the beginning. The function returns all the players left after all
    rounds are finished.

    Parameters:
    - n (int): The number of players.
    - rounds (list): A list of integers representing the number of seconds each round lasts.
    - music (int): The speed of music, i.e., the number of positions advanced per second.

    Assumptions:
    - At the start of each round, the position is at the start of the list.

    Examples:
    - musical_chairs(5, [2, 3, 4], 1)
    - musical_chairs(10, [1, 2, 3, 4, 5], 1)

    """
    players = list(range(1, n + 1))
    eliminated = []
    for (round_num, duration) in enumerate(rounds, start=1):
        remaining_positions = n - music * duration
        for _ in range(duration):
            players = players[1:] + [players[0]]
            if len(players) == remaining_positions:
                eliminated.append(players.pop())
        players = [1] + players
    return eliminated