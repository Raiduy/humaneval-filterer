def wizard_battle(dragon_hp: int, wizards: list) -> str:
    """Return the name of the wizard who defeated the dragon, given the dragon's hit points (HP) and an ordered list with the wizard's name and their magic power."""

    def attack(wizard: tuple) -> None:
        wizard_power = wizard[1]
        dragon_hp -= wizard_power
        if dragon_hp <= 0:
            return f'The {wizard[0]} defeated the dragon!'
    winner = 'The dragon won!'
    for wizard in wizards:
        if dragon_hp > 0:
            attack(wizard)
            if dragon_hp == 0:
                winner = wizard[0]
                break
    return winner