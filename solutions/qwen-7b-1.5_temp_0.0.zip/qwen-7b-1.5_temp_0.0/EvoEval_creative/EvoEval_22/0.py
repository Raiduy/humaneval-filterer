def galactic_travel(t, v):
    """Given the time (t) in years and average velocity (v) in km/s, calculate the distance traveled in light years in a galaxy far, far away.
    Assume that 1 light year is approximately 9.461 x 10^12 km.

    Args:
        t (float): Time in years
        v (float): Average velocity in km/s

    Returns:
        float: Distance traveled in light years
    """
    velocity_ly_per_year = v / 365.25
    distance_ly = t * velocity_ly_per_year
    return distance_ly