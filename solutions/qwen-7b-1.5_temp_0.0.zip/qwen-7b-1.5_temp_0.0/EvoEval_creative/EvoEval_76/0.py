def create_pyramid(lst):
    """
    Given a list of positive integers, create a pyramid using '#' characters. Build the pyramid from the bottom up, with each level having a string length equal to the sum of its corresponding integers. Return the pyramid as a list of strings.

    Examples:
    >>> create_pyramid([3, 2, 1])
    ['#', '##', '###']
    >>> create_pyramid([5, 4, 2])
    ['##', '####', '#####']
    >>> create_pyramid([])
    []
    """
    if not lst:
        return []
    pyramid = []
    current_level = 0
    for num in lst[::-1]:
        level_length = current_level * num
        current_level += 1
        pyramid.append('#' * level_length)
    return pyramid