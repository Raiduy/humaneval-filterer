from typing import List, Tuple

def find_path(maze: List[List[int]], start: Tuple[int], end: Tuple[int]) -> List[Tuple[int]]:
    """Returns the shortest path from start to end in a maze represented by a 2D array.

    The maze is a 2D array where 0s represent walls and 1s represent open paths. The start and end points 
    are tuples representing coordinates in the 2D array. The function should return a list of points 
    representing the shortest path from start to end. If no path is possible, return an empty list.

    Example usage:
    >>> maze = [[1,0,1,1,1], [1,0,1,0,1], [1,1,1,0,1], [1,0,0,0,1], [1,1,1,1,1]]
    >>> start = (0,0)
    >>> end = (4, 4)
    >>> find_path(maze, start, end)
    [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (4, 1), (4, 2), (4, 3), (4, 4)]

    >>> maze = [[1,0,1], [0,0,1], [1,1,1]]
    >>> start = (0,0)
    >>> end = (2, 2)
    >>> find_path(maze, start, end)
    []

    """
    visited = {start: 0}
    path = [start]

    def explore_cell(current细胞坐标):
        if current细胞坐标 == end:
            return True
        (row, col) = current细胞坐标
        for (dr, dc) in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
            (new_row, new_col) = (row + dr, col + dc)
            if 0 <= new_row < len(maze) and 0 <= new_col < len(maze[0]) and (maze[new_row][new_col] == 1) and ((new_row, new_col) not in visited):
                visited[new_row, new_col] = visited[current细胞坐标] + 1
                path.append((new_row, new_col))
                if explore_cell((new_row, new_col)):
                    return True
                visited.pop((new_row, new_col))
        return False
    if explore_cell(start):
        return path[::-1]
    else:
        return []