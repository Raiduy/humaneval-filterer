def cooking_challenge(ingredient_dict):
    if not ingredient_dict:
        return []
    sorted_items = sorted(ingredient_dict.items(), key=lambda x: (-x[1], x[0]))
    result = [(ingredient, recipe) for (ingredient, recipe) in sorted_items]
    return result