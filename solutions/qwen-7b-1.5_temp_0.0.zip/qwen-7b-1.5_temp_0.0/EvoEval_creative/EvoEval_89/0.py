def space_invaders(aliens, ray):
    """
    A Space Invader Game
    --------------------

    In this space invader game, we have an array of aliens with their positions represented by positive integers. The `space_invaders` function takes two parameters:
    - `aliens`: A list of integers representing the positions of the aliens.
    - `ray`: An integer representing the position to aim the ray gun.

    The function returns a new list containing the remaining alien positions after the ray gun has been fired, considering the destruction pattern described below:

    1. The ray gun destroys the alien at the given position `ray`.
    2. It also destroys any alien immediately to the left or right of the aimed position.

    However, if the alien's position is odd, the ray gun will only destroy it if it's directly aimed at it (not just adjacent).

    Examples:
    >>> assert space_invaders([1, 2, 3, 4, 5], 3) == [1, 5]
    >>> assert space_invaders([1, 2, 4, 5, 6], 4) == [1, 2, 5, 6]
    >>> assert space_invaders([2, 3, 5, 6, 7, 9, 10], 6) == [2, 3, 5, 7, 9, 10]
    >>> assert space_invaders([1, 2, 3, 5, 6, 7], 1) == [3, 5, 6, 7]

    Args:
        aliens (list[int]): List of alien positions.
        ray (int): Position to aim the ray gun.

    Returns:
        list[int]: Remaining alien positions after the ray gun has been fired.
    """
    remaining.aliens = []
    for alien in aliens:
        if alien == ray or alien % 2 != 0:
            continue
        if alien - 1 >= 0 and aliens[alien - 1] == ray:
            remaining.aliens.append(alien - 1)
        if alien + 1 < len(aliens) and aliens[alien + 1] == ray:
            remaining.aliens.append(alien + 1)
        remaining.aliens.append(alien)
    return remaining.aliens