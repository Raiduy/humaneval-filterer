def str_to_morse_code(s):
    """
    Given a string containing only lowercase letters a-z and spaces, this function converts the string into Morse Code.
    Each letter is separated by a space and each word is separated by a slash ( / ).

    Morse Code format:
    - 'a' to 'z' are represented by '.-' (dot followed by hyphen)
    - Space is represented by ' '
    - Words are separated by '/'

    Examples:
    str_to_morse_code("hello world") returns ".... . .-.. .-.. --- / .-- --- .-. .-.. -.."
    str_to_morse_code("morse code") returns "-- --- .-. ... . / -.-. --- -.. ."
    str_to_morse_code("") returns ""

    Args:
    s (str): The input string to convert to Morse Code

    Returns:
    str: The Morse Code representation of the input string
    """
    if not s:
        return ''
    morse_code = ''
    words = s.split()
    for word in words:
        morse_word = ''
        for letter in word.lower():
            if letter in morse_code_dict:
                morse_word += morse_code_dict[letter] + ' '
        morse_code += morse_word.strip() + '/'
    morse_code = morse_code[:-1]
    return morse_code