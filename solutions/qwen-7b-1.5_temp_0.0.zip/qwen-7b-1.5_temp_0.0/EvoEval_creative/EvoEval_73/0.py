def treasure_hunt(grid, bag_capacity):
    import math

    def collect_chests(chests, capacity):
        trips = 0
        while chests:
            num_chests_to_take = min(capacity, chests)
            for i in range(num_chests_to_take):
                chest_index = chests.pop(0)
                if grid[chest_index[0]][chest_index[1]] == 1:
                    trips += 1
            if chests:
                num_chests_to_take = len(chests)
                for chest in chests:
                    chest_index = chest
                    trips += 1
                    grid[chest_index[0]][chest_index[1]] = 0
        return trips
    if not all((len(row) == len(set(row)) for row in grid)):
        raise ValueError('All chambers must have the same number of chests')
    num_chests = sum((sum(row) for row in grid))
    trips = math.ceil(num_chests / bag_capacity)
    return trips