def playlist_shuffle(playlist: list, seed: int) -> list:
    """Return a new playlist order based on a numerical seed.

    Given a list of song titles (strings) as 'playlist' and an odd integer 'seed',
    implement an algorithm to shuffle the playlist to create a new order.
    The same seed should always produce the same shuffled playlist.

    The shuffling algorithm works as follows:
    - Skip songs containing "Rock" during swapping.
    - Start at index 0 and swap with the element at the index `seed % playlist_length`.
    - Update the seed for every index using the formula: seed = (seed * 16807) % 2147483647.
    - Continue this process until the end of the list.

    Example usage:
    >>> playlist_shuffle(["One More Time", "Around the World", "Harder Better Faster Stronger", "Technologic", "Robot Rock"], 7)
    ['Harder Better Faster Stronger', 'One More Time', 'Technologic', 'Around the World', 'Robot Rock']
    >>> playlist_shuffle(["Song 2", "Parklife", "Country House", "Song 2", "Girls & Boys"], 3)
    ['Song 2', 'Parklife', 'Girls & Boys', 'Song 2', 'Country House']

    Args:
        playlist (list): List of song titles to shuffle.
        seed (int): An odd integer used for shuffling.

    Returns:
        list: The shuffled playlist.
    """
    shuffled_playlist = playlist.copy()
    for (i, title) in enumerate(playlist):
        if 'Rock' in title:
            continue
        seed_index = (seed + i) % len(playlist)
        (shuffled_playlist[i], shuffled_playlist[seed_index]) = (shuffled_playlist[seed_index], shuffled_playlist[i])
    seed = seed * 16807 % 2147483647
    return shuffled_playlist