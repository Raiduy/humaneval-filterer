def cipher_mapping(s, cipher):
    """Given a string 's' and a mapping dictionary 'cipher', this function replaces characters in 's'
    with their corresponding values from 'cipher'. Characters not found in 'cipher' are left unchanged.
    If 's' is an empty string, the function returns an empty string.

    Examples:
    >>> cipher_mapping("hello world", {'h':'y', 'e':'u', 'l':'q', 'o':'p', 'w':'j', 'r':'f', 'd':'m'})
    'yuqqp jpfqm'
    >>> cipher_mapping("apple pie", {'a':'z', 'p':'r', 'l':'m', 'e':'s', 'i':'u'})
    'zrrms rus'
    >>> cipher_mapping("simple test", {})
    'simple test'
    >>> cipher_mapping("good day", {'g':'b', 'o':'a', 'd':'t', 'a':'g', 'y':'h'})
    'baat tgh'
    """
    new_string = ''
    for char in s:
        if char in cipher:
            new_string += cipher[char]
        else:
            new_string += char
    return new_string