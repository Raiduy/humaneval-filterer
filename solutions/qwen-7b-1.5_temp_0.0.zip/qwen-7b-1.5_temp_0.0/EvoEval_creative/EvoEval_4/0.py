from typing import List


def candles_relight(candles: List[int]) -> int:
    """
    Given a list of integers representing the heights of candles, this function calculates the number of candles that can be lit. 
    A candle at position `i` is lit if it is taller than all the candles before it, and the first candle is always assumed to be lit.

    Args:
        candles (List[int]): A list of integers representing candle heights.

    Returns:
        int: The number of candles that can be lit.

    Examples:
        >>> candles_relight([3, 2, 1, 3, 2, 4])
        2
        >>> candles_relight([1, 2, 3, 4, 5])
        5
        >>> candles_relight([])
        0
    """
    if not candles:
        return 0
    lit_candles = 1
    for i in range(1, len(candles)):
        if candles[i] > candles[i - 1]:
            lit_candles += 1
    return lit_candles