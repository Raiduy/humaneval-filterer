def spell_casting(strings):
    """
    A wizard's function to sort the words in each spell based on their length, preserving original order for equal lengths
    
    Parameters:
    strings (list): List of spell strings, where each spell is a sequence of words separated by a single space and without punctuation marks

    Returns:
    list: A new list with each spell's words sorted according to the specified rule
    """
    sorted_spells = []
    for spell in strings:
        sorted_words = sorted(spell.split(), key=len)
        sorted_spell = ' '.join(sorted_words)
        sorted_spells.append(sorted_spell)
    return sorted_spells