def alien_language_translator(english_word: str) -> str:
    """
    Translate an English word into the alien language.

    Args:
        english_word (str): The input English word to be translated.

    Returns:
        str: The translated alien language word.

    Examples:
        >>> alien_language_translator("hello")
        '#%((?'
        >>> alien_language_translator("alien")
        '+($%='
    """
    return ''.join((alien_symbols[letter] for letter in english_word))