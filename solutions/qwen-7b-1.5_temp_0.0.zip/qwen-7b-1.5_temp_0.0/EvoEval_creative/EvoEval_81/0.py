def alien_language(word_list, alien_dictionary):
    """
    An alien civilization's alphabet dictionary: `alien_dictionary`

    Given a sorted list of words in the alien language and the alien dictionary, determine if the list is correctly sorted in ascending order.

    **Input:**
    - word_list: List of strings representing words in the alien language (sorted according to the alien dictionary)
    - alien_dictionary: A string containing all lowercase letters from 'a' to 'z' in some non-English order

    **Output:**
    - "CORRECT" if the word list is sorted correctly
    - "INCORRECT" if the word list is not sorted correctly
    - "CORRECT" if the word list is empty

    **Examples:**
    ```python
    >>> alien_language(['cat', 'dog', 'elephant'], 'abcdefghijklmnopqrstuvwxyz')
    "CORRECT"

    >>> alien_language(['apple', 'banana', 'kiwi'], 'zyxwvutsrqponmlkjihgfedcba')
    "INCORRECT"

    >>> alien_language(['bee', 'ant', 'cat', 'dog'], 'bacdefghijklmnopqrstuvwxyz')
    "CORRECT"

    >>> alien_language([], 'bacdefghijklmnopqrstuvwxyz')
    "CORRECT"
    ```
    """
    if not word_list:
        return 'CORRECT'
    first_letter = word_list[0][0]
    last_letter = alien_dictionary[-1]
    if first_letter != last_letter:
        return 'INCORRECT'
    for i in range(1, len(word_list)):
        current_word = word_list[i]
        next_word = word_list[i - 1]
        if alien_dictionary.index(current_word[0]) > alien_dictionary.index(next_word[0]):
            return 'INCORRECT'
    return 'CORRECT'