def asciiArt(n, s):
    """Create a 2D ASCII art with `n` copies of each character in the given string `s`, surrounded by '*' characters in a 'U' shape.

    Parameters:
    - `n` (int): A positive integer determining the size of the art (number of copies per row and column).
    - `s` (str): A string containing alphanumeric characters with at least one character.

    Returns:
    A 2D string representing the ASCII art with '*' frames.

    Examples:
    ```python
    >>> asciiArt(1, "abc")
    '*abc*'
                 '*abc*'
                 '*****'

    >>> asciiArt(2, "xy")
    '*xxyy*'
                 '*xxyy*'
                 '******'

    >>> asciiArt(3, "123")
    '*111222333*'
                 '*111222333*'
                 '*111222333*'
                 '***********'
    ```

    Note:
    - This function assumes that `n` is a positive integer and `s` is not empty.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError('n must be a positive integer.')
    if not isinstance(s, str) or not s:
        raise ValueError('s must contain at least one alphanumeric character.')
    rows = n * 2 + 1
    cols = len(s)
    art = [['*' for _ in range(cols)] for _ in range(rows)]
    for (i, char) in enumerate(s):
        art[i // n][i % n] = char * n
    for row in art:
        (row[0], row[-1]) = ('*', '*')
    return '\n'.join((''.join(row) for row in art))