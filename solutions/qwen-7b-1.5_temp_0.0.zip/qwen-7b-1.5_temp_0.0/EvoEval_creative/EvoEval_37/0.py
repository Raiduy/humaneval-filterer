def string_transform(s):
    """Transform a string according to the given rules:
    - Replace vowels with the next vowel in the sequence.
    - Replace consonants with the next consonant in the alphabet (wrapping 'z' to 'b').
    - Preserve punctuation, spaces, and digits.

    Original case is preserved.

    Example:
    >>> string_transform("Hello, World!")
    'Jimmu, Xusmf!'
    >>> string_transform("Coding is Fun!")
    'Dufoph jt Gap!'
    """
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    transformed_sentence = ''
    for char in s:
        if char.isalpha():
            if char.lower() in vowels:
                index = vowels.index(char.lower()) + 1
                if index > len(vowels) - 1:
                    index = 0
                transformed_char = vowels[index]
            else:
                index = consonants.index(char.lower()) + 1
                transformed_char = consonants[index % len(consonants)]
        else:
            transformed_char = char
        transformed_sentence += transformed_char
    return transformed_sentence