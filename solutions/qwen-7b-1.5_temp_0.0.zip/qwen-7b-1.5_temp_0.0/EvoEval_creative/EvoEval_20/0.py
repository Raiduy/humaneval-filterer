def generate_pattern(n: int):
    """
    Given an integer 'n', this function returns a list of strings representing patterns. 
    The pattern consists of numbers from 1 to n in ascending order, then descending back to 1, separated by commas.

    Parameters:
    n (int): The input integer for the pattern generation.

    Returns:
    list[str]: A list containing the pattern strings.

    Examples:
    >>> generate_pattern(3)
    ['1', '1,2', '1,2,3', '3,2,1', '2,1', '1']
    
    >>> generate_pattern(0)
    []
    """
    if n <= 0:
        return []
    patterns = []
    for i in range(1, n + 1):
        pattern = f'{i},'
        for j in range(i - 1, 0, -1):
            pattern += str(j) + ','
        pattern = pattern[:-1]
        patterns.append(pattern)
    return patterns