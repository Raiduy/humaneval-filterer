def princess_rescue(coord, grid):
    """
    A princess is trapped in a 2D grid filled with monsters. You are a brave warrior tasked with saving the princess.
    Your starting point is at the top-left corner of the grid and you need to reach the princess who is at a certain coordinate in the grid.
    However, there are monsters in some parts of the grid. You can move either to the right or down.
    You need to find out the minimum number of moves to reach the princess without encountering a monster. 
    If it's impossible to reach the princess without encountering a monster, return -1.

    The grid is represented as a 2D list. Each element in the list is either 0 (open space) or 1 (monster). 
    The princess's coordinate is represented as a tuple (row, column).

    Examples:
    - coord = (2,2), grid = [[0,0,0],[0,1,0],[0,0,0]] -> Output: 4
    - coord = (3,3), grid = [[0,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,0]] -> Output: 6
    - coord = (3,3), grid = [[0,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]] -> Output: -1
    - coord = (1,1), grid = [[0,0],[1,0]] -> Output: 2
    - coord = (2,2), grid = [[0,1,0],[0,1,0],[0,0,0]] -> Output: 4

    Args:
        coord (tuple): The coordinates of the princess in the grid (row, column)
        grid (list): A 2D list representing the grid with 0 for open spaces and 1 for monsters

    Returns:
        int: The minimum number of moves required to reach the princess if possible, -1 otherwise
    """
    (rows, cols) = (len(grid), len(grid[0]))
    visited = set()
    queue = [(0, 0)]
    while queue:
        (row, col) = queue.pop(0)
        if row == coord[0] and col == coord[1]:
            return min((row + col for (row, col) in visited))
        if grid[row][col] == 1:
            return -1
        if (row + 1, col) not in visited and 0 <= row + 1 < rows:
            queue.append((row + 1, col))
            visited.add((row + 1, col))
        if (row, col + 1) not in visited and 0 <= col + 1 < cols:
            queue.append((row, col + 1))
            visited.add((row, col + 1))
    return -1