
from typing import List

def find_rarest_element(elems: List[str]) -> str:
    """ Find the rarest element in a list of strings. If there are multiple rarest elements, return the one that appears first. 
    If the list is empty, return None.

    Example usage:
    >>> find_rarest_element(['apple', 'banana', 'apple', 'orange', 'banana', 'orange', 'apple'])
    'banana'
    >>> find_rarest_element(['cat', 'dog', 'bird', 'cat', 'dog', 'cat'])
    'bird'
    >>> find_rarest_element([])
    None

    """
    if not elems:
        return None
    element_count = {}
    for elem in elems:
        if elem in element_count:
            element_count[elem] += 1
        else:
            element_count[elem] = 1
    rarest_elements = [k for (k, v) in element_count.items() if v == min(element_count.values())]
    return rarest_elements[0]