def meal_calculator(customers, meals):
    """
    Calculate the total calories consumed by each customer based on the meals they have consumed.

    Parameters:
    customers (list): A list of customer names.
    meals (dict): A dictionary where the keys are customer names and the values are lists of meals. Each meal is a dictionary with 'dish' and 'calories' keys.

    Returns:
    dict: A dictionary containing customer names as keys and their total calories consumed as values. If a customer's name is not in the meals dictionary, it assumes 0 calories.

    Example:
    >>> meal_calculator(['Alice', 'Bob', 'Charlie'], 
                        {'Alice': [{'dish': 'Pizza', 'calories': 300}, {'dish': 'Burger', 'calories': 500}], 
                         'Bob': [{'dish': 'Salad', 'calories': 100}], 
                         'Charlie': [{'dish': 'Fries', 'calories': 200}, {'dish': 'Burger', 'calories': 500}, {'dish': 'Ice Cream', 'calories': 250}]})
    {'Alice': 800, 'Bob': 100, 'Charlie': 950}

    >>> meal_calculator(['Tom', 'Jerry'], 
                        {'Tom': [{'dish': 'Pizza', 'calories': 300}, {'dish': 'Burger', 'calories': 500}], 
                         'Jerry': [{'dish': 'Fries', 'calories': 200}]})
    {'Tom': 800, 'Jerry': 200}
    """
    total_calories = {}
    for (customer, meals_data) in meals.items():
        if meals_data:
            total_calories[customer] = sum([meal['calories'] for meal in meals_data])
        else:
            total_calories[customer] = 0
    return total_calories