def evaluate_poker_hand(hand: list) -> int:
    """
    Evaluate a poker hand and return its score based on the given point scoring rules.

    Args:
        hand (list): A list of 5 strings representing cards in the format 'value+suit' (e.g., ['10H', '10D', '10C', '2S', '2D']). The suit is ignored in this game.

    Returns:
        int: The score of the poker hand, following the given point system:
            - Pair: Value of the card
            - Triple: Double the value of the card
            - Four of a Kind: Triple the value of the card
            - Five of a Kind: Quadruple the value of the card
            - No pairs, triples, or fours: 0

    Examples:
        >>> evaluate_poker_hand(['5H', '5D', '5S', '9C', '9D'])  # Five of a Kind
        19
        >>> evaluate_poker_hand(['AS', '2H', '3S', '4H', '5D'])  # No pairs, triples, or fours
        0
        >>> evaluate_poker_hand(['KH', 'KD', 'KS', 'KC', 'KA'])  # Full House (Four of a Kind)
        52

    """
    card_values = set((card[0] for card in hand))
    score = 0
    for value in card_values:
        count = hand.count(value)
        if count == 2:
            score += value
        elif count == 3:
            score += 2 * value
        elif count == 4:
            score += 3 * value
    if len(card_values) == 1:
        score += 4 * card_values.pop()
    return score