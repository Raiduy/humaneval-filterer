def find_star_map(lst, star):
    """
    This function takes a 2-dimensional list (nested list) representing a star map and an integer 'star'. It finds the coordinates of the specified star in the map, considering that each row may have a different number of columns. The search starts from the top left corner and proceeds row by row.

    Parameters:
    lst (list): A 2D list containing the star map
    star (int): The unique identifier for the star to find

    Returns:
    list: A list of tuples representing the coordinates (row, column) of the star if found, or an empty list if not found.
    
    Examples:
    >>> find_star_map([
      [1,2,3,4,5,6],
      [7,8,9,10,11,12],
      [13,14,15,16,17,18]
    ], 10)
    [(1, 3)]

    >>> find_star_map([
      [1,1,1],
      [2,2,2],
      [3,3,3]
    ], 2)
    [(1, 0), (1, 1), (1, 2)]

    >>> find_star_map([
      [1,2,3],
      [4,5,6],
      [7,8,9]
    ], 20)
    []
    """
    coordinates = []
    for row in lst:
        if star in row:
            star_index = row.index(star)
            column = star_index % len(row)
            coordinates.append((row.index(star), column))
    return coordinates