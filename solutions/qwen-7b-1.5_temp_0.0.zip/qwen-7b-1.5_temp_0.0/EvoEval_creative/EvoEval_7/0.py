def find_shangri_la(code_sequence: list[int]) -> str:
    """
    This function helps an explorer locate the mythical city of Shangri-La using a code sequence of directions.
    Directions are represented as integers: 0 for North, 1 for East, 2 for South, and 3 for West.

    Args:
    - code_sequence (list[int]): A list of integers representing the movement sequence.

    Returns:
    - str: "Shangri-La found" if the sequence leads back to the starting point (0,0), otherwise "Shangri-La not found".
    Note: Moving is considered a unit of 1.

    Examples:
    >>> find_shangri_la([0, 1, 2, 3])
    'Shangri-La found'
    
    >>> find_shangri_la([0, 1, 0, 3])
    'Shangri-La not found'
    """
    current_position = (0, 0)
    for direction in code_sequence:
        if direction == 0:
            current_position = (current_position[0], current_position[1] - 1)
        elif direction == 1:
            current_position = (current_position[0] + 1, current_position[1])
        elif direction == 2:
            current_position = (current_position[0], current_position[1] + 1)
        elif direction == 3:
            current_position = (current_position[0] - 1, current_position[1])
        if current_position == (0, 0):
            return 'Shangri-La found'
    return 'Shangri-La not found'