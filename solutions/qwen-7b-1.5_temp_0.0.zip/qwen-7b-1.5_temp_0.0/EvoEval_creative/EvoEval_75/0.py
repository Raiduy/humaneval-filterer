def magical_string_transformer(input_str):
    """
    Given a string, this function transforms it according to the specified rules:
    
    1. Vowels are replaced with the next vowel in the sequence 'aeiou', wrapping around at the end (case-insensitive).
    2. Consonants are replaced with the next consonant in the English alphabet that is not a vowel, wrapping around at 'z' (case-insensitive).
    3. Digits are incremented by 1, wrapping around at 9.
    4. Punctuation marks and special characters remain unchanged, except '?' becomes '!' in even indices and vice versa in odd indices.

    Examples:
    >>> magical_string_transformer("Hello, World!")
    "Jimmu, Xusmf!"
    >>> magical_string_transformer("Python 3.8.5")
    "Qzvjup 4.9.6"
    >>> magical_string_transformer("AEIOUaeiou")
    "EIOUAeioua"
    """
    vowels = {'a': 'e', 'e': 'i', 'i': 'o', 'o': 'u', 'u': 'a', 'A': 'E', 'E': 'I', 'I': 'O', 'O': 'U', 'U': 'A'}
    consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    digits = {str(d): str((d + 1) % 10) for d in range(10)}
    punctuation_map = {'?': '!'}
    transformed_str = ''
    for char in input_str.lower():
        if char.isalpha():
            if char in vowels:
                transformed_str += vowels[char]
            elif char in consonants:
                next_consonant = consonants[(consonants.index(char) + 1) % len(consonants)]
                transformed_str += next_consonant
        elif char.isdigit():
            transformed_str += digits[char]
        elif char in punctuation_map:
            index = input_str.index(char)
            if index % 2 == 0:
                transformed_str += punctuation_map[char]
            else:
                transformed_str += char
        else:
            transformed_str += char
    return transformed_str