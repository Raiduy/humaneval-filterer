def letter_shift_cipher(s, n):
    """Task
    Apply a simple shift cipher to a given string, shifting letters in the alphabet by 'n' places while preserving vowels. Return a tuple with the encrypted string and the vowel count.

    Args:
    s (str): The input string to be encrypted.
    n (int): The number of positions to shift each letter.

    Returns:
    tuple: A tuple containing the encrypted string and the count of vowels in the encrypted string.
    
    Examples:
    >>> letter_shift_cipher("hello", 1)
    ('ifmmp', 1)
    >>> letter_shift_cipher("abcde", 3)
    ('defgh', 1)
    >>> letter_shift_cipher("I love Python!", 13)
    ('V ybir Clguba!', 3)
    """
    encrypted_string = ''
    vowel_count = 0
    for char in s:
        if char.isalpha():
            shifted_char = chr((ord(char.lower()) - ord('a') + n) % 26 + ord('a'))
            encrypted_string += shifted_char
            if char.lower() in ['a', 'e', 'i', 'o', 'u']:
                vowel_count += 1
        else:
            encrypted_string += char
    return (encrypted_string, vowel_count)