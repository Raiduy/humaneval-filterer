def create_pyramid(p):
    """
    Given a positive integer p, this function constructs a pyramid with p blocks at the base. 
    The number of blocks in each subsequent layer follows a pattern based on whether the previous layer's count is even or odd.
    
    Parameters:
    p (int): Positive integer representing the number of blocks in the base layer.

    Returns:
    list: A list containing the number of blocks in each layer from bottom to top.

    Examples:
    >>> create_pyramid(10)
    [10, 8, 6, 4, 2]
    
    >>> create_pyramid(9)
    [9, 6, 4, 2]
    """
    pyramid = [p]
    for i in range(1, p // 2 + 1):
        if p % 2 == 0:
            pyramid.append(p - 2 * i)
        else:
            pyramid.append(p - 3 * i)
    while pyramid[-1] <= 0:
        pyramid.pop()
    return pyramid