def spider_web_jump(arr):
    """
    This function finds the optimal path for a spider to reach the 'safe cell' in a two-dimensional array representing a spider's web,
    using the minimum energy possible. The spider starts from the top-left cell (0,0) and each cell has a value indicating the energy required for a jump.

    Parameters:
    arr (List[List[int]]): A two-dimensional array with values representing energy requirements

    Returns:
    int: The minimum energy required to reach the safe cell

    Examples:
    >>> spider_web_jump([[1, 2, 1, 99], [1, 3, 2, 0], [99, 1, 1, 99], [99, 99, 99, 99]])
    6
    >>> spider_web_jump([[2, 3], [1, 0]])
    3
    >>> spider_web_jump([[0]])
    0

    Constraints:
    - 1 <= arr.length <= 100
    - 1 <= arr[i].length <= 100
    - 0 <= cell.value <= 100
    - The array contains exactly 1 safe cell with value 0.
    """
    (m, n) = (len(arr), len(arr[0]))
    visited = [[False] * n for _ in range(m)]
    energy = 0
    current_pos = (0, 0)
    while current_pos != (m - 1, n - 1):
        (x, y) = current_pos
        if arr[x][y] == 0:
            break
        visited[x][y] = True
        directions = [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)]
        for (dx, dy) in directions:
            if 0 <= dx < m and 0 <= dy < n and (not visited[dx][dy]) and (arr[dx][dy] != 99):
                energy += arr[dx][dy]
                current_pos = (dx, dy)
    return energy