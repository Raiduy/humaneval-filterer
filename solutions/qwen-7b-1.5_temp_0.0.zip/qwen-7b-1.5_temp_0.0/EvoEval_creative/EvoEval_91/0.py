def spaceship_trajectory(spaceship_data):
    """Create a function which takes a list of tuples representing a spaceship's flight data,
    and returns a string indicating the spaceship's final status.

    Parameters:
    spaceship_data (list of tuples): A list containing tuples with the format:
        - First element: A string representing the action ('Launch', 'Move', 'Land')
        - Second element: An integer indicating the distance moved in that action (negative for backwards, positive for forwards)

    Returns:
    str: The final status of the spaceship based on the given actions. It will be one of:
        - 'On Ground': If the sequence starts with 'Launch' and ends with 'Land'
        - 'Invalid Action Sequence': If any action is invalid according to the rules
        - Otherwise, the final status after all actions

    Example usage:
    >>> spaceship_trajectory([('Launch', 1), ('Move', 2), ('Land', -1)])
    'On Ground'
    >>> spaceship_trajectory([('Launch', 1), ('Move', 2), ('Land', -1), ('Move', 3)])
    'Invalid Action Sequence'
    """
    status = 'On Ground'
    for (action, distance) in spaceship_data:
        if status == 'On Ground' and action == 'Launch':
            status = 'In Space'
        elif status == 'In Space' and (action != 'Move' or distance == 0):
            return 'Invalid Action Sequence'
        elif status == 'In Space' and action == 'Land':
            status = 'On Ground'
        else:
            pass
    return status