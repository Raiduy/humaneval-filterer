def food_order(menu, order):
    """
    Function to handle food order customization based on a menu and a customer's order dictionary.

    Parameters:
    menu (dict): A dictionary representing the restaurant's menu, where keys are food names and values are ingredient sequences.
    order (dict): A dictionary containing the customer's order modifications, with keys representing food items and values for 'add' and 'remove' lists.

    Returns:
    dict: The final food order with customized ingredients, or the original menu if the order is empty or no changes are specified.
    
    Assumptions:
    - 'remove' list will always exist for an ingredient to be removed.
    - 'add' list will only exist for an ingredient to be added.
    - The order dictionary will only contain food items present in the menu.

    Example:
    >>> menu = {"Burger": ["Bun", "Meat", "Cheese"], "Pizza": ["Dough", "Tomato Sauce", "Cheese"]}
    >>> order = {"Burger": {"remove": ["Cheese"], "add": ["Mushrooms"]}, "Pizza": {"add": ["Pepperoni"]}}
    >>> food_order(menu, order)
    {"Burger": ["Bun", "Meat", "Mushrooms"], "Pizza": ["Dough", "Tomato Sauce", "Cheese", "Pepperoni"]}

    If no changes are specified:
    >>> menu = {"Burger": ["Bun", "Meat", "Cheese"], "Pizza": ["Dough", "Tomato Sauce", "Cheese"]}
    >>> order = {}
    >>> food_order(menu, order)
    {"Burger": ["Bun", "Meat", "Cheese"], "Pizza": ["Dough", "Tomato Sauce", "Cheese"]}
    
    If the order is empty:
    >>> menu = {"Burger": ["Bun", "Meat", "Cheese"], "Pizza": ["Dough", "Tomato Sauce", "Cheese"]}
    >>> order = {}
    >>> food_order(menu, order)
    {"Burger": ["Bun", "Meat", "Cheese"], "Pizza": ["Dough", "Tomato Sauce", "Cheese"]}
    """
    final_order = {}
    for (food, ingredients) in menu.items():
        if food in order:
            if 'remove' in order[food]:
                ingredients = [ingredient for ingredient in ingredients if ingredient not in order[food]['remove']]
            if 'add' in order[food]:
                ingredients.extend(order[food]['add'])
        final_order[food] = ingredients
    if not final_order:
        return menu
    else:
        return final_order