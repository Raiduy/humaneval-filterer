def text_to_morse(text):
    """Convert a string of text to Morse code."""
    morse_code = ''
    for char in text.upper():
        if char in morse_code_dict:
            morse_code += morse_code_dict[char] + ' '
        else:
            morse_code += ' '
    morse_code = ' '.join(morse_code.split()) + ' '
    return morse_code