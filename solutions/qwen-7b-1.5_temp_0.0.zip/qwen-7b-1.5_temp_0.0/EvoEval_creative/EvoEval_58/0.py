def interstellar_translator(earth_phrase):
    """
    A function that translates an Earth phrase into an alien language following specific rules.
    
    Parameters:
    earth_phrase (str): A string containing only lowercase letters and spaces representing the input phrase.

    Returns:
    str: The translated phrase according to the given rules.
    
    Examples:
    >>> interstellar_translator('hello world')
    'Jimmuyz@Xusmfyz'
    >>> interstellar_translator('this is a test')
    'Vjotyz@Otxy@Exy@Vitvyz'
    """
    translated_phrase = ''
    words = earth_phrase.lower().split()
    for word in words:
        word = word[0].upper() + word[1:]
        if word[0] in 'aeiou':
            new_vowel = {'a': 'e', 'e': 'i', 'i': 'o', 'o': 'u', 'u': 'a'}[word[0]]
            if word[0] == 'z':
                new_vowel = 'b'
            word = new_vowel + word[1:]
        else:
            new_consonant = {c: chr((ord(c) - 97 + 1) % 26) if c != 'z' else 'b' for c in word}
            word = ''.join(new_consonant.values())
        if word[0] in 'aeiou':
            translated_phrase += word + 'xy'
        else:
            translated_phrase += word + 'yz'
        if word[-1] == ' ':
            translated_phrase += '@'
    return translated_phrase