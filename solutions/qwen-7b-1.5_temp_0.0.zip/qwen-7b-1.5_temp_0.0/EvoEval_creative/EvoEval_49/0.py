def morse_decoder(msg):
    morse_code_mapping = {'A': '01', 'B': '1000', 'C': '1010', 'D': '100', 'E': '0', 'F': '0010', 'G': '110', 'H': '0000', 'I': '00', 'J': '0111', 'K': '101', 'L': '0100', 'M': '11', 'N': '10', 'O': '111', 'P': '0110', 'Q': '1101', 'R': '010', 'S': '000', 'T': '1', 'U': '001', 'V': '0001', 'W': '011', 'X': '1001', 'Y': '1011', 'Z': '1100', '1': '01111', '2': '00111', '3': '00011', '4': '00001', '5': '00000', '6': '10000', '7': '11000', '8': '11100', '9': '11110', '0': '11111'}
    decoded_msg = ''
    word_separator = '/'
    morse_words = msg.split(word_separator)
    for word in morse_words:
        if word:
            dots_dashes = word.replace(' ', '')
            decoded_char = ''.join((morse_code_mapping[char] for char in dots_dashes))
            decoded_msg += decoded_char + ' '
        else:
            decoded_msg += ' '
    return decoded_msg.strip()