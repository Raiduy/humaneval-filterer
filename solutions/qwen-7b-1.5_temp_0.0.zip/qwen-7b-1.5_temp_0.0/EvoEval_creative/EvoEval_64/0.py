def magical_sequence(start, end, divisor):
    """This function takes three positive integers: 'start', 'end', and 'divisor'. It returns a list of all 
    the numbers in the range ['start', 'end'] inclusive, that are divisible by 'divisor' and are prime numbers. 
    If no such number exists, the function should return an empty list.

    For example:
    >>> magical_sequence(10, 20, 2)
    []
    >>> magical_sequence(1, 5, 3)
    [3]
    >>> magical_sequence(10, 15, 6)
    []
    """

    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    primes_in_range = []
    for num in range(start, end + 1):
        if num % divisor == 0 and is_prime(num):
            primes_in_range.append(num)
    return primes_in_range if primes_in_range else []