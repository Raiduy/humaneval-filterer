def create_alias(name: str) -> str:
    """For a given name, create an alias following the specified rules:
    
    - If the name includes a vowel, replace it with the next vowel in the cycle a->e->i->o->u->a.
    - If the name includes a consonant, replace it with the next consonant in alphabetical order, looping back to 'b' when 'z' is reached.
    - The alias maintains the original name's case (upper or lower).
    - Ignore any non-alphabetical characters.

    Args:
        name (str): The input name to create an alias for.

    Returns:
        str: The created alias.

    Example:
        >>> create_alias('John Doe')
        'Kujp Fui'
    """
    alias = ''
    name = name.lower()
    for char in name:
        if char.isalpha():
            if char in 'aeiou':
                if char == 'u':
                    alias += 'a'
                else:
                    alias += chr(ord(char) + 1 % 5)
            elif char == 'z':
                alias += 'b'
            else:
                alias += chr(ord(char) + 1)
        else:
            alias += char
    return alias