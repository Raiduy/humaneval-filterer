def transform_canvas(canvas: str) -> str:
    """
    Given a canvas with '#' for walls, '-' for empty spaces, and 'P' for a painter's starting point, this function updates the canvas by painting all accessible empty spaces with '*'. It ensures that the walls are not crossed and returns an updated canvas accordingly.

    Parameters:
    canvas (str): The input canvas string, where '#' represents walls, '-' represents empty spaces, and 'P' represents the starting point.

    Returns:
    str: The updated canvas with accessible empty spaces painted, or 'Invalid canvas' if conditions are not met.

    Examples:
    >>> transform_canvas('P----#-----#-----#-----')
    'P****#-----#-----#-----'

    >>> transform_canvas('--#-P#-----#-----#--#--')
    'Invalid canvas'

    >>> transform_canvas('-----#--P--#-----#-----')
    '-----#**P**#-----#-----'

    >>> transform_canvas('-----#-----#--P---#P----')
    'Invalid canvas'
    """
    if canvas[0] != 'P':
        return canvas
    painted_spaces = 0
    canvas_len = len(canvas)
    accessible_spaces = 0
    for i in range(1, canvas_len):
        if canvas[i] == '-' and canvas[i - 1] == 'P':
            canvas = canvas[:i] + '*' + canvas[i:]
            painted_spaces += 1
            accessible_spaces += 1
        elif canvas[i] == '#':
            continue
        if painted_spaces > 1 or painted_spaces % accessible_spaces == 0:
            return 'Invalid canvas'
    return canvas