from typing import List

def magical_alphabet(input_string: str) -> List[int]:
    """ 
    Given a string where 'a' represents '1', 'b' represents '2', 'c' represents '3' ... 'z' represents '26'. 
    This function returns a list of all possible combinations based on the interpretation of the input string as numbers.
    
    Example:
    >>> magical_alphabet('123')
    ['abc', 'lc', 'aw']
    
    >>> magical_alphabet('111')
    ['aaa', 'ak', 'ka']
    
    Note: The input strings will only contain digits.
    """
    alphabet = [chr(i) for i in range(97, 123)]
    combinations = []
    for char in input_string:
        combination = [int(char)]
        for next_char in alphabet:
            if int(next_char) - 1 == int(char):
                combination.append(int(next_char))
                break
        combinations.append(''.join(map(str, combination)))
    return combinations