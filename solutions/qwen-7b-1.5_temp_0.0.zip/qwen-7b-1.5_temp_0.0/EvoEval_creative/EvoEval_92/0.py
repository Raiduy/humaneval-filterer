def paint_fountain(n):
    """
    This function takes a positive integer n as the number of fountain layers and returns a string representing a fountain with n layers.
    The fountain is symmetrical, wider with each layer, and starts with 'A' in the central column. If n exceeds 26, the painting restarts from 'A'.

    Parameters:
    n (int): Positive integer representing the number of fountain layers.

    Returns:
    str: A string with newlines between layers, centered for each layer, and the last layer having a maximum width of 2n-1 characters.

    Examples:
    - For n = 1, the output is 'A'
    - For n = 3, the output is:
        '  A  
'
        'BAB 
'
        'CCACC'
    - For n = 27, the output is a 27-layered fountain with 'A' in the central column and the same pattern.

    Note:
    - The input is guaranteed to be a positive integer.
    - The alphabet consists of uppercase letters from 'A' to 'Z', with 26 letters.

    """
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    current_layer = 'A'
    max_width = 2 * n - 1
    fountain = ''
    for i in range(n):
        layer = '{:<{width}}'.format(current_layer.center(max_width), width=max_width // 2)
        fountain += layer + '\n'
        current_layer = alphabet[(i + 1) % len(alphabet)]
    return fountain