def word_frequency_analysis(text: str, word: str) -> tuple:
    """Return the frequency of the given word in a text and the sentence with the max frequency of the word.

    Args:
        text (str): The input text.
        word (str): The word to analyze.

    Returns:
        tuple: A tuple containing the frequency of the word (int) and the sentence with the max frequency (str). If the word is not found, returns (0, ""). 

    Examples:
        >>> word_frequency_analysis("Hello world. I love this world.", "world")
        (2, "Hello world")

        >>> word_frequency_analysis("This is the best day. I love this day because it's sunny.", "day")
        (2, "This is the best day")

        >>> word_frequency_analysis("This is a test. Testing is fun.", "test")
        (1, "This is a test")

        >>> word_frequency_analysis("Welcome to the world of coding.", "python")
        (0, "")
    """
    sentences = text.split('. ')
    word_count = 0
    max_freq_sentence = ''
    for sentence in sentences:
        sentence_word_count = sentence.count(word)
        if sentence_word_count > word_count:
            word_count = sentence_word_count
            max_freq_sentence = sentence
    return (word_count, max_freq_sentence)