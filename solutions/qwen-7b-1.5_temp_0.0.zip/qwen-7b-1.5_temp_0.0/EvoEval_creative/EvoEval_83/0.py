def reverse_vowels(s):
    """Given a string s, return a new string with the vowels in reverse order, while keeping the position of other characters unchanged.
    The string can contain uppercase and lowercase letters.
    Example:
    reverse_vowels('Hello') == 'Holle'
    reverse_vowels('Python') == 'Python'
    reverse_vowels('algorithm') == 'ilgorathm'
    """
    vowels = 'aeiouAEIOU'
    reversed_vowels = ''
    for char in s:
        if char in vowels:
            reversed_vowels = char + reversed_vowels
        else:
            reversed_vowels += char
    return reversed_vowels