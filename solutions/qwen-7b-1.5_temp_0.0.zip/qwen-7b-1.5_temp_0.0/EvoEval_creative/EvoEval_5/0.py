from typing import List, Tuple


def zigzag_traversal(matrix: List[List[int]]) -> List[int]:
    """Given a 2D list of integers, return a list that represents its elements traversed in a zigzag order starting from the top-left corner and moving rightwards.
    When the right end is reached, the direction should be downwards to the next row, then to the left end, and so on until all elements are covered. 

    Example:
    >>> zigzag_traversal([[1, 2], [3, 4], [5, 6, 7], [8, 9, 10]])
    [1, 2, 4, 3, 5, 6, 7, 10, 9, 8]

    Args:
        matrix (List[List[int]]): A 2D list of integers.

    Returns:
        List[int]: The zigzag traversal of the given matrix.

    """
    result = []
    (rows, cols) = (len(matrix), len(matrix[0]))
    for i in range(rows):
        for j in range(cols):
            result.append(matrix[i][j])
            if j == cols - 1 or (i < rows - 1 and j > 0):
                result.append(matrix[i + 1][j - 1])
    if i < rows - 1:
        for _ in range(2 * (rows - i - 1)):
            result.append(matrix[i + 1][0])
            result.append(matrix[i][0])
    return result