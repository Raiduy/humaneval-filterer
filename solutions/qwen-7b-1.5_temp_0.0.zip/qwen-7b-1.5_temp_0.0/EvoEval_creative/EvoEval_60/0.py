def happy_ants(path_length, sugar_locations, ant_positions):
    """
    Function to calculate the number of happy ants after they march along a path with sugar pieces.

    Parameters:
    - path_length (int): Positive integer representing the length of the path.
    - sugar_locations (list of int): List of positive integers less than path_length, denoting initial sugar locations.
    - ant_positions (list of tuples): List of tuples, where each tuple contains an ant's position (less than path_length) and its marching direction ("left" or "right").

    Returns:
    - int: Number of happy ants at the end of their march.

    Examples:
    >>> happy_ants(10, [2, 5, 7], [(1, "right"), (3, "right"), (6, "left")])
    3

    >>> happy_ants(20, [2, 10, 14, 15], [(2, "right"), (8, "right"), (19, "left"), (15, "left")])
    4

    >>> happy_ants(3, [2], [(0, "right"), (1, "right"), (2, "left")])
    3

    >>> happy_ants(0, [], [])
    0
    """
    happy_ants_count = 0
    visited = set()
    for (position, direction) in ant_positions:
        if position not in visited and position in sugar_locations:
            happy_ants_count += 1
            visited.add(position)
        if direction == 'right':
            position += 1
        elif direction == 'left':
            position -= 1
        if position < 0:
            position = path_length + position
        elif position >= path_length:
            break
    return happy_ants_count