def calculate_integral_coefficients(xs: list) -> list:
    """Calculate the indefinite integral of a polynomial given its coefficients.

    Args:
        xs (list): Coefficients of the polynomial in the form [c0, c1, c2, ..., cn], where `c0` is the constant term and `cn` is the coefficient of `x^n`.

    Returns:
        list: A new list representing the coefficients of the integral polynomial, with the constant of integration set to zero.

    Examples:
        >>> calculate_integral_coefficients([3, 2, 1])
        [0, 3.0, 1.0, 0.3333333333333333]
        >>> calculate_integral_coefficients([1, 3, 3, 1])
        [0, 1.0, 1.5, 1.0, 0.25]

    """
    integral_coeffs = [0]
    for (n, coefficient) in enumerate(xs[1:], start=1):
        integral_coeffs.append(coefficient / (n + 1))
    integral_coeffs.append(xs[0])
    return integral_coeffs