def magical_sorting(arr):
    """
    In a land of magic, a sorcerer has an enchanted array 'arr' of N integers arr[1], arr[2], ..., arr[N].
    The numbers in the array are granted a random order by a spell. The sorcerer wants to bring order to this chaos and
    needs to sort this array in non-decreasing order. He can use his magic wand to cast two types of spells:

    1. 'Rotate': This spell rotates all elements of the array by one position to the right. The last element of the array 
        will be moved to the starting position in the array i.e. 0th index. 
    2. 'Swap': This spell allows him to swap any two elements in the array.

    The sorcerer wants to use a minimum amount of magic to save his energy, so he can only cast the 'Swap' spell once.

    Your task is to help the sorcerer determine if it is possible to get an array sorted in non-decreasing order by using 
    the 'Rotate' spell any number of times and the 'Swap' spell only once.

    If it is possible to obtain the sorted array using the sorcerer's spells, then return True; otherwise, return False.
    If the given array is empty, then return True.

    Note: The given list is guaranteed to have unique elements.

    Examples:
    >>> magical_sorting([3, 4, 5, 1, 2])
    True

    >>> magical_sorting([3, 5, 4, 1, 2])
    True

    >>> magical_sorting([3, 5, 4, 2, 1])
    False
    """
    if not arr:
        return True
    original_arr = arr.copy()
    sorted_arr = sorted(original_arr)
    inversions = 0
    for i in range(len(original_arr)):
        for j in range(i + 1, len(original_arr)):
            if original_arr[i] > original_arr[j]:
                inversions += 1
    if inversions == 1:
        (i, j) = (0, len(original_arr) - 1)
        while original_arr[i] > original_arr[j]:
            i += 1
            j -= 1
        (original_arr[i], original_arr[j]) = (original_arr[j], original_arr[i])
        if original_arr == sorted_arr:
            return True
    else:
        return False