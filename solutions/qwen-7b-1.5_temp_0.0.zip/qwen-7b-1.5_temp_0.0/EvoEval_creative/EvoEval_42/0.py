def find_legendary_item(player_input):
    """
    In a popular multiplayer online game, players can acquire various items with rarity values ranging from 1 (common) to 5 (legendary). 
    This function determines if a legendary item (rarity 5) has been acquired by a player and returns the rarity of the second most valuable item if one exists.

    Parameters:
    player_input (list): A list representing the items acquired by a player, where each item is the rarity value (1-5).

    Returns:
    tuple: A tuple containing:
        - bool: Whether a legendary item was acquired or not.
        - int or None: The rarity of the second most valuable item (if a legendary item was not acquired, None is returned).

    Examples:
    >>> find_legendary_item([1, 2, 3, 4, 5])
    (True, 4)
    >>> find_legendary_item([5])
    (True, -1)
    >>> find_legendary_item([1, 3, 4])
    (False, None)
    >>> find_legendary_item([])
    (False, None)
    """
    if not player_input:
        return (False, None)
    rarity_set = set(player_input)
    if 5 in rarity_set:
        sorted_items = sorted(player_input, reverse=True)
        return (True, sorted_items[1] if len(sorted_items) > 1 else -1)
    else:
        return (False, None)