def split_strings(s: str, n: int) -> list:
    """Return a list of n-character long strings created from the input string s.
    If the length of s isn't a multiple of n, the remaining characters are added as the 
    last element of the returned list.

    Examples:
    >>> split_strings('HelloWorld', 3)
    ['Hel', 'loW', 'orl', 'd']
    >>> split_strings('CodingIsFun', 5)
    ['Codin', 'gIsFu', 'n']
    """
    chunks = s[:n] + [s[i:i + n] for i in range(n, len(s), n)]
    return chunks