def planet_path(planets, path):
    """Given a dictionary of planets and a list of planets forming a path,
    check if the path is valid by directly connecting each planet in the path.
    Returns True if valid, False otherwise. Handles cases where planets don't exist
    or the path is empty.

    Example:
    >>> planet_path({'a': ['b', 'c'], 'b': ['a', 'c'], 'c': ['a', 'b']}, ['a', 'b', 'c'])
    True
    >>> planet_path({'a': ['b', 'c'], 'b': ['a', 'c'], 'c': ['a', 'b']}, ['a', 'c', 'b'])
    True
    >>> planet_path({'a': ['b', 'c'], 'b': ['a', 'c'], 'c': ['a', 'b']}, ['a', 'b', 'a'])
    True
    >>> planet_path({'a': ['b'], 'b': ['a', 'c'], 'c': ['b']}, ['a', 'c', 'b'])
    False
    >>> planet_path({'a': ['b'], 'b': ['a', 'c'], 'c': ['b']}, [])
    False
    >>> planet_path({}, ['a', 'b', 'c'])
    False
    """
    if planets is None or path is None or (not path):
        return False
    for i in range(len(path) - 1):
        planet_a = path[i]
        planet_b = path[i + 1]
        if planet_a not in planets or planet_b not in planets[planet_a] or planets[planet_a][planet_b] is None:
            return False
        if planets[planet_a][planet_b] != path[i + 1]:
            return False
    return True