def hidden_message(test_cases):

    def extract_first_letters(strings):
        cleaned_strings = [word.lower().strip('?!') for word in strings]
        secret_messages = ''.join((word[0] for word in cleaned_strings))
        return secret_messages
    decoded_messages = []
    for case in test_cases:
        secret_message = extract_first_letters(case)
        if secret_message == 'take the cannoli':
            decoded_messages.append(secret_message)
        else:
            decoded_messages.append(secret_message)
    return decoded_messages