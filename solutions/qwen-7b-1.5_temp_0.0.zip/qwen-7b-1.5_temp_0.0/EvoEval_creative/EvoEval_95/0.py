def matrixMystery(m):
    """Function to calculate the absolute difference between the sums of the diagonals in a 2D array (matrix)

    Args:
        m (2D list of integers): A square or rectangular matrix

    Returns:
        int: The absolute difference between the sums of the two diagonals, or 'Invalid Matrix' if the matrix is not square.

    Examples:
        >>> matrixMystery([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        0
        >>> matrixMystery([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
        2
        >>> matrixMystery([[1, 2], [3, 4]])
        0
    """
    if len(m) != len(m[0]):
        return 'Invalid Matrix'
    diagonal1_sum = sum((row[i] for (i, row) in enumerate(m)))
    diagonal2_sum = sum((row[len(m) - i - 1] for (i, row) in enumerate(reversed(m))))
    return abs(diagonal1_sum - diagonal2_sum)