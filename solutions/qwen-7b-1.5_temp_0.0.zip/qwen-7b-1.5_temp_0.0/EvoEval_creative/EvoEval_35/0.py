def validate_email_structure(email: str) -> bool:
    """Check if an email address has a valid format.

    Args:
        email (str): The email address to validate.

    Returns:
        bool: True if the email has a valid format, False otherwise.
    
    Examples:
        >>> validate_email_structure("myemail@")
        False
        >>> validate_email_structure("myemail@domain")
        False
        >>> validate_email_structure("myemail@domain.com")
        True
        >>> validate_email_structure("myemail.domain.com")
        False
        >>> validate_email_structure("myemail@domain@domain.com")
        False
    """
    if '@' not in email or '@' == email[0] or '@' == email[-1]:
        return False
    if '.' not in email.split('@')[1]:
        return False
    return True