def space_travel(distance, speed, fuel, planet_gravity, spaceship_weight):
    """
    Given the distance of a planet from Earth in light years, the speed of the spaceship in light years per year, the amount of fuel in the spaceship in years, the gravity of the planet, and the weight of the spaceship,
    this function computes the fuel consumption and determines if the spaceship can reach the planet with the given fuel.

    Parameters:
    - distance (float): The distance to the planet in light years
    - speed (float): The speed of the spaceship in light years per year
    - fuel (float): The initial amount of fuel in the spaceship in years
    - planet_gravity (float): The gravity of the planet in standard gravitational acceleration (e.g., 9.8 for Earth)
    - spaceship_weight (float): The weight of the spaceship in years

    Returns:
    - float: The remaining fuel after reaching the planet, rounded to 2 decimal points if possible, or 'Insufficient fuel' if not enough fuel for the trip.
    
    Notes:
    - Fuel consumption is calculated as `spaceship_weight * planet_gravity * 0.1` per year.
    - The spaceship can reach the planet if the fuel is greater than or equal to the trip duration (distance divided by speed).
    - The remaining fuel is calculated by subtracting the fuel consumed during the trip from the initial amount.

    Example:
    >>> space_travel(4.22, 0.5, 10, 9.8, 100)
    'Insufficient fuel'
    >>> space_travel(2.5, 1, 2, 3.7, 1.5)
    0.61
    """
    fuel_consumption_per_year = spaceship_weight * planet_gravity * 0.1
    trip_duration = distance / speed
    if fuel >= trip_duration:
        remaining_fuel = round(fuel - fuel_consumption_per_year * trip_duration, 2)
    else:
        remaining_fuel = 'Insufficient fuel'
    return remaining_fuel