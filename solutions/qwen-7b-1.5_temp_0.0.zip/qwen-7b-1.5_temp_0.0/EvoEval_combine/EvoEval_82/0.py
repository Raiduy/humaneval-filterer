
def odd_fibfib(n: int) -> int:
    """The Odd FibFib sequence is a sequence similar to the FibFib sequence,
    where odd numbers are generated based on the given rules.

    Args:
        n (int): The index of the element in the sequence.

    Returns:
        int: The n-th element of the odd_fibfib sequence.

    Examples:
        >>> odd_fibfib(1)
        0
        >>> odd_fibfib(5)
        0
        >>> odd_fibfib(7)
        1
        >>> odd_fibfib(9)
        0
    """
    fibfib_sequence = [0, 0, 1] + [0] * (n - 3)
    for i in range(4, n + 1):
        fibfib_sequence[i] = fibfib_sequence[i - 1] + fibfib_sequence[i - 2] + fibfib_sequence[i - 3]
        if fibfib_sequence[i] % 2 == 0:
            digits = [int(d) for d in str(fibfib_sequence[i]) if d % 2 != 0]
            if digits:
                fibfib_sequence[i] = 1 * len(digits)
            else:
                fibfib_sequence[i] = 0
    return fibfib_sequence[n]