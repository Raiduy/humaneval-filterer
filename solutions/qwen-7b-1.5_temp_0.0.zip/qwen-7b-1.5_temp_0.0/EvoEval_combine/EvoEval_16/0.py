def get_music_notes(word: str, music_string: str) -> list:
    vowels = 'aeiouAEIOU'
    result = []
    for (i, char) in enumerate(reversed(word)):
        if char not in vowels:
            next_vowel_index = i + 1
            while next_vowel_index < len(word) and word[next_vowel_index] not in vowels:
                next_vowel_index += 1
            if next_vowel_index > 0:
                beats = [int(note) for note in music_string[i:next_vowel_index]]
                result.extend(beats)
                break
    return result if result else []