
def prime_vowel(string):
    """
    Write a function that takes a string and returns the closest vowel that stands between two consonants from the right side of the string (case sensitive) if the string length is a prime number. 

    If the string is not a prime number, return an empty string. 

    Vowels in the beginning and ending don't count. You may assume that the given string contains only English letters.

    Examples:
    - prime_vowel('Hello') ==> "e"
    - prime_vowel('abcdcba') ==> ""
    - prime_vowel('kittens') ==> "e"
    - prime_vowel('orange') ==> ""
    - prime_vowel('yogurt') ==> ""
    - prime_vowel('FULL') ==> ""
    - prime_vowel('quick') ==> ""
    - prime_vowel('ab') ==> ""

    """

    def is_prime(n):
        """Helper function to check if a number is prime."""
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    vowels = 'aeiou'
    string = string[::-1].replace(vowels, '', 1)[::-1]
    if is_prime(len(string)):
        consonants = [c for c in string if c.isalpha() and c not in vowels]
        if consonants:
            last_consonant_index = len(consonants) - 1
            for i in range(last_consonant_index, -1, -1):
                if string[i] in vowels:
                    return string[i]
        else:
            return ''
    else:
        return ''