
def mixed_solution(arr):
    """
    Given an array of integers, this function calculates the sum of odd elements that are in even positions and have a sum of their digits greater than 0. For negative numbers, the first signed digit is considered.

    Examples:
    >>> mixed_solution([]) == 0
    >>> mixed_solution([-1, 11, -11]) == 0
    >>> mixed_solution([1, 1, 2]) == 1
    >>> mixed_solution([5, 8, 7, 1]) == 12
    >>> mixed_solution([3, 3, -3, 3, 3]) == 6
    >>> mixed_solution([-35, 13, 24, 321]) == -35
    """
    total = 0
    for (i, num) in enumerate(arr):
        if num < 0:
            num = abs(num)
            while num % 10 < 0:
                num = num // 10 - 1
        if num % 2 == 0 and num % 5 != 0 and (sum((int(digit) for digit in str(abs(num)))) > 0):
            total += num
    return total