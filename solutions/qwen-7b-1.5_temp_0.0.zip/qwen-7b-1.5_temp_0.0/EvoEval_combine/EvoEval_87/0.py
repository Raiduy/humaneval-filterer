
def match_and_remove_unbalanced(text):
    """
    This function takes a string as an input. The string consists of parentheses '()', and alphabets only.
    The task is to check if the parentheses in the string are balanced. If unbalanced, remove the vowels from the string.
    Return the same string if the parentheses are balanced.
    The parentheses are considered balanced if every open parenthesis has a corresponding close parenthesis.

    Examples:
    >>> match_and_remove_unbalanced('a(b)c(def)')
    'a(b)c(def)'
    >>> match_and_remove_unbalanced('a(bc)de(fg)')
    '(bc)d(fg)'
    >>> match_and_remove_unbalanced('ab)c(de)f')
    'b)c(d)f'
    >>> match_and_remove_unbalanced('ab(cd)')
    'b(cd)'
    """

    def is_parentheses_balanced(s):
        stack = []
        for char in s:
            if char in '()':
                stack.append(char)
            elif stack and stack[-1] == '(' and (char == ')'):
                stack.pop()
        return not stack
    if not is_parentheses_balanced(text):
        vowels = 'aeiouAEIOU'
        text = ''.join((char for char in text if char not in vowels and char.isalpha()))
    return text