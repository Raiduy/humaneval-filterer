
def largest_prime_odd_ends(nums):
    """
    This function takes an array of numbers as input and returns the largest prime factor of the elements
    in the array that are greater than 10 and have both first and last digits odd (1, 3, 5, 7, 9).
    
    Assumptions:
    - All numbers in the array are integers greater than 1.
    - If no prime factor satisfies the condition, it returns None.

    Example usage:
    >>> largest_prime_odd_ends([15, -73, 14, -15])
    => 5
    >>> largest_prime_odd_ends([33, -2, -3, 45, 21, 109])
    => 109
    >>> largest_prime_odd_ends([10, -2, -3, 5, 21, 4])
    => None

    """

    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    result = None
    for num in nums:
        if num > 10 and num % 10 in [1, 3, 5, 7, 9] and is_prime(num):
            if result is None or num > result:
                result = num
    return result