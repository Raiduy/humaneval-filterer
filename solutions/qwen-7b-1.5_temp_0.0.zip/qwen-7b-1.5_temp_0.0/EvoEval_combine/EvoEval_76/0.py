def sort_prime_digit_sum(lst):
    modified_lst = [num if not is_prime(num) else sum_digits(num) for num in lst]
    first_last_sum = sum((modified_lst[i] + modified_lst[-i - 1] for i in range(len(modified_lst) // 2)))
    modified_lst.sort() if first_last_sum % 2 != 0 else modified_lst.sort(reverse=True)
    return modified_lst