
def modp_prime_numbers(n: int, p: int) -> list:
    """Implement a function that takes two non-negative integers n and p, first calculate \\(2^n\\ modulo p\\), 
    then return an array of the first calculated modulo result integers that are prime numbers and less than the calculated modulo result.
    If no prime numbers are found within the range, return an empty array.
    
    Example:
    >>> modp_prime_numbers(5, 11)
    [2, 3, 5, 7]
    >>> modp_prime_numbers(3, 5)
    [2]
    >>> modp_prime_numbers(0, 101)
    []
    >>> modp_prime_numbers(3, 11)
    [2, 3, 5, 7]
    >>> modp_prime_numbers(100, 101)
    []
    """
    modulo_result = pow(2, n, p)
    primes_in_range = [x for x in range(modulo_result) if x < modulo_result and is_prime(x, p)]
    return primes_in_range