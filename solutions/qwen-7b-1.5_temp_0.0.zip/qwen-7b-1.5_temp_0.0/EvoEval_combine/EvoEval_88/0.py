
def process_and_sort_string(s):
    """
    A function that takes a string with words separated by commas or spaces and performs the following steps:
    1. Split the string into a list of words.
    2. Remove words with odd lengths from the list.
    3. Sort the list first by word length in ascending order, then alphabetically if words have the same length.
    4. Return the sorted list of strings.

    Example usage:
    ```python
    input1 = "Hi, my name is John"
    output1 = process_and_sort_string(input1) => ["Hi", "is", "my", "John", "name"]

    input2 = "One, two, three, four, five, six"
    output2 = process_and_sort_string(input2) => ["five", "four"]
    ```

    """
    words = s.split(', ')
    words = [word for word in words if len(word) % 2 == 0]
    sorted_words = sorted(words, key=lambda x: (len(x), x))
    return sorted_words