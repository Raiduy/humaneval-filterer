from typing import List

def balance_triples(operations: List[int]) -> bool:
    """
    Given a list of deposit and withdrawal operations on a bank account starting with zero balance, this function checks if there are at least three distinct points in time where the balance sums to zero (excluding the initial balance). If the balance ever falls below zero, it immediately returns False.

    Examples:
    >>> balance_triples([1, -1, 2, -2, 3, -3])
    True
    >>> balance_triples([1, 2, 3, -6])
    False
    >>> balance_triples([1, 2, -4, 5])
    False
    >>> balance_triples([2, -2, 3, -3, 4, -4])
    True
    >>> balance_triples([1, -1, 2])
    False

    Args:
        operations (List[int]): A list of integers representing deposit (+) or withdrawal (-) operations.

    Returns:
        bool: True if there are at least three zero-sum balances, False otherwise.
    """
    balance = 0
    count = 0
    for op in operations:
        balance += op
        if balance == 0:
            count += 1
            if count >= 3:
                return True
        elif balance < 0:
            return False
    return count >= 3