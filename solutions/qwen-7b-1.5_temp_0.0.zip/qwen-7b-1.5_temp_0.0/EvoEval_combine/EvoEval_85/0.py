def next_smallest_sorted_binary(lst):
    """
    Given a list of non-negative integers, first sort the list based on the number of ones in their binary representation in ascending order, and then for the same number of ones, sort based on the original value. 

    If the list is empty or there is only one element with no other elements smaller, return None. Otherwise, return the second smallest element from the sorted list.

    Examples:
    >>> next_smallest_sorted_binary([1, 2, 3, 4, 5])
    2
    >>> next_smallest_sorted_binary([5, 1, 4, 3, 2])
    2
    >>> next_smallest_sorted_binary([])
    None
    >>> next_smallest_sorted_binary([1, 1])
    None
    """
    lst.sort(key=lambda x: (bin(x).count('1'), x))
    if len(lst) < 2:
        return None
    return lst[1]