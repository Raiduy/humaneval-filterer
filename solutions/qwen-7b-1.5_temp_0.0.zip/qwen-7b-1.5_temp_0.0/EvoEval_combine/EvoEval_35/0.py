def check_dict_happiness(dict):
    """
    Given a dictionary, where all keys are strings, this function checks if the dictionary meets the following conditions:
    1. All keys are either all lower case or all upper case.
    2. Each key is a happy string, which means it has a length of at least 3 and every 3 consecutive letters are distinct.

    Returns True if all conditions are met, and False otherwise.
    
    Examples:
    >>> check_dict_happiness({"abc": "apple", "def": "banana"})
    True
    >>> check_dict_happiness({"abc": "apple", "ABD": "banana"})
    False
    >>> check_dict_happiness({"aab": "apple", "abc": "banana"})
    False
    >>> check_dict_happiness({"aab": "apple", 8: "banana", "a": "apple"})
    False
    >>> check_dict_happiness({"ABC": "John", "DEF": "36", "GHI": "Houston"})
    True
    >>> check_dict_happiness({"STATE": "NC", "ZIP": "12345"})
    False

    """
    if not dict:
        return False
    all_lower = all((key.islower() for key in dict.keys()))
    all_upper = all((key.isupper() for key in dict.keys()))
    if not (all_lower or all_upper):
        return False
    for (key, value) in dict.items():
        if len(key) < 3 or not set(key[i:i + 3]) - set(key[:i]) - set(key[i + 1:i + 4]):
            return False
    return True