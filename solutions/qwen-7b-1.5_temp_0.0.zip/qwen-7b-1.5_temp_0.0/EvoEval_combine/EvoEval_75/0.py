def transform_dict(input_dict):
    """
    Transform a dictionary where keys are strings and values are numbers. Return a new dictionary with keys unchanged,
    but values rounded to the nearest integer, rounding away from zero. If keys are not all in uppercase or lowercase,
    or if the dictionary is empty, return an empty dictionary.

    Examples:
    >>> transform_dict({"a": "10", "b": "15.3"})
    {"a": 10, "b": 15}
    >>> transform_dict({"A": "10.5", "B": "-15.5"})
    {"A": 11, "B": -16}
    >>> transform_dict({"a": "10", "B": "15.3"})
    {}
    >>> transform_dict({"a": "10.5", 8: "-15.5"})
    {}

    Note:
    Rounding away from zero means that if the number is equidistant from two integers, the one returned is the one farther
    from zero. For instance, if the value is "14.5", it will be rounded up to 15, and if it's "-14.5", it will be rounded down to -15.
    """
    if not input_dict or not all((isinstance(key, str) for key in input_dict.keys())):
        return {}
    input_dict = {key.lower(): value for (key, value) in input_dict.items()}
    return {key: round(float(value), 0) if float(value).is_integer() else round(float(value), 1) for (key, value) in input_dict.items()}