
def happy_case_string(s):
    """Check if a string is happy and apply the required transformations.

    Args:
        s (str): The input string to be processed.

    Returns:
        str: The result after reversing case for happy strings and reversing the entire string if not happy or empty.

    Examples:
        >>> happy_case_string("1234")
        "4321"
        >>> happy_case_string("ab")
        "ba"
        >>> happy_case_string("#a@C")
        "#A@c"
        >>> happy_case_string("abcd")
        "ABCD"
        >>> happy_case_string("aabb")
        "bbaa"
        >>> happy_case_string("adb")
        "ADB"
        >>> happy_case_string("*#@")
        "@#*"

    """
    if len(s) < 3:
        return s[::-1]
    for i in range(2, len(s), 3):
        if s[i] == s[i - 1] or s[i] == s[i - 2]:
            return s[::-1]
    happy_string = ''
    for char in s:
        if char.isalpha():
            happy_string += char.lower() if char.islower() else char.upper()
        else:
            happy_string += char
    return happy_string[::-1]