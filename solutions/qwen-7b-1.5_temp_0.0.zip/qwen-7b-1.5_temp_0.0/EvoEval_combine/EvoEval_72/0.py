
from typing import List
from math import factorial

def special_close_factorials(numbers: List[int], threshold: int) -> bool:
    """
    Check if in given list of numbers, are any two special factorials closer to each other than the given threshold.
    The special factorial (Brazilian factorial) is defined as n! * (n-1)! * (n-2)! * ... * 1! where n > 0.

    Example usage:
    >>> special_close_factorials([2, 3], 10)
    False
    >>> special_close_factorials([1, 2, 3, 4], 100)
    True
    """
    factorials_set = set()
    for num in numbers:
        if num > 0:
            factorial_num = factorial(num) * reduce(factorial, range(1, num + 1), 1)
            factorials_set.add(factorial_num)
    if len(factorials_set) < len(numbers):
        return True
    else:
        return False