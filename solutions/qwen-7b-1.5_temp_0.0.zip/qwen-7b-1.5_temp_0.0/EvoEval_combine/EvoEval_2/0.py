
from typing import List

def modp_intersperse(numbers: List[int], n: int, p: int) -> List[int]:
    """Insert the result of \\(2^n\\ modulo p\\) between every two consecutive elements of the input list `numbers'"""
    if not numbers:
        return []
    insertions = n // p + (n % p != 0)
    result = []
    for (i, num) in enumerate(numbers):
        result.append(num)
        if i < len(numbers) - 1:
            result.append(pow(2, n, p) * (i + 1) % p)
    return result