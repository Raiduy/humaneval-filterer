def sorted_happy_strings(lst):
    """Function to filter and sort happy strings from a list

    Args:
        lst (list): List of strings, containing at least 3-letter strings with distinct consecutive letters

    Returns:
        list: Filtered and sorted list of happy strings, first by length in ascending order, then alphabetically for strings of the same length

    Examples:
        >>> assert sorted_happy_strings(["abc", "a", "aaabcd", "abcd"]) == ["abcd"]
        >>> assert sorted_happy_strings(["abcd", "aaa", "abc", "abccba", "cd"]) == ["abcd"]
    """

    def is_happy(s):
        if len(s) < 3:
            return False
        for i in range(len(s) - 2):
            if s[i] == s[i + 1] or s[i] == s[i + 2]:
                return False
        return True
    happy_strings = [s for s in lst if is_happy(s) and len(s) % 2 == 0]
    happy_strings.sort(key=lambda s: (len(s), s))
    return happy_strings