def pluck_and_prod(arr):
    """
    Given an array `arr` representing a branch of a tree with non-negative integer nodes,
    this function plucks the smallest even value node with the smallest index if it exists,
    and calculates the sum of the magnitudes of the remaining nodes multiplied by their sign product.

    Parameters:
    arr (list): A list of non-negative integer nodes

    Returns:
    tuple: A tuple containing:
        - The plucked node as a list `[smallest_value, index]`
        - The sum of the magnitudes of the remaining nodes multiplied by their sign product, or `None` if the array is empty after plucking

    Constraints:
    - 1 <= len(arr) <= 10000
    - 0 <= node.value

    Examples:
    >>> pluck_and_prod([4, 2, 3])
    ([2, 1], 7)
    >>> pluck_and_prod([1, 2, 3])
    ([2, 1], 4)
    >>> pluck_and_prod([])
    ([], None)
    >>> pluck_and_prod([-5, -2, 3, 0, -4])
    ([-4, 4], 0)
    """
    smallest_even = None
    smallest_index = -1
    for (i, num) in enumerate(arr):
        if num % 2 == 0:
            if smallest_even is None or num < smallest_even:
                smallest_even = num
                smallest_index = i
    if smallest_even is None:
        return ([], None)
    plucked_node = [smallest_even, smallest_index]
    remaining_nodes = [n for n in arr if n != smallest_even]
    remaining_sum = sum((abs(n) for n in remaining_nodes))
    sign_product = 1 if all((n >= 0 for n in remaining_nodes)) else -1 if any((n < 0 for n in remaining_nodes)) else 0
    return (plucked_node, remaining_sum * sign_product)