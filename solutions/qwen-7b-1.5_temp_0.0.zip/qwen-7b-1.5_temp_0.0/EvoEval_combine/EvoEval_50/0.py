
def get_closest_upper_vowel(word):
    """Find the closest uppercase vowel that stands between two consonants from the right side of the word,
    considering case sensitivity, and is at an even index.

    Vowels in the beginning and ending are not counted. Return an empty string if no such vowel exists.
    
    Examples:
    >>> get_closest_upper_vowel("yoUgUrt")
    "U"
    >>> get_closest_upper_vowel("FULL")
    ""
    >>> get_closest_upper_vowel("quick")
    ""
    >>> get_closest_upper_vowel("ab")
    ""

    Args:
    word (str): The input word to search for the closest uppercase vowel.

    Returns:
    str: The closest uppercase vowel meeting the conditions, or an empty string if none found.
    """
    vowels = 'AEIOU'
    closest_vowel = ''
    if len(word) < 2:
        return closest_vowel
    for i in range(1, len(word), 2):
        if word[i] in vowels and word[i - 1] not in vowels:
            closest_vowel = word[i]
            break
    return closest_vowel