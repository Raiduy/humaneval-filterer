
from typing import List
from fractions import Fraction

def filter_and_simplify(fractions: List[str], n: str) -> List[bool]:
    """Filter an input list of fractions, ensuring they simplify to a whole number when multiplied by the given `n`. Both fractions and `n` are represented as strings in the format `<numerator>/<denominator>` with positive whole numbers.

    Args:
        fractions (List[str]): List of fractions to be filtered.
        n (str): The fraction against which to test simplification.

    Returns:
        List[bool]: A list indicating if each fraction in the input simplified to a whole number when multiplied by `n`.
    """
    fractions_as_Fractions = [Fraction(int(numerator), int(denominator)) for (numerator, denominator) in zip(fractions, n.split('/'))]
    simplified_results = [frac.numerator * int(n) % 1 == 0 for frac in fractions_as_Fractions]
    return simplified_results