def sort_prime_digit_sum(lst):
    """
    You are given a list of non-negative integers. First, for each integer, if it is a prime number, 
    replace it with the sum of its digits; if not, keep it as is. Then, return a copy of the modified list 
    after sorting, where you will sort the list in ascending order if the sum of the first and last index value 
    is odd, or sort it in descending order if the sum of the first and last index value is even.

    Note:
    * don't change the original list.

    Examples:
    * sort_prime_digit_sum([]) => []
    * sort_prime_digit_sum([5]) => [5]
    * sort_prime_digit_sum([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_prime_digit_sum([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    * sort_prime_digit_sum([0, 3, 2, 1, 3, 5, 7, 4, 5, 5, 5, 2, 181, 32, 4, 32, 3, 2, 32, 324, 4, 3]) => [0, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 5, 5, 5, 5, 7, 10, 32, 32, 32, 324]
    """

    def is_prime(n):
        if n == 0 or n == 1:
            return False
        for i in range(2, n):
            if n % i == 0:
                return False
        return True

    def sum_digits(n):
        s = 0
        while n:
            s += n % 10
            n //= 10
        return s
    new_lst = []
    for i in lst:
        if is_prime(i):
            new_lst.append(sum_digits(i))
        else:
            new_lst.append(i)
    if (new_lst[0] + new_lst[-1]) % 2 == 0:
        return sorted(new_lst, reverse=True)
    else:
        return sorted(new_lst)