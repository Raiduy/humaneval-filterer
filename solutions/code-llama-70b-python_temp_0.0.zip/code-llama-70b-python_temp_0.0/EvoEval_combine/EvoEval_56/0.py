def product_of_odd_prime_factors(n):
    """Given a positive integer n, return the product of its unique odd prime factors.
    If all prime factors are even, return 0.
    Assume n > 1 and is not a prime.
    For example:
    product_of_odd_prime_factors(9) == 3
    product_of_odd_prime_factors(15) == 15
    product_of_odd_prime_factors(20) == 5
    product_of_odd_prime_factors(32) == 0
    """