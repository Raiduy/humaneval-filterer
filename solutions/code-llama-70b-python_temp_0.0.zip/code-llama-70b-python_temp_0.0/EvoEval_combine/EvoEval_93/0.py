
def prime_vowel(string):
    """Write a function that takes a string and returns the closest vowel that stands between 
    two consonants from the right side of the string (case sensitive) if the string length is a prime number. 

    If the string is not a prime number, return an empty string. 

    Vowels in the beginning and ending doesn't count. You may assume that the given string contains English letters only.

    Example:
    prime_vowel('Hello') ==> "e"
    prime_vowel('abcdcba') ==> ""
    prime_vowel('kittens') ==> "e"
    prime_vowel('orange') ==> ""
    prime_vowel('yogurt') ==> "" 
    prime_vowel('FULL') ==> ""
    prime_vowel('quick') ==> ""
    prime_vowel('ab') ==> ""
    """
    if not is_prime(len(string)):
        return ''
    for i in range(len(string) - 1, 0, -1):
        if is_vowel(string[i]):
            if is_consonant(string[i - 1]) and is_consonant(string[i + 1]):
                return string[i]
    return ''