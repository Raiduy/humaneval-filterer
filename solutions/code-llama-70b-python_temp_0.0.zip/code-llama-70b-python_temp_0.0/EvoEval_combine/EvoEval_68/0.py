
def minOddDigitsProductSubArray(nums):
    """
    Given an array of positive integers nums, find the minimum product of odd digits of any 
    non-empty sub-array of nums. For each integer in the sub-array, you need to calculate 
    the product of its odd digits. If all digits are even in an integer, consider its product as 0.
    You need to return the minimum sum of these products.
    
    Example:
    minOddDigitsProductSubArray([2, 3, 4, 1, 2, 4]) == 0
    minOddDigitsProductSubArray([235, 912, 43]) == 3 (as 235 -> 15, 912 -> 9, 43 -> 3)

    Note: 
    A sub-array is a contiguous part of an array. And you should calculate the products for 
    each integer in the sub-array independently.
    """
    odd_digits = []
    for num in nums:
        odd_digits.append([int(x) for x in str(num) if int(x) % 2 != 0])
    odd_digit_product = []
    for digits in odd_digits:
        product = 1
        for digit in digits:
            product *= digit
        odd_digit_product.append(product)
    min_product = sum(odd_digit_product)
    for i in range(len(odd_digit_product)):
        sub_array_sum = 0
        for j in range(i, len(odd_digit_product)):
            sub_array_sum += odd_digit_product[j]
            if sub_array_sum < min_product:
                min_product = sub_array_sum
    return min_product