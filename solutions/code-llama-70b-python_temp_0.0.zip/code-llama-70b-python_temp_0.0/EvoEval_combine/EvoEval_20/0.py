
def grade_and_case(s, grades):
    """You are a teacher at the end of the semester who has to give out grades and also checking the format of students' names. 

    The teacher has given you a list of student names in string format 's' and a corresponding list of GPAs for these students 'grades'. 

    You need to write a function that will:
    1. Output the student name in reverse case (from lower to upper or vise versa).
    2. Assign a letter grade to the student based on their GPA using the following table:
             GPA       |    Letter grade
              4.0                A+
            > 3.7                A 
            > 3.3                A- 
            > 3.0                B+
            > 2.7                B 
            > 2.3                B-
            > 2.0                C+
            > 1.7                C
            > 1.3                C-
            > 1.0                D+ 
            > 0.7                D 
            > 0.0                D-
              0.0                E

    The function should return a list of tuples, where each tuple contains the reversed case student name and their corresponding letter grade.

    Example:
    grade_and_case(['Amy', 'BOB', 'miLEs'], [4.0, 3, 1.7]) ==> [('aMY', 'A+'), ('bob', 'B'), ('MIleS', 'C-')]
    """
    return [(s[i].swapcase(), get_grade(grades[i])) for i in range(len(s))]