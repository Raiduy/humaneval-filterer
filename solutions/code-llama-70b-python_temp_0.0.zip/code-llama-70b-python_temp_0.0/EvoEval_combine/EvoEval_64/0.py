
def modp_prime_numbers(n: int, p: int):
    """Implement a function that takes two non-negative integers n and p, first calculate 2^n modulo p, 
    then return an array of the first calculated modulo result integers that are prime numbers and less than the calculated modulo result.
    If no prime numbers are found within the range, return an empty array.
    For example:
    modp_prime_numbers(5, 11) => [2,3,5,7]
    modp_prime_numbers(3, 5) => [2]
    modp_prime_numbers(0, 101) => []
    modp_prime_numbers(3, 11) => [2,3,5,7]
    modp_prime_numbers(100, 101) => []
    """
    if n < 0 or p < 0:
        raise ValueError('n and p should be non-negative integers')
    if p == 1:
        return []
    result = []
    for i in range(2, pow(2, n) % p):
        if is_prime(i):
            result.append(i)
    return result