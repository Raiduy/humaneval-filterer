
import math

def minSubArraySumEvenOdd(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums. Then, return a tuple that has the number of even and odd digits in 
    this minimum sum respectively.

    Example:
    minSubArraySumEvenOdd([2, 3, 4, 1, 2, 4]) == (0, 1)  # minimum sum is 1 which has 0 even digit and 1 odd digit
    minSubArraySumEvenOdd([-1, -2, -3]) == (1, 0)  # minimum sum is -6 which has 1 even digit and 0 odd digit
    """
    minimum = sum(nums)
    length = len(nums)
    even = odd = int(minimum) % 2
    for l in range(len(nums)):
        for i in range(len(nums) - l):
            s = sum(nums[i:i + l + 1])
            if s < minimum:
                minimum = s
                length = l + 1
                even = int(minimum) % 2
                odd = int(minimum) // 2
    return (even, odd)