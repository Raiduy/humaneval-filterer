
def planet_vowel_count(planet1, planet2):
    """
    There are eight planets in our solar system: the closest to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.

    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return an integer representing the number of vowels 
    in the names of the planets whose orbits are located between the orbit of 
    planet1 and the orbit of planet2, sorted by the proximity to the sun. 

    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given planet name.

    If planet1 or planet2 are not correct planet names, the function should return 0.

    Examples
    planet_vowel_count("Jupiter", "Neptune") ==> 5  # (Saturn = 2, Uranus = 3)
    planet_vowel_count("Earth", "Mercury") ==> 2  # (Venus = 2)
    planet_vowel_count("Mercury", "Uranus") ==> 10  # (Venus = 2, Earth = 2, Mars = 1, Jupiter = 3, Saturn = 2)
    """
    planets = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune']
    vowels = ['a', 'e', 'i', 'o', 'u']
    count = 0
    if planet1 in planets and planet2 in planets:
        if planet1 == planet2:
            return 0
        else:
            if planet1 in planet2:
                (planet1, planet2) = (planet2, planet1)
            for planet in planets:
                if planet1 in planet and planet2 in planet:
                    for letter in planet:
                        if letter.lower() in vowels:
                            count += 1
                elif planet1 in planet:
                    for letter in planet:
                        if letter.lower() in vowels:
                            count += 1
                elif planet2 in planet:
                    for letter in planet:
                        if letter.lower() in vowels:
                            count += 1
                else:
                    continue
            return count
    else:
        return 0