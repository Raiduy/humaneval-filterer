from typing import List

def sort_happy_numbers(numbers: str) -> str:
    """ 
    Input is a space-delimited string of numerals from 'zero' to 'nine'. Valid choices are 'zero', 'one', 'two', 
    'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'. This function has two main operations:
    
    1) It checks if the string of numbers is 'happy'. A string is happy if, after removing spaces from the string, every 3 consecutive letters are distinct.
    For instance, 'one two three' is not happy, but 'one one two' is happy. If the string is not happy, return 'Not a happy string'.
    
    2) If the string is happy, it sorts the string with numbers from smallest to largest and returns the sorted string.
    
    >>> sort_happy_numbers('three one five')
    'Not a happy string'
    
    >>> sort_happy_numbers('three two two')
    'Not a happy string'
    
    >>> sort_happy_numbers('five two eight')
    'two five eight'
    """
    numbers = numbers.split()
    for i in range(len(numbers) - 2):
        if numbers[i] == numbers[i + 1] or numbers[i] == numbers[i + 2] or numbers[i + 1] == numbers[i + 2]:
            return 'Not a happy string'
    numbers = [num.replace('zero', '0') for num in numbers]
    numbers = [num.replace('one', '1') for num in numbers]
    numbers = [num.replace('two', '2') for num in numbers]
    numbers = [num.replace('three', '3') for num in numbers]
    numbers = [num.replace('four', '4') for num in numbers]
    numbers = [num.replace('five', '5') for num in numbers]
    numbers = [num.replace('six', '6') for num in numbers]
    numbers = [num.replace('seven', '7') for num in numbers]
    numbers = [num.replace('eight', '8') for num in numbers]
    numbers = [num.replace('nine', '9') for num in numbers]
    numbers = sorted(numbers)
    numbers = [num.replace('0', 'zero') for num in numbers]
    numbers = [num.replace('1', 'one') for num in numbers]
    numbers = [num.replace('2', 'two') for num in numbers]
    numbers = [num.replace('3', 'three') for num in numbers]
    numbers = [num.replace('4', 'four') for num in numbers]
    numbers = [num.replace('5', 'five') for num in numbers]
    numbers = [num.replace('6', 'six') for num in numbers]
    numbers = [num.replace('7', 'seven') for num in numbers]
    numbers = [num.replace('8', 'eight') for num in numbers]
    numbers = [num.replace('9', 'nine') for num in numbers]
    return ' '.join(numbers)