def transform_dict(input_dict):
    """
    Create a function that takes a dictionary as an input where keys are strings and values are strings 
    representing numbers. The function should return a new dictionary where the keys remain the same, 
    but each value is replaced with the closest integer to it. If the number is equidistant from two 
    integers, round it away from zero. The function should return an empty dictionary if keys are not 
    all in upper case or all in lower case.

    The function should also return an empty dictionary if the given dictionary is empty or if keys are not all strings.

    Examples:

    >>> transform_dict({"a":"10", "b":"15.3"})
    {"a": 10, "b": 15}
    >>> transform_dict({"A":"10.5", "B":"-15.5"})
    {"A": 11, "B": -16}
    >>> transform_dict({"a":"10", "B":"15.3"})
    {}
    >>> transform_dict({"a": "10.5", 8: "-15.5"})
    {}

    Note:
    Rounding away from zero means that if the given number is equidistant from two integers, the one 
    you should return is the one that is the farthest from zero. For example, if the value string 
    represents "14.5", it should return 15 and if it represents "-14.5", it should return -15.
    """
    keys = input_dict.keys()
    values = input_dict.values()
    if not all((isinstance(key, str) for key in keys)):
        return {}
    if not all((key.islower() for key in keys)) and (not all((key.isupper() for key in keys))):
        return {}
    if not all((isinstance(value, str) for value in values)):
        return {}
    new_dict = {}
    for key in keys:
        value = input_dict[key]
        value = float(value)
        value = round_away_from_zero(value)
        value = int(value)
        new_dict[key] = value
    return new_dict