
def mixed_solution(arr):
    """
    Write a function mixed_solution which takes an array of integers. This function should return the sum of all of the odd
    elements that are in even positions and has a sum of their digits > 0. 
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    
    Examples:
    >>> mixed_solution([]) == 0
    >>> mixed_solution([-1, 11, -11]) == 0
    >>> mixed_solution([1, 1, 2]) == 1
    >>> mixed_solution([5, 8, 7, 1]) == 12
    >>> mixed_solution([3, 3, -3, 3, 3]) == 6
    >>> mixed_solution([-35, 13, 24, 321]) == -35
    """
    return sum([x for (i, x) in enumerate(arr) if i % 2 == 0 and sum(map(int, str(x))) > 0 and (x % 2 == 1)])