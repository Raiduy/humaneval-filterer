
def hex_grade_calculator(grades):
    """
    A professor in computer science has a unique way of grading his students. He evaluates the students based on their scores and assigns a hexadecimal grade. However, the professor is interested in knowing how many students have received prime hexadecimal grades. 
    
    He uses the following table to assign grades:
             GPA        |    Hexadecimal grade
              4.0                     F
            > 3.7                     E 
            > 3.3                     D 
            > 3.0                     C
            > 2.7                     B 
            > 2.3                     A
            > 2.0                     9
            > 1.7                     8
            > 1.3                     7
            > 1.0                     6
            > 0.7                     5 
            > 0.0                     4
              0.0                     3
              
    The prime numbers in hexadecimal are 2, 3, 5, 7, B (=decimal 11), D (=decimal 13).
    So from the above table, the prime grades are 'D', 'B', '7', '5', '3'.

    You are required to write a function that takes a list of GPAs as input and return the count of students who have received prime grades. 

    Example:
    hex_grade_calculator([4.0, 3, 2.75, 1.9, 3.5]) ==> 3
    Explanation: Based on the GPA the grades would be ['F', 'B', 'B', '8', 'D']. Out of these grades, 'D' and 'B' are prime grades. So, the function returns 3.
    """
    prime_grades = ['D', 'B', '7', '5', '3']
    return len([grade for grade in [grade_calculator(gpa) for gpa in grades] if grade in prime_grades])