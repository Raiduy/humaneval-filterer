
def find_max_triple_sum(x, y, n):
    """
    This function takes two positive numbers x and y, and a positive integer n. It first identifies the
    largest even integer in the range [x, y] inclusive, if there's no such number, it should return -1. 

    Then the function should create an integer array a of length n. For each i (1 ≤ i ≤ n), 
    the value of a[i] = i * i - i + 1. 

    The function then finds and returns the sum of the largest triple (a[i], a[j], a[k]) in array a 
    where i < j < k, and a[i] + a[j] + a[k] is a multiple of 3. 

    If no such triple exists, the function returns -1. If the largest even integer in the range [x, y] 
    inclusive is found, it should be added to the sum of the largest triple. 

    Examples:
    find_max_triple_sum(12, 15, 5) = 14 + 21 = 35
    find_max_triple_sum(13, 17, 6) = 16 + 28 = 67
    """
    largest_even = 0
    for i in range(x, y + 1):
        if i % 2 == 0:
            largest_even = i
    a = []
    for i in range(1, n + 1):
        a.append(i * i - i + 1)
    largest_triple = []
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            for k in range(j + 1, len(a)):
                if a[i] + a[j] + a[k] % 3 == 0:
                    largest_triple = [a[i], a[j], a[k]]
    if len(largest_triple) == 0:
        return -1
    else:
        return sum(largest_triple) + largest_even