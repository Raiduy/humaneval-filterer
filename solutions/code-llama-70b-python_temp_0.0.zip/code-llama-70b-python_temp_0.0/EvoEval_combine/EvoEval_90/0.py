
def vowels_in_dict_keys(dict):
    """
    Given a dictionary, write a function that checks if all the keys are strings in either lower case or upper case 
    and returns a dictionary where keys are the same keys from the input dictionary and the values are the count of vowels in each key. 
    If the keys are not all in lower case nor all in upper case, return an empty dictionary. 
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a vowel, but only when it is at the end of the given word.
    The function should return an empty dictionary if the input dictionary itself is empty.
    
    Examples:
    vowels_in_dict_keys({"a":"apple", "b":"banana"}) should return {"a":1, "b":0}.
    vowels_in_dict_keys({"a":"apple", "A":"banana", "B":"banana"}) should return {}.
    vowels_in_dict_keys({"a":"apple", 8:"banana", "a":"apple"}) should return {}.
    vowels_in_dict_keys({"Name":"John", "Age":"36", "City":"Houston"}) should return {}.
    vowels_in_dict_keys({"STATE":"NC", "ZIP":"12345" }) should return {"STATE": 2, "ZIP": 1}.
    """
    vowels = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']
    y_vowels = ['y', 'Y']
    result = {}
    if not dict:
        return {}
    for key in dict.keys():
        if not isinstance(key, str):
            return {}
    for key in dict.keys():
        if not key.islower() and (not key.isupper()):
            return {}
    for key in dict.keys():
        vowel_count = 0
        for char in key:
            if char in vowels:
                vowel_count += 1
            if char in y_vowels and key.index(char) == len(key) - 1:
                vowel_count += 1
        result[key] = vowel_count
    return result