def palindromic_and_odd_digit_array(arr):
    """Given a list of positive integers 'arr', return the minimum number of elements
    that need to be changed to make the array both palindromic and containing only odd digits. 
    A palindromic array is an array that is read the same backwards and forwards. 
    An array containing only odd digits is an array where every digit in every element is an odd number. 
    In one change, you can change one element to any other positive integer.
    
    For example:
    >>> palindromic_and_odd_digit_array([1, 2, 3, 5, 4, 2, 9, 6])
    4
    >>> palindromic_and_odd_digit_array([1, 2, 3, 4, 3, 6, 2])
    4
    >>> palindromic_and_odd_digit_array([1, 2, 3, 2, 1])
    2
    """
    if arr == arr[::-1]:
        for i in arr:
            if i % 2 == 0:
                return sum(list(map(lambda x: 1 if x % 2 == 0 else 0, arr)))
        return 0
    arr_rev = arr[::-1]
    count = 0
    for i in range(len(arr)):
        if arr[i] != arr_rev[i]:
            count += 1
    for i in arr_rev:
        if i % 2 == 0:
            return count + sum(list(map(lambda x: 1 if x % 2 == 0 else 0, arr_rev)))
    return count