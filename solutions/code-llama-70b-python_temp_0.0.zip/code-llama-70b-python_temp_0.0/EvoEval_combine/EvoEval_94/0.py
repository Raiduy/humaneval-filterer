
def sort_count_nums(arr):
    """
    Write a function sort_count_nums which takes an array of integers and does the following:

    1) Counts the number of elements which has a sum of digits > 0. If a number is negative, 
    then its first signed digit will be negative.
    e.g. -123 has signed digits -1, 2, and 3.

    2) After counting, the function should then sort the initial array in ascending order if the 
    count of elements with sum of digits > 0 is odd, or sort it in descending order if the count 
    is even.

    Note that the function should not change the given array.

    Examples:
    * sort_count_nums([]) => []
    * sort_count_nums([5]) => [5]
    * sort_count_nums([2, 4, 3, 0, 1]) => [4, 3, 2, 1, 0]
    * sort_count_nums([-1, 11, -11, 2, 4, 3, 0, 1, 5, 6]) => [-11, -1, 0, 1, 2, 3, 4, 5, 6, 11]
    """
    pass