
def happy_case_string(s):
    """You are given a string s.
    Your task is to first check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct.
    If the string is happy, reverse the case for each letter in the string. 
    If s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string is not happy or if it contains no letters, reverse the string.

    The function should return the resulted string.
    
    Examples:
    happy_case_string("1234") = "4321"
    happy_case_string("ab") = "ba"
    happy_case_string("#a@C") = "#A@c"
    happy_case_string("abcd") = "ABCD"
    happy_case_string("aabb") = "bbaa"
    happy_case_string("adb") = "ADB"
    happy_case_string("*#@") = "@#*"
    """
    return