
def get_common_max_triples(n, l1: list):
    """
    You are given a positive integer n and a list 'l1'. You have to create an integer array a of length n.
        For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
    You need to find the common elements between the array 'a' and list 'l1' and return them in a sorted order. 
    If any number is a multiple of 3 in the common elements list, you then have to find the total number of 
    triples (a[i], a[j], a[k]) of 'a' where i < j < k, and a[i] + a[j] + a[k] is a multiple of 3.
    If there are no numbers that are multiples of 3 in the list of common elements, return 0.

    Example :
        Input: n = 5, l1 = [1, 7, 13, 21, 4, 5]
        Output: ([1, 7, 13, 21], 1)
        Explanation: 
        a = [1, 3, 7, 13, 21]
        The common elements are [1, 7, 13, 21].
        The only valid triple is (1, 7, 13).
    """
    a = [i * i - i + 1 for i in range(1, n + 1)]
    common_elements = list(set(a) & set(l1))
    common_elements.sort()
    if not common_elements:
        return (common_elements, 0)
    count = 0
    for i in range(len(common_elements)):
        for j in range(i + 1, len(common_elements)):
            for k in range(j + 1, len(common_elements)):
                if (common_elements[i] + common_elements[j] + common_elements[k]) % 3 == 0:
                    count += 1
    return (common_elements, count)