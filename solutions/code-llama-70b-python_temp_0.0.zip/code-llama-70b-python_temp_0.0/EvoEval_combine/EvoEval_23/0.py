
def special_stone_factorial(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones. The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.

    For each level, calculate the Brazilian factorial (defined as: brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!), 
    where n is the number of stones in the level.

    Return the list of Brazilian factorials for each level.

    For example:
    >>> special_stone_factorial(3)
    [12, 34560, 125411328000]
    """
    from math import factorial

    def brazilian_factorial(n):
        return factorial(n) * factorial(n - 1)
    if n == 1:
        return [1]
    stones = n
    result = []
    for level in range(1, n + 1):
        result.append(brazilian_factorial(stones))
        if stones % 2 == 0:
            stones += 1
        else:
            stones += 2
    return result