def sorted_happy_strings(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that are not happy or have odd lengths from it,
    and returns the resulted list in a sorted order.
    
    A string is considered happy if its length is at least 3 and every 3 consecutive letters are distinct.
    For example: "abcd" and "adb" are happy strings, but "a", "aa", "aabb", and "xyy" are not.

    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.

    The function should return a list of strings in sorted order by ascending length and alphabetically for words with same length.
    
    For example:
    assert sorted_happy_strings(["abc", "a", "aaabcd", "abcd"]) => ["abcd"]
    assert sorted_happy_strings(["abcd", "aaa", "abc", "abccba", "cd"]) => ["abcd"]
    """
    new_lst = []
    for word in lst:
        if happy(word):
            new_lst.append(word)
    new_lst = sorted(new_lst, key=len)
    return new_lst