
def get_closest_upper_vowel(word):
    """You are given a word. Your task is to find the closest uppercase vowel that stands between 
    two consonants from the right side of the word (case sensitive).

    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any uppercase vowel met the above condition. 

    Additionally, the vowel must stand at an even index in the string.

    You may assume that the given string contains English letter only.

    Example:
    get_closest_upper_vowel("yoUgUrt") ==> "U"
    get_closest_upper_vowel("FULL") ==> ""
    get_closest_upper_vowel("quick") ==> ""
    get_closest_upper_vowel("ab") ==> ""
    """