def max_freq_and_sum_check(lst, a, b):
    """
    You are given a non-empty list of positive integers and two additional integers a and b.
    The function should first find the greatest integer in the list that has a frequency greater than or equal 
    to the value of the integer itself. Let's call this value 'max_freq'.
    If there's no such element in the list, 'max_freq' is -1.
    After finding 'max_freq', the function should check if either a or b is equal to the sum of 'max_freq' and the other integer.
    If this is true, return a tuple: (max_freq, True)
    If this is not true, return a tuple: (max_freq, False)
    If 'max_freq' is -1, return (-1, False)

    Examples:
        max_freq_and_sum_check([4, 1, 2, 2, 3, 1], 2, 0) ➞ (2, True)
        max_freq_and_sum_check([1, 2, 2, 3, 3, 3, 4, 4, 4], 5, 2) ➞ (3, True)
        max_freq_and_sum_check([5, 5, 4, 4, 4], 8, 3) ➞ (-1, False)
        max_freq_and_sum_check([5, 5, 4, 4, 4], 10, 5) ➞ (-1, False)
    """
    max_freq = -1
    for i in lst:
        if lst.count(i) >= i:
            max_freq = max(max_freq, i)
    if max_freq == -1:
        return (-1, False)
    if a == max_freq + b or b == max_freq + a:
        return (max_freq, True)
    else:
        return (max_freq, False)