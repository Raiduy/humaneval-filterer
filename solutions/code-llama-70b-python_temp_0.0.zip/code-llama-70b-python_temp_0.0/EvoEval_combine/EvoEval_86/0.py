
def evaluate_common_expressions(operators, operand_lists):
    """
    Given an operators list and a list of operand_lists, find the common operands between 
    all operand_lists then evaluate the algebraic expression built using the common operands 
    with the given operators. The operands should be sorted in ascending order.  Return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operators = ['+', '*', '-']
    operand_lists = [[2, 3, 4, 5], [3, 5, 7, 8], [3, 4, 5, 9]]
    common_operands = [3, 5]  # common elements between all operand lists
    result = 3 + 5  # Using the operators from the operators list
    => result = 8

    Note:
        The length of the operators list is greater than or equal to the length of the common_operands list minus one.
        Each operand list consists of non-negative integers and has at least two operands.
        The operators list has at least one operator.
        Return None if there are no common operands.

    """
    common_operands = set(operand_lists[0])
    for operand_list in operand_lists:
        common_operands = common_operands.intersection(set(operand_list))
    if len(common_operands) == 0:
        return None
    common_operands = list(common_operands)
    common_operands.sort()
    result = common_operands[0]
    for i in range(len(operators)):
        result = eval(str(result) + operators[i] + str(common_operands[i + 1]))
    return result