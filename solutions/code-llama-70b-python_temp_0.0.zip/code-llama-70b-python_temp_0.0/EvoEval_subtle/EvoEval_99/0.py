
def closest_integer(value):
    """
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it towards zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding towards zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    closest to zero. For example closest_integer("14.5") should
    return 14 and closest_integer("-14.5") should return -14.
    """
    from math import floor, ceil
    if value.count('.') == 1:
        idx = value.index('.')
        dec = float(value[idx + 1])
        if dec > 0 and dec < 5:
            return int(value[:idx])
        elif dec >= 5 and dec <= 9:
            return int(ceil(float(value)))
        elif dec == 5 and int(value[:idx]) % 2 == 0:
            return int(value[:idx])
        elif dec == 5 and int(value[:idx]) % 2 != 0:
            return int(floor(float(value)))
        else:
            return int(floor(float(value)))
    else:
        return int(value)