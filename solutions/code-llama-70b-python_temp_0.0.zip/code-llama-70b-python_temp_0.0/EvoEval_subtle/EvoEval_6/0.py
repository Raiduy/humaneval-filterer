
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses. Additionally, return the list in descending order.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [3, 3, 2, 1]
    """
    stack = []
    max_nesting_level_list = []
    tokens = paren_string.split()
    for token in tokens:
        stack = []
        for char in token:
            if char == '(':
                stack.append(char)
            elif char == ')':
                if len(stack) == 0:
                    raise ValueError('Unbalanced closing parenthesis in input string.')
                stack.pop()
            else:
                raise ValueError('Invalid character in input string.')
        if len(stack) != 0:
            raise ValueError('Unbalanced opening parenthesis in input string.')
        max_nesting_level_list.append(len(token) // 2)
    return sorted(max_nesting_level_list, reverse=True)