
def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence. Do not use recursion. Return string representation.
    >>> fib4(5)
    '4'
    >>> fib4(6)
    '8'
    >>> fib4(7)
    '14'
    """
    n0 = 0
    n1 = 0
    n2 = 2
    n3 = 0
    current_n = 0
    for i in range(n):
        current_n = n0 + n1 + n2 + n3
        n0 = n1
        n1 = n2
        n2 = n3
        n3 = current_n
    return str(current_n)