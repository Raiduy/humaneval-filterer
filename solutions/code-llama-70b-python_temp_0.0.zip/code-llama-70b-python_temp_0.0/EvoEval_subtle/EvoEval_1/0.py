from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string. 
    Return the list in ascending alphabetical order 
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['(()())', '(())', '()']
    """
    if len(paren_string) == 0:
        return []
    stack = []
    index_dict = {}
    for (index, char) in enumerate(paren_string):
        if char == '(':
            stack.append(index)
        elif char == ')':
            if len(stack) == 0:
                raise ValueError('The input string is not balanced')
            idx = stack.pop()
            index_dict[idx] = index
    if len(stack) != 0:
        raise ValueError('The input string is not balanced')
    paren_list = []
    for idx in index_dict:
        paren_str = paren_string[idx:index_dict[idx] + 1]
        paren_list.append(paren_str)
    paren_list.sort()
    return paren_list