

def monotonic(l: list):
    """Return True if list elements are monotonically increasing or decreasing. If the list is empty, return False.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    >>> monotonic([])
    False
    """
    if len(l) <= 1:
        return False
    first_pair = (l[0], l[1])
    rest = l[2:]
    if first_pair[0] < first_pair[1]:
        for i in range(len(rest)):
            if rest[i] >= rest[i + 1]:
                return False
    elif first_pair[0] > first_pair[1]:
        for i in range(len(rest)):
            if rest[i] <= rest[i + 1]:
                return False
    else:
        return False
    return True