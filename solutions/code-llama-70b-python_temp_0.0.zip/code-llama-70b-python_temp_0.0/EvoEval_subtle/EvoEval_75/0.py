
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 4 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(90) == True
    90 = 2 * 3 * 3 * 5
    """
    while a % 2 == 0:
        a /= 2
    while a % 3 == 0:
        a /= 3
    while a % 5 == 0:
        a /= 5
    if a == 1:
        return True
    else:
        return False