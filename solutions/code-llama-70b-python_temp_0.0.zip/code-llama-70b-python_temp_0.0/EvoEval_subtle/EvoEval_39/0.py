
def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime. If the number is even, return None.
    >>> prime_fib(1)
    None
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    f_minus_2 = 0
    f_minus_1 = 1
    for _ in range(n):
        f = f_minus_2 + f_minus_1
        f_minus_2 = f_minus_1
        f_minus_1 = f
    if f % 2 == 0:
        return None
    return f