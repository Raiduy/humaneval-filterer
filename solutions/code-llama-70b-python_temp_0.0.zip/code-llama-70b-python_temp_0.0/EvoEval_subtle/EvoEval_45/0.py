

def triangle_perimeter(a, b, c):
    """Given length of three sides return perimeter for a triangle.
    >>> triangle_perimeter(5, 3, 3)
    11
    """
    return a + b + c