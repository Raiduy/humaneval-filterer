

def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 3 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'THST'
    >>> encode('This is a message')
    'tHLS LS D MHSSDGH'
    """
    vowels = 'aeiouAEIOU'
    vowels_replace = dict(zip(vowels, vowels[3:] + vowels[:3]))
    return ''.join((c.swapcase() if c not in vowels else vowels_replace[c] for c in message))