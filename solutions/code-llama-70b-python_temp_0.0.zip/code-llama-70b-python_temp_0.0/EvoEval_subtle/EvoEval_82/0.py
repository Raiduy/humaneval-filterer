
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise. The function should ignore white spaces in the string length calculation.
    Examples
    prime_length('Hello') == True
    prime_length(' a b c d c b a ') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    non_spaces = set(string.replace(' ', ''))
    return len(non_spaces) in (0, 1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31)