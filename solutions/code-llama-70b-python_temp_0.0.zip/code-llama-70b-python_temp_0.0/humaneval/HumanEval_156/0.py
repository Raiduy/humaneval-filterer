
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    roman_nums = {
        1: 'i',
        5: 'v',
        10: 'x',
        50: 'l',
        100: 'c',
        500: 'd',
        1000: 'm',
    }
    result = []
    for digit_idx in range(len(str(number))):
        digit = int(str(number)[digit_idx])
        if digit <= 3:
            result.append(roman_nums[10**digit_idx] * digit)
        elif digit == 4:
            result.append(roman_nums[10**digit_idx] + roman_nums[10**(digit_idx+1)])
        elif digit < 9:
            result.append(roman_nums[10**(digit_idx+1)] + roman_nums[10**digit_idx] * (digit-5))
        else:
            result.append(roman_nums[10**digit_idx] + roman_nums[10**(digit_idx+1)])
    return ''.join(result).lower()
