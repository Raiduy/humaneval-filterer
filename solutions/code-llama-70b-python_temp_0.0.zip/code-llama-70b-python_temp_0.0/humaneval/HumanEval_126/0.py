
def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''
    # version 1: my solution
    # check if lst is sorted
    # check if there is no more than 1 duplicate of the same number
    # return True if both conditions are met
    # return False if either condition is not met
    # for i in range(len(lst)-1):
    #     if lst[i] > lst[i+1]:
    #         return False
    # for i in range(len(lst)-1):
    #     if lst[i] == lst[i+1]:
    #         if lst[i+1] != lst[i+2]:
    #             pass
    #         else:
    #             return False
    # return True

    # version 2: Shawn's solution
    # check if lst is sorted
    # check if there is no more than 1 duplicate of the same number
    # return True if both conditions are met
    # return False if either condition is not met
    for i in range(len(lst)-2):
        if lst[i] > lst[i+1] or lst[i] == lst[i+1] and lst[i+1] != lst[i+2]:
            return False
    return True

