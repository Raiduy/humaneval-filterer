
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    # Count of numbers that start with 1
    start_with_1 = 0

    # Count of numbers that end with 1
    end_with_1 = 0

    # Total count
    total = 0

    # Iterate through all the numbers
    for i in range(1, n + 1):

        # Convert the number to string
        num = str(i)

        # Check if the number starts with 1
        if num[0] == '1':
            start_with_1 += 1

        # Check if the number ends with 1
        if num[-1] == '1':
            end_with_1 += 1

    # Add the count of numbers starting with 1 to count of numbers ending with 1
    total = start_with_1 + end_with_1

    # Check if the number is single digit and starts and ends with 1
    if str(n)[0] == '1' and str(n)[-1] == '1':
        total -= 1

    return total

