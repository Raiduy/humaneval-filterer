

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    # base-10 to base-2, base-3, ...
    # Approach:
    # Repeatedly divide by base to get the remainder
    # Reverse the order of the remainder and convert to string
    # Convert to int
    # return the value
    # return int("".join(reversed(list(map(str, remainder)))), base)
    # return int("".join(reversed([str(x % base) for x in divmod(x, base)])), base)
    # return int("".join([str(x % base) for x in divmod(x, base)][::-1]), base)
    return int("".join([str(x % base) for x in divmod(x, base)][::-1]), base)

