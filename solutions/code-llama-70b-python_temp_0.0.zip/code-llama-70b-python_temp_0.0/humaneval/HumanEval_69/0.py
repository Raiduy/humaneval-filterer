
def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''

    # 使用字典存储列表中的数字和出现的次数
    dict = {}
    for i in lst:
        if i in dict:
            dict[i] += 1
        else:
            dict[i] = 1
    
    # 找出出现次数大于等于数字的数字中的最大值
    max = -1
    for i in dict:
        if i == dict[i]:
            if i > max:
                max = i
    return max

