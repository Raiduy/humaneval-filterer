
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    from collections import Counter
    no_even_digits = []
    for num in x:
        str_num = str(num)
        digits = Counter(str_num)
        even_count = 0
        for key in digits.keys():
            if int(key) % 2 == 0:
                even_count += 1
        if even_count == 0:
            no_even_digits.append(num)
    return sorted(no_even_digits)

