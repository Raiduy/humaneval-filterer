
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    #plan
    # 1. take first number in list and set it as the min
    # 2. loop through list
    # 3. add each number to a temp variable
    # 4. if temp variable is less than min set it as min
    # 5. return min

    # 1. take first number in list and set it as the min
    min = nums[0]
    # 2. loop through list
    for i in range(len(nums)):
        # 3. add each number to a temp variable
        temp = nums[i]
        # 4. if temp variable is less than min set it as min
        if temp < min:
            min = temp
    # 5. return min
    return min

