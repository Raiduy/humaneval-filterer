from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    # split the string into a list of strings
    num_list = numbers.split()
    # define a mapping of word to digit
    word_to_digit = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }
    # define a function to map the word to digit
    word_to_digit_func = lambda word: word_to_digit[word]
    # map the list of words to a list of digits
    digit_list = list(map(word_to_digit_func, num_list))
    # sort the list of digits
    digit_list.sort()
    # define a function to map the digit to a word
    digit_to_word_func = lambda digit: list(word_to_digit.keys())[list(word_to_digit.values()).index(digit)]
    # map the list of digits to a list of words
    sorted_num_list = list(map(digit_to_word_func, digit_list))
    # join the list of words into a string
    sorted_numbers = " ".join(sorted_num_list)
    return sorted_numbers

