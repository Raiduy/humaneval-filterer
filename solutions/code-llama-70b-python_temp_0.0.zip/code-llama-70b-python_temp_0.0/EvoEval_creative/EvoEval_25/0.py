def word_frequency_analysis(text: str, word: str):
    """Return the frequency of the given word in a text. Also, return the sentence in which the word appears the most times.

    The function will return a tuple where the first element is the frequency of the word, and the second element is the sentence with the max frequency of the word. If the word is not found in the text, return (0, ""). 

    Assume that sentences end with a period.

    >>> word_frequency_analysis("Hello world. I love this world.", "world")
    (2, "Hello world")

    >>> word_frequency_analysis("This is the best day. I love this day because it's sunny.", "day")
    (2, "This is the best day")

    >>> word_frequency_analysis("This is a test. Testing is fun.", "test")
    (1, "This is a test")

    >>> word_frequency_analysis("Welcome to the world of coding.", "python")
    (0, "")
    """
    word = word.lower()
    text = text.lower()
    frequency = 0
    max_frequency = 0
    sentence_with_max_frequency = ''
    for sentence in text.split('.'):
        frequency = sentence.count(word)
        if frequency > max_frequency:
            max_frequency = frequency
            sentence_with_max_frequency = sentence.strip()
    return (max_frequency, sentence_with_max_frequency)