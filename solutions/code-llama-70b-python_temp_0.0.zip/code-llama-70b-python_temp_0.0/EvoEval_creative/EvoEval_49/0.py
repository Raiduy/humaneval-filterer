def morse_decoder(msg):
    """You have been tasked to write a function that deciphers Morse code into 
    plain text. Morse code is a method used in telecommunication to encode 
    text characters as sequences of two different signal durations, called 
    dots and dashes, or dits and dahs.
    The international Morse code encodes the basic Latin alphabet, some extra 
    Latin letters, the Arabic numerals and a small set of punctuation and 
    procedural signals. Morse code is usually transmitted by on-off keying of 
    an information-carrying medium such as electric current, sound, visible 
    light, etc. 

    In your function, the Morse code transmission is represented as a string 
    where "0" represents a dot, "1" represents a dash, and " " (space) 
    represents a pause between individual characters. Words are separated by 
    a "/" symbol. 

    For simplicity, you only need to decode the basic Latin alphabet and 
    Arabic numerals. The Morse code mapping for these characters is as 
    follows:

    A: '01', B: '1000', C: '1010', D: '100', E: '0', F: '0010', G: '110', 
    H: '0000', I: '00', J: '0111', K: '101', L: '0100', M: '11', N: '10', 
    O: '111', P: '0110', Q: '1101', R: '010', S: '000', T: '1', U: '001', 
    V: '0001', W: '011', X: '1001', Y: '1011', Z: '1100', 1: '01111', 
    2: '00111', 3: '00011', 4: '00001', 5: '00000', 6: '10000', 7: '11000', 
    8: '11100', 9: '11110', 0: '11111' 

    Examples:
    For msg = "010101/01 1010 0 110 0" the output should be "ACEGE".
    For msg = "01111 00111/00011 00001/10000 11000 11100 11110 11111" the output should be "12 34 67890"
    """
    morse_dict = {'01': 'A', '1000': 'B', '1010': 'C', '100': 'D', '0': 'E', '0010': 'F', '110': 'G', '0000': 'H', '00': 'I', '0111': 'J', '101': 'K', '0100': 'L', '11': 'M', '10': 'N', '111': 'O', '0110': 'P', '1101': 'Q', '010': 'R', '000': 'S', '1': 'T', '001': 'U', '0001': 'V', '011': 'W', '1001': 'X', '1011': 'Y', '1100': 'Z', '01111': '1', '00111': '2', '00011': '3', '00001': '4', '00000': '5', '10000': '6', '11000': '7', '11100': '8', '11110': '9', '11111': '0'}
    return ''.join([morse_dict[i] for i in msg.split('/')])