def text_to_morse(text):
    """You will be given a string of text and your task is to convert it to morse code. The function 
    should return a string, with each character representing a corresponding Morse code. 

    Morse Code is a system of communication developed by Samuel F.B. Morse that uses a series of dots and dashes to represent letters, numbers and other symbols. In Morse Code, each letter of the English alphabet is represented by a specific series of dots and dashes.

    The Morse code for each letter should be separated by a single space, and each word should be separated by a double space. 

    You can use the following dictionary for the Morse code equivalents:

    {'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.', 
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 
    'Y': '-.--', 'Z': '--..', ' ': '  '}

    Examples:
    text_to_morse("HELLO WORLD")  # returns ".... . .-.. .-.. ---   .-- --- .-. .-.. -.."
    text_to_morse("MORSE CODE")   # returns "-- --- .-. ...   -.-. --- -.. ."
    """
    morse_code = {'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--', 'Z': '--..', ' ': '  '}
    return ''.join((morse_code[char] for char in text.upper()))