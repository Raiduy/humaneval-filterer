def transform_canvas(canvas: str) -> str:
    """
    You have an canvas containing either '#' (representing a wall), '-' (representing 
    an empty space), or 'P' (representing the point at which a painter starts). The painter 
    can move horizontally on the canvas and paints all empty spaces he encounters
    with '*' without crossing or hitting the walls.
    
    The task is to return an updated canvas with all the accessible spaces painted, 
    keeping wall configuration and unaccessible spaces same. If the canvas contains no painter 'P', 
    return the canvas as it is. If there are more than one 'P' or the number of painted space divides the empty spaces evenly, return 'Invalid canvas'.

    Examples:

    >>> transform_canvas('P----#-----#-----#-----')
    'P****#-----#-----#-----'
    
    >>> transform_canvas('--#-P#-----#-----#--#--')
    'Invalid canvas'
    
    >>> transform_canvas('-----#--P--#-----#-----')
    '-----#**P**#-----#-----'
    
    >>> transform_canvas('-----#-----#--P---#P----')
    'Invalid canvas'
    """
    canvas_list = list(canvas)
    painter_indices = [i for (i, x) in enumerate(canvas_list) if x == 'P']
    if len(painter_indices) != 1:
        return 'Invalid canvas'
    painter_index = painter_indices[0]
    wall_indices = [i for (i, x) in enumerate(canvas_list) if x == '#']
    closest_left_wall_index = max([i for i in wall_indices if i < painter_index])
    closest_right_wall_index = min([i for i in wall_indices if i > painter_index])
    empty_space = canvas_list[closest_left_wall_index + 1:closest_right_wall_index]
    if len(empty_space) % 2 == 0:
        return 'Invalid canvas'
    middle = len(empty_space) // 2
    left_indices = [closest_left_wall_index + 1 + i for i in range(middle)]
    right_indices = [closest_right_wall_index - 1 - i for i in range(len(empty_space) - middle)][::-1]
    empty_indices = left_indices + right_indices
    for i in empty_indices:
        canvas_list[i] = '*'