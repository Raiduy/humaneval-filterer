def create_alias(name: str) -> str:
    """ For a given name, create an alias following these rules:
        If the name includes a vowel, replace it with the next vowel in the cycle a->e->i->o->u->a. 
        If the name includes a consonant, replace it with the next consonant in alphabetical order, once 'z' is reached, loop back to 'b'.
        The alias should maintain the original names case (upper or lower)
        Ignore any non-alphabetical characters.

    >>> create_alias('John Doe')
    'Kujp Fui'
    """
    vowels = ['a', 'e', 'i', 'o', 'u']
    consonants = ['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z']
    name = name.lower()
    alias = ''
    for letter in name:
        if letter in vowels:
            alias += vowels[(vowels.index(letter) + 1) % 5]
        elif letter in consonants:
            alias += consonants[(consonants.index(letter) + 1) % 21]
        else:
            alias += letter
    if name[0].isupper():
        return alias.capitalize()
    else:
        return alias