
from typing import List

def find_rarest_element(elems: List[str]) -> str:
    """ Find the rarest element in a list of strings. If there are multiple rarest elements, return the one that appears first. 
    If the list is empty, return None.

    >>> find_rarest_element(['apple', 'banana', 'apple', 'orange', 'banana', 'orange', 'apple'])
    'banana'
    >>> find_rarest_element(['cat', 'dog', 'bird', 'cat', 'dog', 'cat'])
    'bird'
    >>> find_rarest_element([])
    None
    """
    if len(elems) == 0:
        return None
    elem_counts = {}
    for elem in elems:
        if elem in elem_counts:
            elem_counts[elem] += 1
        else:
            elem_counts[elem] = 1
    min_count = len(elems)
    rarest_elem = None
    for (elem, count) in elem_counts.items():
        if count < min_count:
            min_count = count
            rarest_elem = elem
    return rarest_elem