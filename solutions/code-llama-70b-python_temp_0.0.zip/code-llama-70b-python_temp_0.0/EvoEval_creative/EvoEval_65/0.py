def food_order(menu, order):
    """
    Imagine you are developing a system for a Fast Food Restaurant. They have a menu that is 
    a dictionary where the keys are the names of the food and the values are sequences of ingredients.
    However, customers often customize their orders by adding extra ingredients or removing some.
    
    Given a dictionary representing the menu and another dictionary representing a customer's order,
    your task is to return a new dictionary representing the final food order with customized ingredients.

    For example:
      menu = {"Burger": ["Bun", "Meat", "Cheese"], "Pizza": ["Dough", "Tomato Sauce", "Cheese"]}
      order = {"Burger": {"remove": ["Cheese"], "add": ["Mushrooms"]}, "Pizza": {"add": ["Pepperoni"]}}
      
      Returns:
      {"Burger": ["Bun", "Meat", "Mushrooms"], "Pizza": ["Dough", "Tomato Sauce", "Cheese", "Pepperoni"]}

    Assumptions:
      - An ingredient to be removed will always be in the original food order.
      - An ingredient to be added won't be in the original food order.
      - The order dictionary will not contain any food not on the menu.

    If the order dictionary is empty, return the original menu
      
    If the order dictionary is given but no ingredients are specified to be added or removed, return the original menu:
    """
    final_order = {}
    if not order:
        return menu
    for food in order:
        if food in menu:
            if order[food]:
                for action in order[food]:
                    if action == 'add':
                        for ingredient in order[food][action]:
                            menu[food].append(ingredient)
                    elif action == 'remove':
                        for ingredient in order[food][action]:
                            menu[food].remove(ingredient)
                final_order[food] = menu[food]
        else:
            print('{} is not on the menu.'.format(food))
    return final_order