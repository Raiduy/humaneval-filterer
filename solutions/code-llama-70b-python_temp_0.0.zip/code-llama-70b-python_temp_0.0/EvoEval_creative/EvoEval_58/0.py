def interstellar_translator(earth_phrase):
    """
    Write a function that takes an earth phrase, and translates it into 
    an alien language that follows a specific set of rules. The rules for the 
    translation are as follows:

    1. All vowels (a,e,i,o,u) should be replaced with the next vowel in the 
       sequence (a->e, e->i, i->o, o->u, u->a).
    2. All consonants should be replaced with the next consonant that appears 
       in the english alphabet. If the consonant is 'z', replace it with 'b'.
    3. All spaces should be replaced with the '@' symbol.
    4. The first letter of every word should be capitalized.
    5. If the original word started with a vowel, append 'xy' to the end of the word. 
       If the original word started with a consonant, append 'yz' to the end of the word.

    Assume the input is a string containing only lowercase letters and spaces.
    
    Examples:
    >>> interstellar_translator('hello world')
    'Jimmuyz@Xusmfyz'
    >>> interstellar_translator('this is a test')
    'Vjotyz@Otxy@Exy@Vitvyz'
    """
    vowels = {'a': 'e', 'e': 'i', 'i': 'o', 'o': 'u', 'u': 'a'}
    consonants = {'b': 'c', 'c': 'd', 'd': 'f', 'f': 'g', 'g': 'h', 'h': 'j', 'j': 'k', 'k': 'l', 'l': 'm', 'm': 'n', 'n': 'p', 'p': 'q', 'q': 'r', 'r': 's', 's': 't', 't': 'v', 'v': 'w', 'w': 'x', 'x': 'y', 'y': 'z', 'z': 'b'}
    words = earth_phrase.split()
    for i in range(len(words)):
        if words[i][0] in vowels:
            words[i] += 'xy'
        else:
            words[i] += 'yz'
        for j in range(len(words[i])):
            if words[i][j] in vowels:
                words[i] = words[i].replace(words[i][j], vowels[words[i][j]])
            elif words[i][j] in consonants:
                words[i]