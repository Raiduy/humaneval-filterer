def werewolf_transformation(n: int, m: int):
    """A werewolf's transformation is impacted by the lunar cycle.
    This cycle has n days (n > 0), and the transformation process is most
    intense on the m-th day of the cycle (m > 0, m <= n).

    On days other than the m-th day, the transformation percentage follows a
    linear pattern, increasing (+10%) or decreasing (-10%) from the previous day. On the
    m-th day, the transformation percentage doubles from the previous day,
    up to a maximum of 100%.
    After the m-th day, the transformation starts decreasing by -10% each day.

    The function werewolf_transformation calculates the werewolf
    transformation percentages over the course of one cycle given the length
    of the cycle (n) and the most intense day (m).

    The function should return a list of transformation percentages, as integers.

    >>> werewolf_transformation(5, 3)
    [0, 10, 20, 10, 0]

    >>> werewolf_transformation(7, 4)
    [0, 10, 20, 40, 30, 20, 10]

    >>> werewolf_transformation(10, 5)
    [0, 10, 20, 30, 60, 50, 40, 30, 20, 10]

    NOTE: the transformation process starts from the first day
    of the cycle with 0% transformation. Any transformation percentage should be truncated within the range of 0% and 100%.
    """
    start = 0
    end = 100
    transformation_percentages = []
    for day in range(n):
        if day < m - 1:
            start += 10
            transformation_percentages.append(start)
        elif day > m - 1:
            start -= 10
            transformation_percentages.append(start)
        else:
            start *= 2
            transformation_percentages.append(start)
    return transformation_percentages