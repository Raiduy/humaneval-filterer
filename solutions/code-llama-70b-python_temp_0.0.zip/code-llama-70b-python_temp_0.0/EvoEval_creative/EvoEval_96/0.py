def get_magic_indices(lst):
    """
    You are given a list of integers. Your task is to find and return all "magic" indices in the list. 
    An index is considered "magic" if it fulfils the following two conditions:
        1. The value at that index is a multiple of the index.
        2. The product of all digits in the value is equal to the index. 
        
    Negative values are treated as the same as positive ones.
    
    You should return a list of all magic indices, sorted in ascending order. If there is no magic index in the list, return an empty list.
    
    Note: Indices are 0-based

    Example :
        Input: lst = [0, 7, -6, 12, -20, 5, -7]
        Output: [0, 5]
        Explanation: 
        At index 0, value is 0, which is a multiple of 0, and the product of the digits equals the index
        At index 5, value is 5, and the product of the digits (5 = 5) equals the index.
    """
    magic_indices = []
    for i in range(len(lst)):
        if abs(lst[i]) % (i + 1) == 0:
            digits = [int(n) for n in str(abs(lst[i]))]
            if abs(lst[i]) == 0:
                magic_indices.append(i)
            elif i + 1 == reduce(lambda x, y: x * y, digits):
                magic_indices.append(i)
    return magic_indices