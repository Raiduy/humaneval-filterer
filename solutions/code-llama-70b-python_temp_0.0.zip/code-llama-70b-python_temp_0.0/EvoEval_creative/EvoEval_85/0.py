def princess_rescue(coord, grid):
    """
    A princess is trapped in a 2D grid filled with monsters. You are a brave warrior tasked with saving the princess.
    Your starting point is at the top-left corner of the grid and you need to reach the princess who is at a certain coordinate in the grid.
    However, there are monsters in some parts of the grid. You can move either to the right or down.
    You need to find out the minimum number of moves to reach the princess without encountering a monster. 
    If it's impossible to reach the princess without encountering a monster, return -1.
    
    The grid is represented as a 2D list. Each element in the list is either 0 or 1. 
    0 represents an open space where you can move, and 1 represents a monster. 
    The princess's coordinate is represented as a tuple (row, column).
    
    Examples:
    
    For coord = (2,2) and grid = [[0,0,0],[0,1,0],[0,0,0]], the output should be 4.
    For coord = (3,3) and grid = [[0,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,0]], the output should be 6.
    For coord = (3,3) and grid = [[0,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], the output should be -1.
    For coord = (1,1) and grid = [[0,0],[1,0]], the output should be 2.
    For coord = (2,2) and grid = [[0,1,0],[0,1,0],[0,0,0]], the output should be 4.
    """
    p_row = coord[0]
    p_col = coord[1]
    w_row = 0
    w_col = 0
    moves = 0
    if grid[w_row][w_col] == 1:
        path = 'down'
    else:
        path = 'right'
    while w_row < p_row and w_col < p_col:
        if path == 'down':
            if w_row + 1 < len(grid):
                w_row += 1
                moves += 1
                if grid[w_row][w_col] == 1:
                    path = 'right'
            else:
                path = 'right'
        elif path == 'right':
            if w_col + 1 < len(grid[0]):
                w_col += 1
                moves += 1
                if grid[w_row][w_col] == 1:
                    path = 'down'
            else:
                path = 'down'
    if w_row == p_row and w_col == p_col:
        return moves