def magical_cafe(menu, magic_spell):
    """
    Imagine you are creating a program for a magical cafe. This cafe serves dishes that can be transformed into another dish when a magic spell is applied. Your task is to create a function that takes a menu of dishes as a dictionary and a magic spell as a string. The function should return a new menu where each dish has been transformed by the magic spell. 

    The transformation works as follows:
    Each letter in the name of the dish will be replaced by the letter in the spell that corresponds to its position. If the name of the dish is longer than the spell, the spell starts again from the beginning.
    
    For example:
    
    >>> magical_cafe({'pie': 5, 'cake': 7}, 'ab')
    {'aba': 5, 'abab': 7}

    >>> magical_cafe({'soup': 3, 'salad': 4, 'sandwich': 8}, 'xyz')
    {'xyzx': 3, 'xyzxy': 4, 'xyzxyzxy': 8}

    The menu dictionary consists of dish names as keys and their prices as values.
    """
    new_menu = {}
    for (food, price) in menu.items():
        new_food = ''
        for i in range(len(food)):
            new_food += magic_spell[i % len(magic_spell)]
        new_menu[new_food] = price
    return new_menu