def asciiArt(n, s):
    """Task
    Write a function that takes an integer (n) and a string (s) as input. The function will return a 2D ASCII
    art that has n copies of each character in the string (s) in each row and column. The ASCII art should be
    framed by the '*' character in a "U" shape as shown in the following examples.

    Examples:
        asciiArt(1, "abc") => "*abc*"
                              "*abc*"
                              "*****"

        asciiArt(2, "xy") => "*xxyy*"
                             "*xxyy*"
                             "******"

        asciiArt(3, "123") => "*111222333*"
                              "*111222333*"
                              "*111222333*"
                              "***********"

    Note:
    - n will always be a positive integer.
    - The string (s) will only contain alphanumeric characters and will have at least one character.
    - You don't have to worry about handling empty strings or null values.
    """
    result = ''
    result += '*' + s * n + '*\n'
    for i in range(n):
        result += '*' + s * n + '*\n'
    result += '*' * (len(s) * n + 1)
    return result