def potion_mixing(potions, target):
    """
    In this task, you are a wizard who is trying to create a magic potion. You have a list of
    potions, each represented by a string. Each string represents the potion's name, followed by
    the potion's power level (an integer). You are given a target power level that you need to reach
    by mixing potions. Your task is to return a list of potions that you need to mix to reach the
    target power level. If it is not possible to reach the target power level with the given potions,
    return an empty list. You can use each potion only once.
    If there are multiple ways to reach the target power level, return the one with the smallest number
    of potions. If there's still a tie, return the one with smallest alphebetical order sorted by the
    concatenation of the string representations of the potions.
    The potion's power levels will always be positive integers.
    Return the potions in ascending order.

    Example:
    potion_mixing(["Healing Potion 10", "Strength Potion 5", "Invisibility Potion 7"], 15) -> ["Healing Potion 10", "Strength Potion 5"]
    potion_mixing(["Luck Potion 3", "Wisdom Potion 8", "Fire Resistance Potion 12"], 20) -> ['Fire Resistance Potion 12', 'Wisdom Potion 8']
    potion_mixing(["Poison Potion 2", "Water Breathing Potion 6", "Night Vision Potion 5"], 10) -> []
    potion_mixing(["Potion of Swiftness 3", "Potion of Leaping 2", "Potion of Harming 10"], 1) -> []
    """
    potions = [potion.split() for potion in potions]
    potions = [(name, int(power)) for (name, power) in potions]
    potions.sort(key=lambda x: x[1])
    for i in range(len(potions)):
        for j in range(i + 1, len(potions)):
            if potions[i][1] + potions[j][1] == target:
                return [potions[i][0] + ' ' + str(potions[i][1]), potions[j][0] + ' ' + str(potions[j][1])]
    return []