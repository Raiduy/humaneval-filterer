def spider_web_jump(arr):
    """
    In a two-dimensional array representing a spider's web, each cell represents a connection to neighboring cells.
    Each cell has a value, which indicates the energy required for a spider to jump to that cell from an adjacent cell.
    Your task is to find the optimal path for the spider to reach the 'safe cell', using the minimum energy possible.
    Return the minimum energy required.

    The array is guaranteed to have exactly 1 safe cell, which is represented by 0.
    The spider always starts from the top-left cell (0,0).
    
    Here's an example web:
    [[1, 2, 1, 99],
     [1, 3, 2, 0],
     [99, 1, 1, 99],
     [99, 99, 99, 99]]
    The optimal path would be (0,0) -> (0,1) -> (0,2) -> (1,2) -> (1,3), with an energy requirement of 1 + 2 + 1 + 2 = 6.

    Example 1:
        Input: [[2, 3], [1, 0]]
        Output: 3
        Explanation: The spider jumps from (0,0) to (1,0) to (1,1) using 2 + 1 = 3 energy.

    Example 2:
        Input: [[0]]
        Output: 0
        Explanation: The spider starts at the safe cell, so no energy is required.

    Constraints:
        * 1 <= arr.length <= 100
        * 1 <= arr[i].length <= 100
        * 0 <= cell.value <= 100
        * The array is guaranteed to contain exactly 1 safe cell.
    """
    (m, n) = (len(arr), len(arr[0]))
    min_energy = [[float('inf') for _ in range(n)] for _ in range(m)]
    min_energy[0][0] = 0
    for i in range(m):
        for j in range(n):
            if i - 1 >= 0:
                min_energy[i][j] = min(min_energy[i][j], min_energy[i - 1][j] + arr[i][j])
            if j - 1 >= 0:
                min_energy[i][j] = min(min_energy[i][j], min_energy[i][j - 1] + arr[i][j])
    return min_energy[-1][-1]