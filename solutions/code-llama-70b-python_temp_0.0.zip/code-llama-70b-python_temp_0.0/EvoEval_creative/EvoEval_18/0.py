def magical_seven(n: int):
    """
    magical_seven returns the n-th number that is a multiple of 7 and its digits sum up to 7.
    
    >>> magical_seven(1)
    7
    >>> magical_seven(2)
    70
    >>> magical_seven(3)
    133
    >>> magical_seven(4)
    322
    >>> magical_seven(5)
    511
    """
    if n < 1:
        return 0
    if n == 1:
        return 7
    num = 70
    i = 2
    while i < n:
        if i % 2 == 0:
            num = num * 7
        else:
            num = num + 7
        i += 1
    return num