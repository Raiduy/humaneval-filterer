def str_to_morse_code(s):
    """
    You are given a string containing only lowercase letters a-z and spaces.
    Write a function str_to_morse_code() that translates the string into Morse Code.
    Each letter is separated by a space and each word is separated by a slash ( / ).
    Return the Morse Code string.

    Morse Code Dictionary: 
    {'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....', 
    'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 
    'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 
    'y': '-.--', 'z': '--..'}

    Examples:
    str_to_morse_code("hello world") returns ".... . .-.. .-.. --- / .-- --- .-. .-.. -.."
    str_to_morse_code("morse code") returns "-- --- .-. ... . / -.-. --- -.. ."
    str_to_morse_code("") returns ""
    """
    morse_code_dict = {'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--', 'z': '--..'}
    return ' '.join([morse_code_dict[char] for char in s])