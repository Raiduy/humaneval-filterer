def word_spiral(arr):
    """Create a function which takes in a 2D array of characters and returns a 
    string which represents the words in the array read in a clockwise spiral starting
    from the top left corner. If the array is empty, return an empty string. 

    Examples:
    assert word_spiral([['h','i','!'],['b','y','e']]) == 'hi!eyb'
    assert word_spiral([['l','o','v','e'],['i','s','i','n'],['t','h','e','a'],['i','r', '!','!!']]) == 'lovena!!!ritisieh'
    assert word_spiral([]) == ''
    """
    if not arr:
        return ''
    res = ''
    top = 0
    bottom = len(arr) - 1
    left = 0
    right = len(arr[0]) - 1
    while top < bottom and left < right:
        for i in range(left, right + 1):
            res += arr[top][i]
        top += 1
        for i in range(top, bottom + 1):
            res += arr[i][right]
        right -= 1
        for i in range(right, left - 1, -1):
            res += arr[bottom][i]
        bottom -= 1
        for i in range(bottom, top - 1, -1):
            res += arr[i][left]
        left += 1
    if top == bottom:
        for i in range(left, right + 1):
            res += arr[top][i]
    elif left == right:
        for i in range(top, bottom + 1):
            res += arr[i][left]
    return res