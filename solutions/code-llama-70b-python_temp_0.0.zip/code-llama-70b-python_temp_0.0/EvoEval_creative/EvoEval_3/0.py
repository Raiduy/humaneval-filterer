from typing import List

def magical_alphabet(input_string: str) -> List[int]:
    """ 
    Given a string where 'a' represents '1', 'b' represents '2', 'c' represents '3' ... 'z' represents '26'. 
    This function should return a list of all possible combinations based on the interpretation of the input string. 
    For example, if input is '123', it should return ['abc', 'lc', 'aw'] which represents ['1,2,3', '12,3', '1,23'].

    >>> magical_alphabet('123')
    ['abc', 'lc', 'aw']
    
    >>> magical_alphabet('111')
    ['aaa', 'ak', 'ka']
    
    Note: Assume all input strings will only contain digits
    """
    if len(input_string) == 0:
        return ['']
    elif len(input_string) == 1:
        return [chr(int(input_string) + 96)]
    else:
        result = []
        for i in range(1, len(input_string) + 1):
            for left in magical_alphabet(input_string[:i]):
                for right in magical_alphabet(input_string[i:]):
                    result.append(left + right)
        return result