def musical_chairs(n, rounds, music):
    """A playful program that simulates a game of musical chairs. 

    The program should represent the game with a list of n players. Each round, 
    the music plays for a certain number of seconds. When the music stops, the 
    player at the current position gets eliminated. The next round starts from 
    the next position. If the end of the list is reached, start again from the 
    beginning. The function should return all the players left after all rounds 
    are finished.

    The function takes three parameters: 
    - n (int): The number of players.
    - rounds (list): A list of integers representing the number of seconds each round lasts.
    - music (int): The speed of music, i.e., the number of positions advanced per second.

    Assume that at the start of each round, the position is at the start of the list.

    Examples:
    - For musical_chairs(5, [2, 3, 4], 1), the game progresses as follows:
        - Round 1: After 2 seconds, player at position 2 is eliminated. Players left: [1, 2, 4, 5]
        - Round 2: After 3 seconds, player at position 1 is eliminated. Players left: [1, 4, 5]
        - Round 3: After 4 seconds, player at position 2 is eliminated. Players left: [1, 4]
        - The function returns: [1, 4]

    - For musical_chairs(10, [1, 2, 3, 4, 5], 1), the function returns: [1, 3, 7, 8, 10]
    """
    players = [i for i in range(1, n + 1)]
    position = 0
    for round in rounds:
        position = (position + round * music - 1) % len(players)
        del players[position]
    return players