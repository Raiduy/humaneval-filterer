def magical_transformation(s):
    """
    Write a function that takes a string and returns a 'magically' transformed version of it.
    This 'magically' transformed version of the string is created by replacing every 
    vowel (a, e, i, o, u) individually with the next vowel in line (a -> e, e -> i, i -> o, o -> u, 
    u -> a). The capitalization should be preserved in the transformation.

    Additionally, every consonant should be replaced by the next consonant in the alphabet. 
    Here, 'y' is considered a consonant and 'z' wraps around to 'b'. 
    Preserve the capitalization for consonants as well.
    
    Maintain the order of characters and special characters in the sentence. Except "?" should become "!" in odd indices and vice versa but only in even indices

    For example:
    magical_transformation('Hi') returns 'Jo'
    magical_transformation('hello') returns 'jimmu'
    magical_transformation('Hello World!!!') returns 'Jimmu Xusmf!?!'
    magical_transformation('abcdef') returns 'ecdfig'
    """
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    new_string = ''
    for i in range(len(s)):
        if s[i] in vowels:
            new_string += vowels[(vowels.index(s[i]) + 1) % 5]
        elif s[i] in consonants:
            new_string += consonants[(consonants.index(s[i]) + 1) % 20]
        elif s[i] == 'y':
            new_string += 'z'
        elif s[i] == 'z':
            new_string += 'b'
        elif s[i] == '?':
            if i % 2 == 0:
                new_string += '!'
            else:
                new_string += '?'
        elif s[i] == '!':
            if i % 2 == 0:
                new_string += '?'
            else:
                new_string += '!'
        else:
            new_string += s[i]
    return new_string.upper()