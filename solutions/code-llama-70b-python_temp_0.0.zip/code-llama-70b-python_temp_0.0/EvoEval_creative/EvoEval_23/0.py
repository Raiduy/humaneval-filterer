def prime_cipher(s: str):
    """
    Given a string s, write a function that performs the following operations:
    - Replace each letter in the string s with the k-th prime number, where a is the 1st prime number, b is the 2nd prime number, z is the 26th prime number.
    - If the character in the string is not a lowercase letter a-z, leave it unchanged.
    - Return the new string.

    Notes:
    - The 1st prime number is 2, the 2nd is 3, the 3rd is 5, and so on.
    - The function should be case sensitive. Only lowercase letters should be replaced with prime numbers.

    Examples:
    >>> prime_cipher("hello")
    '1911373747'
    >>> prime_cipher("world")
    '834761377'
    >>> prime_cipher("Python!")
    'P9771194743!'
    >>> prime_cipher("12345")
    '12345'
    >>> prime_cipher("abc")
    '235'
    """
    prime_dict = dict(zip([chr(letter) for letter in range(ord('a'), ord('z') + 1)], [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101]))
    return ''.join([prime_dict[char] if char in prime_dict else char for char in s])