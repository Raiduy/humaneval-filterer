def secret_code(message, n_values):
    """
    Your task is to help a secret organization communicate by encoding and decoding messages. The organization has its own secret code, in which each letter is replaced by the letter which is n positions ahead in the alphabet cycle. However, the organization uses a random number generator for n, so n can be different for each letter. Spaces and punctuation are not encoded.

    Your function should take two parameters. The first parameter is a string, which will be the message to encode or decode. The second parameter is a list of integers, which are the values of n for each character in the string.

    If the list of integers is longer than the message, ignore the extra integers. If the message is longer than the list of integers, cycle through the list of integers again from the beginning.

    Example 1:
        Input: message = "Hello", n_values = [1, 2, 3, 4, 5]
        Output: "Igopt"

    Example 2:
        Input: message = "Hello World!", n_values = [1, 2, 3]
        Output: "Igomq Xqumf!"

    Constraints:
        * 1 <= len(message) <= 100
        * message contains only letters, spaces and punctuation
        * 1 <= len(n_values) <= 100
        * Each integer in n_values will be between 1 and 26.
    """
    pass