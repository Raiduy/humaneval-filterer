def zodiac_element(birthdays):
    """
    You are given a list of dates in the format YYYY-MM-DD, which represent birthdays. 
    Each birthday corresponds to a zodiac sign and each zodiac sign is associated with one 
    of the four elements: Fire, Water, Air, and Earth.

    Your task is to return a dictionary with the elements as keys and the number of birthdays 
    corresponding to zodiac signs associated with each element as values. If there are no 
    birthdays under a given element, do not include that element in the returned dictionary.

    Zodiac Sign    Dates              Element
    Aries          March 21 – April 19    Fire
    Taurus         April 20 – May 20     Earth
    Gemini         May 21 – June 20       Air
    Cancer         June 21 – July 22     Water
    Leo            July 23 – August 22    Fire
    Virgo          August 23 – Sept 22   Earth
    Libra          Sept 23 – October 22   Air
    Scorpio        Oct 23 – November 21  Water
    Sagittarius    Nov 22 – Dec 21        Fire
    Capricorn      Dec 22 – Jan 19       Earth
    Aquarius       Jan 20 – Feb 18        Air
    Pisces         Feb 19 – March 20     Water

    Note: Return None if the birthdays list is empty.

    Example:
    >>> zodiac_element(["2000-03-21", "2001-05-21", "2002-08-23", "2003-02-19"]) == {'Fire': 1, 'Air': 1, 'Earth': 1, 'Water': 1}
    >>> zodiac_element(["2000-06-21", "2001-07-23"]) == {'Water': 1, 'Fire': 1}
    >>> zodiac_element([]) == None
    """
    import datetime

    def get_element(date):
        date = datetime.datetime.strptime(date, '%Y-%m-%d')
        if date.month == 3 and date.day >= 21 or (date.month == 4 and date.day <= 19):
            return 'Fire'
        elif date.month == 4 and date.day >= 20 or (date.month == 5 and date.day <= 20):
            return 'Earth'
        elif date.month == 5 and date.day >= 21 or (date.month == 6 and date.day <= 20):
            return 'Air'
        elif date.month == 6 and date.day >= 21 or (date.month == 7 and date.day <= 22):
            return 'Water'
        elif date.month == 7 and date.day >= 23 or (date.month == 8 and date.day <= 22):
            return 'Fire'
        elif date.month == 8 and date.day >= 23 or (date.month == 9 and date.day <= 22):
            return 'Earth'
        elif date.month == 9 and date.day >= 23 or (date.month == 10 and date.day <= 22):
            return 'Air'
        elif date.month == 10 and date.day >= 23 or (date.month == 11 and date.day <= 21):
            return 'Water'
        elif date.month == 11 and date.day >= 22 or (date.month == 12 and date.day <= 21):
            return 'Fire'
        elif date.month == 12 and date.day >= 22 or (date.month == 1 and date.day <= 19):
            return 'Earth'
        elif date.month == 1 and date.day >= 20 or (date.month == 2 and date.day <= 18):
            return 'Air'