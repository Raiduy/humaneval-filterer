def happy_ants(path_length, sugar_locations, ant_positions):
    """
    Imagine a narrow path where ants are marching. Some locations on the path have sugar pieces. A
    happy ant is an ant that passes a location with a sugar piece. When an ant passes a location with sugar,
    it picks up a small bite of the sugar, and subsequent ants can still get sugar from that location.

    Implement a function that takes the path's length (a positive integer), a list of the initial sugar
    locations (positive integers less than the path's length), and a list of ant positions and their marching
    direction (a list of tuples, where the first item of the tuple is the ant's position - a positive integer
    less than the path's length, and the second item is the ant's marching direction as "left" or "right").

    This function should return the number of happy ants at the end of their march.

    Ants can't turn back and starts marching from the given initial position.

    For example:
    happy_ants(10, [2, 5, 7], [(1, "right"), (3, "right"), (6, "left")]) => 3

    happy_ants(20, [2, 10, 14, 15], [(2, "right"), (8, "right"), (19, "left"), (15, "left")]) => 4

    happy_ants(3, [2], [(0, "right"), (1, "right"), (2, "left")]) => 3

    happy_ants(0, [], []) => 0
    """