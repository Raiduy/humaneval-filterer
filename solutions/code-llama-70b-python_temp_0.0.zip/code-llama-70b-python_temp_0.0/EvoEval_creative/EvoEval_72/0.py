def string_fairy_tale(lst):
    """Given a list of strings, where each string consists of a mix of letters and numbers, return a list.
    Each element of the output should be a fairy tale inspired story. The story should be "Once upon a time, 
    in a kingdom far away, lived a magical creature with the name of 'i' who was known for telling 'j' tales a day,
    where 'i' is the i'th string of the input and 'j' is the count of digits in that string.

    >>> string_fairy_tale(['Dragon123', 'Unicorn45'])
    ["Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Dragon123' who was known for telling 3 tales a day", 
     "Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Unicorn45' who was known for telling 2 tales a day"]

    >>> string_fairy_tale(['Mermaid7890', 'Elf111'])
    ["Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Mermaid7890' who was known for telling 4 tales a day", 
     "Once upon a time, in a kingdom far away, lived a magical creature with the name of 'Elf111' who was known for telling 3 tales a day"]
    """
    return [f"Once upon a time, in a kingdom far away, lived a magical creature with the name of '{i}' who was known for telling {len([c for c in i if c.isdigit()])} tales a day" for i in lst]