from typing import List, Tuple


def zigzag_traversal(matrix: List[List[int]]) -> List[int]:
    """Given a 2D list of integers, return a list that represents its elements traversed in a zigzag order starting from the top-left corner and moving rightwards.
    When the right end is reached, the direction should be downwards to the next row, then to the left end, and so on until all elements are covered. 
    >>> zigzag_traversal([[1, 2], [3, 4], [5, 6, 7], [8, 9, 10]])
    [1, 2, 4, 3, 5, 6, 7, 10, 9, 8]
    """
    visited = [[False for _ in range(len(matrix[0]))] for _ in range(len(matrix))]
    result = []
    (current_row, current_column) = (0, 0)
    direction = 'right'
    while len(result) < len(matrix) * len(matrix[0]):
        result.append(matrix[current_row][current_column])
        visited[current_row][current_column] = True
        if direction == 'right':
            if current_column == len(matrix[0]) - 1:
                current_row += 1
                direction = 'left'
            elif current_column > 0:
                current_column -= 1
                current_row += 1
                direction = 'left'
            else:
                current_row += 1
        elif current_column == 0:
            current_row -= 1
            direction = 'right'
        elif current_column < len(matrix[0]) - 1:
            current_column += 1
            current_row -= 1
            direction = 'right'