def find_castle(arr):
    """
    A prince wants to build his castle on the highest hill in his kingdom. The kingdom is a linear array of hills of different heights, represented as integers in the array arr. The prince wants his castle to have a view of as many hills as possible. However, the view from the castle is blocked by any hill that is taller than it. 

    The prince can build his castle on any hill, but he can only see the hills to the left and right that are shorter than the hill he is on. Once a taller hill is encountered, the view in that direction is blocked. The prince can see a hill if it is the same height.

    Write a function that determines the maximum number of hills the prince can see from any hill.

    Example:
    find_castle([1,2,3,2,5,3,6,4,8,2,7]) returns 10 (The prince can see 10 hills if he builds his castle on the hill of height 8)
    find_castle([1, 2, 3, 4, 5, 6, 7, 8, 9]) returns 8 
    find_castle([9, 8, 7, 6, 5, 4, 3, 2, 1]) returns 8
    find_castle([5, 5, 5, 5, 5]) returns 4
    """
    max_view = 0
    for i in range(len(arr)):
        current_view = 0
        for j in range(i - 1, -1, -1):
            if arr[i] >= arr[j]:
                current_view += 1
            else:
                break
        for k in range(i + 1, len(arr)):
            if arr[i] >= arr[k]:
                current_view += 1
            else:
                break
        if current_view > max_view:
            max_view = current_view
    return max_view