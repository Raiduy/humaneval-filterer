def alien_language_translator(english_word: str):
    """
    Assume there is an alien language where each English alphabet is replaced by a unique symbol. 
    In this language, the symbol for 'a' is '+', 'b' is '-', 'c' is '*', 'd' is '/', 'e' is '%', 'f' is '@', 'g' is '!',
    'h' is '#', 'i' is '$', 'j' is '^', 'k' is '&', 'l' is '(', 'm' is ')', 'n' is '=', 'o' is '?', 'p' is ':',
    'q' is ';', 'r' is '`', 's' is '~', 't' is '>', 'u' is '<', 'v' is '{', 'w' is '}', 'x' is '[', 'y' is ']', 'z' is '|'.
    Write a function that translates an English word into this alien language.

    >>> alien_language_translator("hello")
    '#%((?'

    >>> alien_language_translator("alien")
    '+($%='
    """
    alien_word = ''
    for letter in english_word:
        if letter == 'a':
            alien_word += '+'
        elif letter == 'b':
            alien_word += '-'
        elif letter == 'c':
            alien_word += '*'
        elif letter == 'd':
            alien_word += '/'
        elif letter == 'e':
            alien_word += '%'
        elif letter == 'f':
            alien_word += '@'
        elif letter == 'g':
            alien_word += '!'
        elif letter == 'h':
            alien_word += '#'
        elif letter == 'i':
            alien_word += '$'
        elif letter == 'j':
            alien_word += '^'
        elif letter == 'k':
            alien_word += '&'
        elif letter == 'l':
            alien_word += '('
        elif letter == 'm':
            alien_word += ')'
        elif letter == 'n':
            alien_word += '='
        elif letter == 'o':
            alien_word += '?'
        elif letter == 'p':
            alien_word += ':'
        elif letter == 'q':
            alien_word += ';'
        elif letter == 'r':
            alien_word += '`'
        elif letter == 's':
            alien_word += '~'
        elif letter == 't':
            alien_word += '>'
        elif letter == 'u':
            alien_word += '<'
        elif letter == 'v':
            alien_word += '{'
        elif letter == 'w':
            alien_word += '}'
        elif letter == 'x':
            alien_word += '['
        elif letter == 'y':
            alien_word += ']'
        elif letter == 'z':
            alien_word += '|'
    return alien_word