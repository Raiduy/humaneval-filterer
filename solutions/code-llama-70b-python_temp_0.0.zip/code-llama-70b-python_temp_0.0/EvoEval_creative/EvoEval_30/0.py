from typing import List, Tuple

def find_path(maze: List[List[int]], start: Tuple[int], end: Tuple[int]):
    """Returns the shortest path from start to end in a maze represented by a 2D array.

    The maze is a 2D array where 0s represent walls and 1s represent open paths. The start and end points 
    are tuples representing coordinates in the 2D array. The function should return a list of points 
    representing the shortest path from start to end. If no path is possible, return an empty list.

    >>> maze = [[1,0,1,1,1], [1,0,1,0,1], [1,1,1,0,1], [1,0,0,0,1], [1,1,1,1,1]]
    >>> start = (0,0)
    >>> end = (4, 4)
    >>> find_path(maze, start, end)
    [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (4, 1), (4, 2), (4, 3), (4, 4)]

    >>> maze = [[1,0,1], [0,0,1], [1,1,1]]
    >>> start = (0,0)
    >>> end = (2, 2)
    >>> find_path(maze, start, end)
    []
    """
    path = []
    visited = []
    queue = []
    queue.append(start)
    while queue:
        point = queue.pop(0)
        if point == end:
            return path
        if point not in visited:
            visited.append(point)
            path.append(point)
            neighbors = get_neighbors(point, maze)
            for neighbor in neighbors:
                queue.append(neighbor)
    return []