from typing import List, Union

def calculate_shipping_cost(items: List[Union[str, float]], location: str) -> float:
    """
    Given a list of items (represented by their weights in kg) and a location,
    calculate the cost of shipping. Each item has a base shipping cost of $5.0.
    The location multiplies the total cost by a certain factor:
    - "Local": no additional factor
    - "National": factor of 1.5
    - "International": factor of 2.5
    - other location: no additional factor
    If the item's weight is more than 5kg, an additional charge of $10.0 is added.
    
    If an item is passed as a string instead of a float, consider its weight as 1kg and all previous factors are multiplied by 1.5. This multiplication only occurs once even if there are multiple string items.
    
    Return the total shipping cost rounded to two decimal places as a string.
    
    >>> calculate_shipping_cost([3.0, 'Book', 7.0], 'National')
    "56.25"
    >>> calculate_shipping_cost([1.0, 2.0, 3.0, 4.0], 'Local')
    "20.00"
    >>> calculate_shipping_cost([5.5, 2.0, 3.0], 'International')
    "62.50"
    """
    cost = 0
    for item in items:
        if item == str:
            cost += 10
            cost += 15
        else:
            cost += item
    if cost > 5:
        cost += 10
    if location == 'National':
        cost *= 1.5
    elif location == 'International':
        cost *= 2.5
    return f'{cost:.2f}'