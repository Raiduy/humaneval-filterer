def reverse_vowels(s):
    """Given a string s, return a new string with the vowels in reverse order, while keeping the position of other characters unchanged.
    The string can contain uppercase and lowercase letters.
    For example:
    reverse_vowels('Hello') == 'Holle'
    reverse_vowels('Python') == 'Python'
    reverse_vowels('algorithm') == 'ilgorathm'
    """
    vowels = 'aeiouAEIOU'
    new_string = ''
    vowel_list = []
    for i in s:
        if i in vowels:
            vowel_list.append(i)
    for i in s:
        if i in vowels:
            new_string += vowel_list.pop()
        else:
            new_string += i
    return new_string