def adventure_game(map, instructions):
    """
    You are building a text-based adventure game. The game map is a 2D list, where 'S' represents the start, 'E' represents the end, 
    '.' represents a path, and 'X' represents a wall. A player can move in four directions: up, down, left, right. 

    Given a game map and a list of instructions, return the path the player takes. If the player moves into a wall or the edge of 
    the map, they should stay in their current position. If the player finds the end 'E', the game is won and no further instructions 
    are processed. If the list of instructions ends before the player finds 'E', return the player's path so far.

    The player's path should be returned as a list of tuples, where each tuple represents the player's position (row, column) after
    each move.

    If the player never moves from the start 'S', return [(start_row, start_column)].

    Examples:
    adventure_game([
        ['S', '.', '.'],
        ['X', 'X', '.'],
        ['.', 'X', 'E']
    ], ['right', 'right', 'down', 'down', 'right']) ➞ [(0, 0), (0, 1), (0, 2), (1, 2), (2, 2)]

    adventure_game([
        ['.', '.', 'S'],
        ['.', 'X', 'X'],
        ['E', 'X', '.']
    ], ['left', 'left', 'up']) ➞ [(0, 2), (0, 1), (0, 0), (0, 0)]

    adventure_game([
        ['S', 'X', 'E']
    ], ['right', 'right']) ➞ [(0, 0)]
    """
    start_row = 0
    start_column = 0
    end_row = 0
    end_column = 0
    player_row = 0
    player_column = 0
    player_path = []
    for i in range(len(map)):
        for j in range(len(map[i])):
            if map[i][j] == 'S':
                start_row = i
                start_column = j
            elif map[i][j] == 'E':
                end_row = i
                end_column = j
    player_row = start_row
    player_column = start_column
    for i in range(len(instructions)):
        if instructions[i] == 'up':
            if player_row - 1 >= 0 and map[player_row - 1][player_column] != 'X':
                player_row -= 1
        elif instructions[i] == 'down':
            if player_row + 1 < len(map) and map[player_row + 1][player_column] != 'X':
                player_row += 1
        elif instructions[i] == 'left':
            if player_column - 1 >= 0 and map[player_row][player_column - 1] != 'X':
                player_column -= 1
        elif instructions[i] == 'right':
            if player_column + 1 < len(map[0]) and map[player_row][player_column + 1] != 'X':
                player_column += 1
        player_path.append((player_row, player_column))
        if player_row == end_row and player_column == end_column:
            break
    return player_path