def treasure_map(message, shift):
    """
    Create a function called 'treasure_map' that takes two parameters: a 'message' string and an integer 'shift'.
    The function should encrypt the message using a Caesar cipher, a type of substitution cipher in which 
    each character in the message is 'shifted' a certain number of places down the alphabet. 
    
    However, there's a twist: instead of a regular Caesar cipher, you should implement a 'jumping' Caesar cipher. 
    That is, for the first character of the message, you should shift it by one place. For the second character 
    of the message, you should shift it by two places, and so on, increasing the shift by one for each subsequent 
    character. The 'shift' parameter determines the initial shift for the first character.

    Note that the shifting should be cyclical - if it reaches the end of the alphabet, it should wrap around to the 
    beginning. The function needs to handle both lower and upper case letters, but should ignore non-alphabet 
    characters (they should not be modified).

    Examples:
    treasure_map('Hallo', 1) returns 'Icopt'
    treasure_map('XyZ', 2) returns 'ZbD'
    treasure_map('Treasure', 3) returns 'Wvjgzcao'
    treasure_map('Map', 4) returns 'Qfv'
    """
    lower_alphabet = [chr(i) for i in range(97, 123)]
    upper_alphabet = [chr(i) for i in range(65, 91)]
    encrypted_message = []
    for (index, char) in enumerate(message):
        if char.isalpha():
            if char.islower():
                char_index = lower_alphabet.index(char)
                shifted_char = (char_index + shift + index) % 26
                encrypted_message.append(lower_alphabet[shifted_char])
            else:
                char_index = upper_alphabet.index(char)
                shifted_char = (char_index + shift + index) % 26
                encrypted_message.append(upper_alphabet[shifted_char])
        else:
            encrypted_message.append(char)
    encrypted_message = ''.join(encrypted_message)
    return encrypted_message