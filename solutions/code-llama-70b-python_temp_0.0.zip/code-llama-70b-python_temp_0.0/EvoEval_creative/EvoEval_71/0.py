def letter_shift_cipher(s, n):
    """Task
    You are given a string 's' and a number 'n'. Your task is to create a function that applies a simple shift cipher to the string. 
    The shift cipher works by shifting the letters in the alphabet by 'n' places. If the shift takes you past the end of the alphabet, just rotate back to the start of the alphabet. 
    Only shift letters in the string, leave any non-alphabet character as is.
    The function should also count the number of vowels (a, e, i, o, u) in the resulting string.
    Return a tuple containing the encrypted string and the number of vowels in it.

    Examples:
    For s = "hello", n = 1, the result should be ('ifmmp', 1) 
    For s = "abcde", n = 3, the result should be ('defgh', 1) 
    For s = "I love Python!", n = 13, the result should be ('V ybir Clguba!', 3)
    """
    vowels = ['a', 'e', 'i', 'o', 'u']
    alpha = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    alpha_dict = {alpha[i]: i for i in range(len(alpha))}
    s = s.lower()
    s_list = list(s)
    for i in range(len(s_list)):
        if s_list[i] in alpha_dict:
            s_list[i] = alpha[(alpha_dict[s_list[i]] + n) % 26]
    s_new = ''.join(s_list)
    count = 0
    for i in range(len(s_new)):
        if s_new[i] in vowels:
            count += 1
    return (s_new, count)