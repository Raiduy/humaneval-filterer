def prime_anagram_pairs(n):
    """
    Given a positive integer n, return a list of tuples that represents all unique pairs of 
    prime numbers within the range (1, n) that are anagrams of each other. 

    A prime number is a natural number greater than 1 that has no positive divisors other than 1 and itself.
    Two numbers are considered anagrams of each other if their digits can be rearranged to form the other number.

    Example 1:

        Input: 13
        Output: []

    Example 2:

        Input: 32
        Output: [(13, 31)]

    Note:
        1. The returned list should contain tuples of prime numbers where the first number is smaller 
        than the second number. 
        2. The list should be sorted in ascending order based on the first number in each tuple. If there's
        a tie, sort based on the second number.
    """
    pass