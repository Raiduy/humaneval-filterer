def wizard_inventory(inventory_logs):
    """
    You are a wizard with a variety of magical items. Your items are stored in a cart that has limited capacity. 
    Sometimes you acquire new items or use up the items you have. Unfortunately, it is not easy to keep track 
    of your inventory manually.

    Write a function that simulates the inventory of the cart. Your function should take a list of inventory_logs. 
    Each log is a dictionary that has two keys: 'item' and 'quantity'. 'item' refers to the name of the item (a string), 
    and 'quantity' is the number of items gained or used. If 'quantity' is negative, it means you've used that many items. 

    Your function should return a dictionary representing the final status of the inventory. If an item's quantity 
    is zero or less, do not include it in the final inventory.

    Examples:
    wizard_inventory([{ "item" : "Dragon Scale", "quantity" : 2}, 
                     { "item" : "Phoenix Feather", "quantity" : 1}, 
                     { "item" : "Dragon Scale", "quantity" : -1}])
    ==> {"Dragon Scale": 1, "Phoenix Feather": 1 }

    wizard_inventory([{ "item" : "Mermaid Hair", "quantity" : 5}, 
                     { "item" : "Mermaid Hair", "quantity" : -5}])
    ==> {}

    wizard_inventory([])
    ==> {}
    """
    inventory = {}
    for log in inventory_logs:
        (item, quantity) = (log['item'], log['quantity'])
        inventory[item] = inventory.get(item, 0) + quantity
        if inventory[item] <= 0:
            del inventory[item]
    return inventory