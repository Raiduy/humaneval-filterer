

def skjkasdkd(Here is the Python function that solves the problem:
