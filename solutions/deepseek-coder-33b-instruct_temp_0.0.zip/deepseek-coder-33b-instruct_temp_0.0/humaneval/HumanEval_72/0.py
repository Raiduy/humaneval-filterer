
def will_it_fly(q, w):
    # Check if the list is a palindrome
    if q != q[::-1]:
        return False
    # Check if the sum of the elements is less than or equal to w
    if sum(q) > w:
        return False
    return True
