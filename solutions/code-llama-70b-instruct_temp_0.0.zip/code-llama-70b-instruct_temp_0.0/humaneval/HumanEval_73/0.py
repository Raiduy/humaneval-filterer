
def smallest_change(arr):
    n = len(arr)
    mid = n // 2
    changes = 0

    # Check if the array is of odd length
    if n % 2 == 1:
        # If so, exclude the middle element
        mid = n // 2 + 1

    # Iterate through the first half of the array
    for i in range(mid):
        # If the elements at the current index and the mirror index are not equal
        if arr[i] != arr[n - i - 1]:
            # Increment the number of changes
            changes += 1

    # Return the minimum number of changes required
    return changes
