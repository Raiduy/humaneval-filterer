
def minPath(grid, k):
    n = len(grid)
    # Create a set to store the visited cells
    visited = set()
    # Create a list to store the path
    path = []
    # Initialize the minimum path
    min_path = None
    # Find the minimum path
    find_min_path(grid, k, 0, 0, visited, path, min_path)
    return min_path

