
def is_bored(S):
    sentences = S.split('.')
    boredoms = 0
    for sentence in sentences:
        if sentence.strip().lower().startswith('i'):
            boredoms += 1
    return boredoms
