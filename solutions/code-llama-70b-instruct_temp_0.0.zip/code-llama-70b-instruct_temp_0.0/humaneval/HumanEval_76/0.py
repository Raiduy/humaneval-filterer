
def is_simple_power(x, n):
    if n == 1:
        return x == 1
    i = 1
    while n ** i < x:
        i += 1
    return n ** i == x

