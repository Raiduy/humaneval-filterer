

def skjkasdkd(lst):
    largest_prime = max(filter(is_prime, lst))
    return sum_of_digits(largest_prime)
