
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    # Split the string into a list of words
    words = test.split()

    # Create a dictionary to store the count of each word
    word_count = {}

    # Iterate through each word in the list
    for word in words:
        # If the word is not in the dictionary, add it with a count of 1
        if word not in word_count:
            word_count[word] = 1
        # If the word is already in the dictionary, increment its count
        else:
            word_count[word] += 1

    # Find the maximum count in the dictionary
    max_count = max(word_count.values())

    # Create a dictionary to store the result
    result = {}

    # Iterate through each word and its count in the dictionary
    for word, count in word_count.items():
        # If the count is equal to the maximum count, add it to the result dictionary
        if count == max_count:
            result[word] = count

    return result
