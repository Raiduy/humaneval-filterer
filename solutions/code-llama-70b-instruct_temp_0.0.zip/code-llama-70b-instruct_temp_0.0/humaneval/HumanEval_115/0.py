import math

def max_fill(grid, capacity):
    # Initialize the number of times the buckets are lowered
    times_lowered = 0

    # Iterate over each row in the grid
    for row in grid:
        # Initialize the number of units of water in the current row
        units_of_water = 0

        # Iterate over each column in the row
        for col in row:
            # If the current cell contains water, increment the number of units of water
            if col == 1:
                units_of_water += 1

        # Calculate the number of times the buckets need to be lowered for this row
        times_lowered += math.ceil(units_of_water / capacity)

    return times_lowered
