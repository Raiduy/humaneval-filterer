from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """

    # Initialize an empty list to store the note durations
    note_durations = []

    # Iterate over the input string
    for note in music_string.split():
        # Check if the note is a whole note
        if note == 'o':
            note_durations.append(4)
        # Check if the note is a half note
        elif note == 'o|':
            note_durations.append(2)
        # Check if the note is a quarter note
        elif note == '.|':
            note_durations.append(1)

    return note_durations

