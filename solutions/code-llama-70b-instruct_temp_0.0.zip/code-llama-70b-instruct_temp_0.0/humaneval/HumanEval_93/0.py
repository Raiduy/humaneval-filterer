
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    # Create a dictionary to map vowels to their replacements
    vowel_map = {
        'a': 'c',
        'e': 'g',
        'i': 'k',
        'o': 'n',
        'u': 'r'
    }

    # Initialize an empty string to store the encoded message
    encoded_message = ""

    # Iterate over each character in the message
    for char in message:
        # Check if the character is a lowercase vowel
        if char.lower() in vowel_map:
            # Replace the vowel with its mapped replacement
            encoded_message += vowel_map[char.lower()].upper()
        else:
            # Append the character as-is to the encoded message
            encoded_message += char

    # Return the encoded message
    return encoded_message
