
def strange_sort_list(lst):
    if len(lst) == 0:
        return []
    elif len(lst) == 1:
        return lst
    else:
        sorted_lst = sorted(lst)
        min_val = sorted_lst[0]
        max_val = sorted_lst[-1]
        remaining_lst = sorted_lst[1:-1]
        return [min_val] + strange_sort_list(remaining_lst) + [max_val]

