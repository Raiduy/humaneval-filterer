
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices.

    Args:
        lst (list): A list of integers.

    Returns:
        int: The sum of even elements at odd indices.
    """
    if not lst:
        raise ValueError("The list must not be empty.")

    sum = 0
    for i in range(1, len(lst), 2):
        if lst[i] % 2 == 0:
            sum += lst[i]
    return sum


