
def solve(N):
    # Convert the number to a string
    N_str = str(N)

    # Calculate the sum of digits
    sum_of_digits = sum(int(digit) for digit in N_str)

    # Convert the sum of digits to a binary string
    binary_str = bin(sum_of_digits)[2:]

    return binary_str
