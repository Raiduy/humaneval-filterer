from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    # Create a dictionary to map numberals to their corresponding values
    number_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }

    # Split the input string into a list of words
    number_words = numbers.split()

    # Convert each word to its corresponding number and sort the list
    sorted_numbers = sorted([number_map[word] for word in number_words])

    # Convert the sorted numbers back to words and join them into a string
    sorted_number_words = [list(number_map.keys())[list(number_map.values()).index(number)] for number in sorted_numbers]
    sorted_string = ' '.join(sorted_number_words)

    return sorted_string

