
def cycpattern_check(a, b):
    if len(b) > len(a):
        return False

    b_rotations = []
    for i in range(len(b)):
        b_rotations.append(b[i:] + b[:i])

    for rotation in b_rotations:
        if rotation in a:
            return True

    return False

