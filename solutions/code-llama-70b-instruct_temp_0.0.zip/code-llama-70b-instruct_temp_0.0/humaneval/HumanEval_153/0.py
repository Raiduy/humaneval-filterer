
def Strongest_Extension(class_name, extensions):
    # Initialize the strongest extension and its strength
    strongest_extension = extensions[0]
    strongest_extension_strength = count_uppercase(strongest_extension) - count_lowercase(strongest_extension)

    # Iterate through the extensions
    for extension in extensions:
        # Calculate the strength of the current extension
        extension_strength = count_uppercase(extension) - count_lowercase(extension)

        # If the current extension is stronger than the strongest extension, update the strongest extension and its strength
        if extension_strength > strongest_extension_strength:
            strongest_extension = extension
            strongest_extension_strength = extension_strength

    # Return the class name and the strongest extension separated by a dot
    return class_name + "." + strongest_extension
