
def pluck(arr):
    if not arr:
        return []

    smallest_value = float('inf')
    smallest_index = float('inf')

    for i, value in enumerate(arr):
        if value % 2 == 0 and value < smallest_value:
            smallest_value = value
            smallest_index = i

    return [smallest_value, smallest_index]
