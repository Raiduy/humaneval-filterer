
def even_odd_count(num):
    # Convert the number to a string
    num_str = str(num)

    # Initialize even and odd digit counts
    even_count = 0
    odd_count = 0

    # Iterate through each digit in the number
    for digit in num_str:
        # Check if the digit is even
        if int(digit) % 2 == 0:
            even_count += 1
        else:
            odd_count += 1

    # Return a tuple with the even and odd digit counts
    return (even_count, odd_count)
