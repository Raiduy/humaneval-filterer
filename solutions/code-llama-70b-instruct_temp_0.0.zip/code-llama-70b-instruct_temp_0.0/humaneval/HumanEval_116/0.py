
def sort_array(arr):
    # Sort the array in ascending order of number of ones in their binary representation
    sorted_arr = sorted(arr, key=lambda x: (bin(x).count("1"), x))
    return sorted_arr
