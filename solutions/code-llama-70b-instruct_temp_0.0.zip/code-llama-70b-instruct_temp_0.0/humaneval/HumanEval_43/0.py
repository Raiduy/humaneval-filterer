

def pairs_sum_to_zero(l):
    # Create a set to store the elements that have already been seen
    seen = set()

    # Iterate through the list
    for num in l:
        # Check if the complement of the current element is in the set
        if -num in seen:
            return True
        # Add the current element to the set
        seen.add(num)

    # If no pair is found, return False
    return False
