
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    # Create a dictionary to map the original alphabet to the rotated alphabet
    alphabet_mapping = {
        'a': 'c', 'b': 'd', 'c': 'f', 'd': 'g', 'e': 'i', 'f': 'j', 'g': 'l', 'h': 'm', 'i': 'o', 'j': 'p', 'k': 'r', 'l': 's', 'm': 'u', 'n': 'v', 'o': 'x', 'p': 'y', 'q': 'a', 'r': 'b', 's': 'd', 't': 'e', 'u': 'g', 'v': 'h', 'w': 'k', 'x': 'm', 'y': 'n', 'z': 'q', ' ': ' '
    }

    # Create an empty string to store the encrypted string
    encrypted_string = ""

    # Iterate through each character in the input string
    for char in s:
        # Check if the character is in the alphabet mapping
        if char in alphabet_mapping:
            # Append the encrypted character to the encrypted string
            encrypted_string += alphabet_mapping[char]
        else:
            # Append the original character to the encrypted string
            encrypted_string += char

    # Return the encrypted string
    return encrypted_string
