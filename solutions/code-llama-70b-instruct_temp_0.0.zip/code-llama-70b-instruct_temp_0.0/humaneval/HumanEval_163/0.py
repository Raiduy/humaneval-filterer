
def generate_integers(a, b):
    # Ensure that a is less than or equal to b
    if a > b:
        a, b = b, a

    # Initialize an empty list to store the even digits
    even_digits = []

    # Iterate over the range from a to b (inclusive)
    for i in range(a, b + 1):
        # Convert the number to a string
        num_str = str(i)

        # Check if the number is even
        if int(num_str[-1]) % 2 == 0:
            even_digits.append(i)

    return even_digits
