
def unique_digits(x):
    # Initialize an empty list to store the elements with unique digits
    unique_digit_elements = []

    # Iterate through each element in the list
    for element in x:
        # Convert the element to a string
        element_str = str(element)

        # Initialize a flag to check if the element has any even digits
        has_even_digit = False

        # Iterate through each digit in the element
        for digit in element_str:
            # Check if the digit is even
            if int(digit) % 2 == 0:
                has_even_digit = True
                break

        # If the element doesn't have any even digits, add it to the list
        if not has_even_digit:
            unique_digit_elements.append(element)

    # Sort the list in increasing order
    unique_digit_elements.sort()

    # Return the list of elements with unique digits
    return unique_digit_elements
