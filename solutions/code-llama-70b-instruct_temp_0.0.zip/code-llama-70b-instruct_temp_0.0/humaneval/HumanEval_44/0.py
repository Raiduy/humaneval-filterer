

def change_base(x, base):
    if base < 2:
        raise ValueError("Invalid base: {}".format(base))
    if x == 0:
        return "0"
    digits = []
    while x:
        digits.append(str(x % base))
        x //= base
    return "".join(reversed(digits))


