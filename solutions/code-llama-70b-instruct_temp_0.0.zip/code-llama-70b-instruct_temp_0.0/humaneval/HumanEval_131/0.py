
def digits(n):
    if n < 0:
        raise ValueError("Input must be a positive integer")

    product = 1
    for digit in str(n):
        if int(digit) % 2 == 1:
            product *= int(digit)

    return product

