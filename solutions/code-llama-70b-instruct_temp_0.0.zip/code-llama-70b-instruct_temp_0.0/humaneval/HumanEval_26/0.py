from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    # Create a dictionary to keep track of the number of occurrences of each number
    occurrences = {}

    # Iterate through the list of numbers
    for number in numbers:
        # If the number is not in the dictionary, add it with a value of 1
        if number not in occurrences:
            occurrences[number] = 1
        # If the number is already in the dictionary, increment its value by 1
        else:
            occurrences[number] += 1

    # Create a new list to store the unique numbers
    unique_numbers = []

    # Iterate through the list of numbers again
    for number in numbers:
        # If the number occurs only once, add it to the unique_numbers list
        if occurrences[number] == 1:
            unique_numbers.append(number)

    # Return the list of unique numbers
    return unique_numbers
