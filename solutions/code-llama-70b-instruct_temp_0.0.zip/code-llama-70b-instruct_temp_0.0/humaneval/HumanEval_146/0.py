
def specialFilter(nums):
    count = 0
    for num in nums:
        if num > 10 and num % 2 != 0 and num % 10 != 0:
            count += 1
    return count
