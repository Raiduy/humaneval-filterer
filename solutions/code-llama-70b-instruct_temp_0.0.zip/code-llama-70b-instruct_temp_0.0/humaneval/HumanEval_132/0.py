
def is_nested(string):
    # Initialize a stack to keep track of opening brackets
    stack = []

    # Iterate through each character in the string
    for char in string:
        # If the character is an opening bracket, push it onto the stack
        if char == '[':
            stack.append(char)
        # If the character is a closing bracket, check if the stack is empty
        elif char == ']':
            if len(stack) == 0:
                # If the stack is empty, return False
                return False
            else:
                # If the stack is not empty, pop the top element from the stack
                stack.pop()

    # If the stack is empty, return True
    return len(stack) == 0

