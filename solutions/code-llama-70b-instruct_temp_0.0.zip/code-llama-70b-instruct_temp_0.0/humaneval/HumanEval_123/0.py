
def get_odd_collatz(n):
    # Initialize a list to store the odd numbers in the Collatz sequence
    odd_numbers = []

    # Start with the input number n
    current_number = n

    # Iterate until the current number is 1
    while current_number != 1:
        # Check if the current number is odd
        if current_number % 2 == 1:
            # Append the current number to the list of odd numbers
            odd_numbers.append(current_number)

        # If the current number is even
        if current_number % 2 == 0:
            # Divide the current number by 2
            current_number = current_number // 2
        # If the current number is odd
        else:
            # Multiply the current number by 3 and add 1
            current_number = current_number * 3 + 1

    # Append 1 to the list of odd numbers
    odd_numbers.append(1)

    # Sort the list of odd numbers in increasing order
    odd_numbers.sort()

    # Return the list of odd numbers
    return odd_numbers
