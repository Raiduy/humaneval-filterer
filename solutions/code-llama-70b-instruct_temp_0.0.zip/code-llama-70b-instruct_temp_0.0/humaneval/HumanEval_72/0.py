
def will_it_fly(q, w):
    # Check if the list is palindromic
    is_palindromic = q == q[::-1]

    # Check if the sum of the list elements is less than or equal to the maximum possible weight
    sum_elements = sum(q)
    is_sum_less_than_max = sum_elements <= w

    # Return True if both conditions are met, otherwise return False
    return is_palindromic and is_sum_less_than_max
