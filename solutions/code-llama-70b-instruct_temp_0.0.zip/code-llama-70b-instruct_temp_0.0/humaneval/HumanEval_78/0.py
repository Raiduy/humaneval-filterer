
def hex_key(num):
    # Define a set of prime hexadecimal digits
    prime_hex_digits = set(['2', '3', '5', '7', 'B', 'D'])

    # Initialize the count of prime hexadecimal digits
    count = 0

    # Iterate over each character in the hexadecimal number
    for char in num:
        # Check if the character is a prime hexadecimal digit
        if char in prime_hex_digits:
            # Increment the count
            count += 1

    # Return the count of prime hexadecimal digits
    return count
