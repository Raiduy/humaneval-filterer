
def compare(game, guess):
    if len(game) != len(guess):
        raise ValueError("The two lists must have the same length.")
    result = []
    for i in range(len(game)):
        result.append(abs(game[i] - guess[i]))
    return result

