
def check_if_last_char_is_a_letter(txt):
    # Check if the input string is empty
    if not txt:
        return False

    # Check if the last character is a letter
    if txt[-1].isalpha():
        # Check if the last character is a part of a word
        if len(txt) > 1 and txt[-2] != " ":
            return False
        else:
            return True
    else:
        return False

