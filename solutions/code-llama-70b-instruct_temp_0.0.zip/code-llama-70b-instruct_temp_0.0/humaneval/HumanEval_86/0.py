
def anti_shuffle(s):
    words = s.split()
    ordered_words = []
    for word in words:
        if word.isalpha():
            ordered_word = ''.join(sorted(word))
            ordered_words.append(ordered_word)
        else:
            ordered_words.append(word)
    return ' '.join(ordered_words)

