
def exchange(lst1, lst2):
    # Check if all elements of lst1 are even
    if all(num % 2 == 0 for num in lst1):
        return "YES"

    # Check if all elements of lst2 are even
    if all(num % 2 == 0 for num in lst2):
        return "YES"

    # Calculate the number of odd elements in lst1
    odd_count1 = sum(1 for num in lst1 if num % 2 != 0)

    # Calculate the number of odd elements in lst2
    odd_count2 = sum(1 for num in lst2 if num % 2 != 0)

    # Check if the number of odd elements in lst1 is equal to the number of odd elements in lst2
    if odd_count1 == odd_count2:
        return "YES"

    # Check if the number of odd elements in lst1 is less than the number of odd elements in lst2
    if odd_count1 < odd_count2:
        # Calculate the difference in the number of odd elements
        diff = odd_count2 - odd_count1

        # Check if the difference is divisible by 2
        if diff % 2 == 0:
            return "YES"

    return "NO"
