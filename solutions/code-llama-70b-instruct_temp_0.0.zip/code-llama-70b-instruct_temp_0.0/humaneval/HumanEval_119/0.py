
def match_parens(lst):
    # Check if the list has exactly two strings
    if len(lst) != 2:
        raise ValueError("The list must have exactly two strings")

    # Check if the strings only contain open and close parentheses
    for s in lst:
        if any(c not in "()" for c in s):
            raise ValueError("The strings must only contain open and close parentheses")

    # Count the number of open and close parentheses in each string
    open_count1 = lst[0].count("(")
    close_count1 = lst[0].count(")")
    open_count2 = lst[1].count("(")
    close_count2 = lst[1].count(")")

    # Check if concatenating the first string with the second string results in a good string
    if open_count1 + open_count2 == close_count1 + close_count2:
        return "Yes"

    # Check if concatenating the second string with the first string results in a good string
    if open_count1 + close_count2 == close_count1 + open_count2:
        return "Yes"

    # If none of the above checks pass, return 'No'
    return "No"
