

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    # Check if n is a positive integer
    if n <= 0 or not isinstance(n, int):
        raise ValueError("n must be a positive integer")

    # Initialize the largest divisor
    largest_divisor = 1

    # Iterate through all numbers from 2 to n-1
    for i in range(2, n):
        # Check if i divides n evenly
        if n % i == 0:
            # Update the largest divisor if i is larger
            largest_divisor = max(largest_divisor, i)

    return largest_divisor


