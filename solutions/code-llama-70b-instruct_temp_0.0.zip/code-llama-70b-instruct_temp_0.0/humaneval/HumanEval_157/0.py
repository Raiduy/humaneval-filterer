
def right_angle_triangle(a, b, c):
    # Sort the sides in descending order
    a, b, c = sorted([a, b, c], reverse=True)

    # Check if the largest side is hypotenuse of a right-angled triangle
    if a**2 == b**2 + c**2:
        return True
    else:
        return False
