
def double_the_difference(lst):
    # Initialize the sum of squares
    sum_of_squares = 0

    # Iterate over the list
    for num in lst:
        # Check if the number is odd and positive
        if num % 2 != 0 and num >= 0:
            # Add the square of the number to the sum of squares
            sum_of_squares += num ** 2

    # Return the sum of squares
    return sum_of_squares
