
def is_sorted(lst):
    # Check if the list is empty
    if not lst:
        return True

    # Check if the list has more than 1 duplicate of the same number
    for i in lst:
        if lst.count(i) > 1:
            return False

    # Check if the list is sorted in ascending order
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:
            return False

    return True
