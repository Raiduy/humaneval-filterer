
def file_name_check(file_name):
    # Check if the file name contains more than three digits
    if len(re.findall(r'\d', file_name)) > 3:
        return 'No'

    # Check if the file name contains exactly one dot
    if file_name.count('.') != 1:
        return 'No'

    # Split the file name into two parts
    name, extension = file_name.split('.')

    # Check if the name is empty or starts with a letter
    if len(name) == 0 or not name[0].isalpha():
        return 'No'

    # Check if the extension is one of ['txt', 'exe', 'dll']
    if extension not in ['txt', 'exe', 'dll']:
        return 'No'

    return 'Yes'
