
def make_a_pile(n):
    if n < 1:
        raise ValueError("n must be a positive integer")

    pile = [n]
    for i in range(n):
        if n % 2 == 0:
            n += 2
        else:
            n += 1
        pile.append(n)

    return pile


