
def closest_integer(value):
    # Convert the value to a float
    value = float(value)

    # Check if the number is equidistant from two integers
    if value % 0.5 == 0:
        # Round away from zero
        if value > 0:
            return int(value + 0.5)
        else:
            return int(value - 0.5)
    else:
        # Round to the nearest integer
        return round(value)
