
def iscube(a):
    if a == 0:
        return True
    elif a < 0:
        a = -a
    cbrt = int(round(a ** (1. / 3)))
    return cbrt ** 3 == a

