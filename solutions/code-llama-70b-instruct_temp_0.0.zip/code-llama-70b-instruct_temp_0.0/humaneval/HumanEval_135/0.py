
def can_arrange(arr):
    # Initialize the largest index variable
    largest_index = -1

    # Iterate through the array
    for i in range(len(arr)):
        # Check if the current element is not greater than or equal to the element immediately preceding it
        if arr[i] < arr[i-1]:
            # Update the largest index
            largest_index = i

    return largest_index
