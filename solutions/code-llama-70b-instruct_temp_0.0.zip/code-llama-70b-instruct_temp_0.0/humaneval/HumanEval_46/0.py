

def fib4(n):
    if n < 0:
        raise ValueError("Input must be a non-negative integer.")
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0

    # Initialize a list to store the Fib4 sequence
    sequence = [0, 0, 2, 0]

    # Use a loop to generate the sequence
    for i in range(4, n + 1):
        next_term = sequence[i - 1] + sequence[i - 2] + sequence[i - 3] + sequence[i - 4]
        sequence.append(next_term)

    return sequence[n]

