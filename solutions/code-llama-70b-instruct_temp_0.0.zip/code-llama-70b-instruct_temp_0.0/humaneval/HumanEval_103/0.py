
def rounded_avg(n, m):
    if n > m:
        return -1
    else:
        total = 0
        for i in range(n, m+1):
            total += i
        average = total / (m - n + 1)
        rounded_average = round(average)
        binary_representation = bin(rounded_average)
        return binary_representation

