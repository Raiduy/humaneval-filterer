
def circular_shift(x, shift):
    # Convert the integer to a string
    x_str = str(x)

    # If shift is greater than the number of digits, return the digits reversed
    if shift >= len(x_str):
        return x_str[::-1]

    # Shift the digits to the right by shift and return the result
    return x_str[-shift:] + x_str[:-shift]
