
def intersection(interval1, interval2):
    # Check if the two intervals intersect
    if interval1[1] < interval2[0] or interval2[1] < interval1[0]:
        return "NO"

    # Calculate the length of the intersection
    intersection_length = min(interval1[1], interval2[1]) - max(interval1[0], interval2[0]) + 1

    # Check if the length of the intersection is a prime number
    if is_prime(intersection_length):
        return "YES"
    else:
        return "NO"

