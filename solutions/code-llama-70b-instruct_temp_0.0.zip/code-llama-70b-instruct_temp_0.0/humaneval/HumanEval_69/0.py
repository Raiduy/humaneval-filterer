
def search(lst):
    # Create a dictionary to store the frequency of each integer
    freq = {}

    # Iterate through the list and count the frequency of each integer
    for num in lst:
        if num in freq:
            freq[num] += 1
        else:
            freq[num] = 1

    # Find the greatest integer that is greater than 0 and has a frequency greater than or equal to the value of the integer itself
    result = -1
    for num, count in freq.items():
        if num > 0 and count >= num and num > result:
            result = num

    return result
