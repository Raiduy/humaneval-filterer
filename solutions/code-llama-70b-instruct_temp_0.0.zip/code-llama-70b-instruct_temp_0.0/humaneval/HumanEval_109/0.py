
def move_one_ball(arr):
    if len(arr) == 0:
        return True
    if len(arr) == 1:
        return True
    if len(arr) == 2:
        return True
    if arr[0] > arr[1]:
        return False
    for i in range(1, len(arr) - 1):
        if arr[i] < arr[i - 1] or arr[i] > arr[i + 1]:
            return False
    if arr[-1] < arr[-2]:
        return False
    return True
