
def maximum(arr, k):
    if k == 0:
        return []
    if k >= len(arr):
        return sorted(arr, reverse=True)
    max_nums = []
    for num in arr:
        while len(max_nums) > 0 and max_nums[0] < num and k > len(max_nums):
            max_nums.pop(0)
        max_nums.append(num)
    max_nums = sorted(max_nums, reverse=True)
    return max_nums[:k]
