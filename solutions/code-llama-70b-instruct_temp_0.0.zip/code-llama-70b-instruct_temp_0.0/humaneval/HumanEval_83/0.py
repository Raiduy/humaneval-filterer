
def starts_one_ends(n):
    if n == 1:
        return 1
    else:
        return (10 ** (n - 1) - 9 * (10 ** (n - 2))) * 2
