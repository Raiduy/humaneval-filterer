
def select_words(s, n):
    # Check if the input string is empty
    if not s:
        return []

    # Define a set of vowels
    vowels = set("aeiouAEIOU")

    # Split the input string into words
    words = s.split()

    # Initialize an empty list to store the result
    result = []

    # Iterate through each word in the input string
    for word in words:
        # Initialize a counter for consonants
        consonants = 0

        # Iterate through each character in the word
        for char in word:
            # Check if the character is a consonant
            if char not in vowels:
                consonants += 1

        # Check if the number of consonants is equal to n
        if consonants == n:
            result.append(word)

    return result
