
def compare_one(a, b):
    # Convert a and b to floats
    try:
        a = float(a.replace(",", "."))
        b = float(b.replace(",", "."))
    except ValueError:
        return None

    # Compare a and b
    if a > b:
        return a
    elif b > a:
        return b
    else:
        return None

