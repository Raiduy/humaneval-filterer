

def same_chars(s0, s1):
    s0 = ''.join(sorted(s0))
    s1 = ''.join(sorted(s1))
    return set(s0) == set(s1)
