
def is_multiply_prime(a):
    def is_prime(n):
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i * i <= n:
            if n % i == 0 or n % (i + 2) == 0:
                return False
            i += 6
        return True

    if a <= 1:
        return False

    primes = []
    for i in range(2, 100):
        if is_prime(i):
            primes.append(i)

    for x in primes:
        for y in primes:
            for z in primes:
                if x * y * z == a:
                    return True
    return False

