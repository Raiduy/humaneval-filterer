
def total_match(lst1, lst2):
    # Calculate the total number of characters in each list
    total1 = sum(len(s) for s in lst1)
    total2 = sum(len(s) for s in lst2)

    # Compare the totals and return the appropriate list
    if total1 < total2:
        return lst1
    elif total2 < total1:
        return lst2
    else:
        return lst1
