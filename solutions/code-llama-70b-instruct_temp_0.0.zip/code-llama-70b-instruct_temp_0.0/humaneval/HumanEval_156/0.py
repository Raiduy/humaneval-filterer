
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    # Define a dictionary of roman numerals
    roman_numerals = {
        1: 'i',
        5: 'v',
        10: 'x',
        50: 'l',
        100: 'c',
        500: 'd',
        1000: 'm'
    }

    # Initialize an empty string to store the roman numeral
    roman_numeral = ''

    # Iterate through the roman numerals in descending order
    for value, numeral in sorted(roman_numerals.items(), reverse=True):
        # Calculate the number of times the numeral should be added
        count = number // value

        # Add the numeral to the roman numeral string
        roman_numeral += numeral * count

        # Subtract the value of the numeral from the number
        number -= value * count

    # Return the roman numeral in lowercase
    return roman_numeral.lower()
