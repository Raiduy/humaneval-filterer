

def prime_fib(n):
    fib_numbers = [0, 1]
    while len(fib_numbers) < n:
        fib_numbers.append(fib_numbers[-1] + fib_numbers[-2])
    for i in range(len(fib_numbers)):
        if is_prime(fib_numbers[i]):
            n -= 1
        if n == 0:
            return fib_numbers[i]
    return None

