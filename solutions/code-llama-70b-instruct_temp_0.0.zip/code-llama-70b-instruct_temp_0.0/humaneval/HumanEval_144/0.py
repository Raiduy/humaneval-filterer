
def simplify(x, n):
    # Split the fractions into numerator and denominator
    x_num, x_den = x.split("/")
    n_num, n_den = n.split("/")

    # Convert the numerator and denominator to integers
    x_num = int(x_num)
    x_den = int(x_den)
    n_num = int(n_num)
    n_den = int(n_den)

    # Calculate the product of the fractions
    product = (x_num * n_num) / (x_den * n_den)

    # Check if the product is a whole number
    if product % 1 == 0:
        return True
    else:
        return False

