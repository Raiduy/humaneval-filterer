def create_alias(name: str) -> str:
    """ For a given name, create an alias following these rules:
        If the name includes a vowel, replace it with the next vowel in the cycle a->e->i->o->u->a. 
        If the name includes a consonant, replace it with the next consonant in alphabetical order, once 'z' is reached, loop back to 'b'.
        The alias should maintain the original names case (upper or lower)
        Ignore any non-alphabetical characters.

    >>> create_alias('John Doe')
    'Kujp Fui'
    """
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'

    def next_char(char):
        if char.lower() in vowels:
            return vowels[(vowels.index(char.lower()) + 1) % len(vowels)]
        elif char.lower() in consonants:
            return consonants[(consonants.index(char.lower()) + 1) % len(consonants)]
        else:
            return char
    return ''.join((next_char(char) if char.isalpha() else char for char in name))