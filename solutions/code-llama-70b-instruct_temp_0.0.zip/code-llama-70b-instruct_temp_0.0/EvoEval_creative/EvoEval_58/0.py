def interstellar_translator(earth_phrase):
    """
    Write a function that takes an earth phrase, and translates it into 
    an alien language that follows a specific set of rules. The rules for the 
    translation are as follows:

    1. All vowels (a,e,i,o,u) should be replaced with the next vowel in the 
       sequence (a->e, e->i, i->o, o->u, u->a).
    2. All consonants should be replaced with the next consonant that appears 
       in the english alphabet. If the consonant is 'z', replace it with 'b'.
    3. All spaces should be replaced with the '@' symbol.
    4. The first letter of every word should be capitalized.
    5. If the original word started with a vowel, append 'xy' to the end of the word. 
       If the original word started with a consonant, append 'yz' to the end of the word.

    Assume the input is a string containing only lowercase letters and spaces.
    
    Examples:
    >>> interstellar_translator('hello world')
    'Jimmuyz@Xusmfyz'
    >>> interstellar_translator('this is a test')
    'Vjotyz@Otxy@Exy@Vitvyz'
    """
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    translated_phrase = ''
    for word in earth_phrase.split():
        translated_word = ''
        for (i, char) in enumerate(word):
            if char in vowels:
                next_vowel_index = (vowels.index(char) + 1) % len(vowels)
                next_vowel = vowels[next_vowel_index]
                translated_word += next_vowel
            else:
                next_consonant_index = (consonants.index(char) + 1) % len(consonants)
                next_consonant = consonants[next_consonant_index]
                translated_word += next_consonant
        translated_word = translated_word.capitalize()
        if word[0] in vowels:
            translated_word += 'xy'
        else:
            translated_word += 'yz'
        translated_phrase += translated_word
    translated_phrase = translated_phrase.replace(' ', '@')
    return translated_phrase