from typing import List

def magical_alphabet(input_string: str) -> List[int]:
    """ 
    Given a string where 'a' represents '1', 'b' represents '2', 'c' represents '3' ... 'z' represents '26'. 
    This function should return a list of all possible combinations based on the interpretation of the input string. 
    For example, if input is '123', it should return ['abc', 'lc', 'aw'] which represents ['1,2,3', '12,3', '1,23'].

    >>> magical_alphabet('123')
    ['abc', 'lc', 'aw']
    
    >>> magical_alphabet('111')
    ['aaa', 'ak', 'ka']
    
    Note: Assume all input strings will only contain digits
    """
    mapping = {'1': 'a', '2': 'b', '3': 'c', '4': 'd', '5': 'e', '6': 'f', '7': 'g', '8': 'h', '9': 'i', '10': 'j', '11': 'k', '12': 'l', '13': 'm', '14': 'n', '15': 'o', '16': 'p', '17': 'q', '18': 'r', '19': 's', '20': 't', '21': 'u', '22': 'v', '23': 'w', '24': 'x', '25': 'y', '26': 'z'}
    if not input_string:
        return []
    if len(input_string) == 1:
        return [mapping[input_string]]
    (first, rest) = (input_string[0], input_string[1:])
    combinations = magical_alphabet(rest)
    results = []
    for combination in combinations:
        if first.isdigit():
            results.append(mapping[first] + combination)
        if len(first) == 2 and first.isdigit():
            results.append(mapping[first] + combination)
            results.append(first + combination)
    return results