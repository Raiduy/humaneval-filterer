def matrixMystery(m):
    if len(m) != len(m[0]):
        return 'Invalid Matrix'
    first_diagonal_sum = 0
    for i in range(len(m)):
        first_diagonal_sum += m[i][i]
    second_diagonal_sum = 0
    for i in range(len(m)):
        second_diagonal_sum += m[i][len(m) - i - 1]
    difference = abs(first_diagonal_sum - second_diagonal_sum)
    return difference