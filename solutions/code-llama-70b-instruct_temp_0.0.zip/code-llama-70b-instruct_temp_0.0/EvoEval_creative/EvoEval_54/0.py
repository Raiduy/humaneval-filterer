def find_star_map(lst, star):
    """
    You are given a 2 dimensional data, as a nested lists,
    which represents a star map where each individual star has a unique identifier (integer),
    however, unlike traditional maps, each row may contain a different number of columns.
    
    Given lst, and an integer 'star', find the star in the list and return a list of tuples,
    [(x1, y1), (x2, y2)...] such that each tuple is a coordinate - (row, column).
    If a star is found multiple times in the star map, include its coordinates each time.
    
    Start searching from the top left corner and sweep row by row. The coordinates start from (0,0).
    If no such star is found, return an empty list.
    
    Examples:
    find_star_map([
      [1,2,3,4,5,6],
      [7,8,9,10,11,12],
      [13,14,15,16,17,18]
    ], 10) returns [(1, 3)]
    
    find_star_map([
      [1,1,1],
      [2,2,2],
      [3,3,3]
    ], 2) returns [(1, 0), (1, 1), (1, 2)]
    
    find_star_map([
      [1,2,3],
      [4,5,6],
      [7,8,9]
    ], 20) returns []
    """
    coordinates = []
    for (row_index, row) in enumerate(lst):
        for (col_index, value) in enumerate(row):
            if value == star:
                coordinates.append((row_index, col_index))
    return coordinates