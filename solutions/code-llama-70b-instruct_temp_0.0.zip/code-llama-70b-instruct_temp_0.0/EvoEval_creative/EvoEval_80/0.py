def adventure_game(map, instructions):
    for i in range(len(map)):
        for j in range(len(map[i])):
            if map[i][j] == 'S':
                (start_row, start_column) = (i, j)
                break
    (player_row, player_column) = (start_row, start_column)
    path = [(player_row, player_column)]
    for instruction in instructions:
        if instruction == 'up':
            player_row -= 1
        elif instruction == 'down':
            player_row += 1
        elif instruction == 'left':
            player_column -= 1
        elif instruction == 'right':
            player_column += 1
        if map[player_row][player_column] == 'E':
            return path
        if player_row < 0 or player_row >= len(map) or player_column < 0 or (player_column >= len(map[player_row])) or (map[player_row][player_column] == 'X'):
            (player_row, player_column) = path[-1]
        path.append((player_row, player_column))
    return path