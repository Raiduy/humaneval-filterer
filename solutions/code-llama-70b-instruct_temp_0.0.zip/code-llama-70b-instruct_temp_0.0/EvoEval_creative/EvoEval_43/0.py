def space_travel(distance, speed, fuel, planet_gravity, spaceship_weight):
    duration = distance / speed
    fuel_consumption = spaceship_weight * planet_gravity * 0.1
    if fuel < duration:
        return 'Insufficient fuel'
    remaining_fuel = fuel - duration * fuel_consumption
    return round(remaining_fuel, 2)