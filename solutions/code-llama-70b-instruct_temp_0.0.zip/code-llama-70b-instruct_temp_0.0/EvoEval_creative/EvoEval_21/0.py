def crossword_validator(grid, words):
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')
    if len(grid) != len(grid[0]):
        raise ValueError('The grid is not a square.')