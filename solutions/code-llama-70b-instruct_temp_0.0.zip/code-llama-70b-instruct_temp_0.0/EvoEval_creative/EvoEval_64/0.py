def magical_sequence(start, end, divisor):
    if start < 1 or end < 1 or divisor < 1:
        raise ValueError('All input numbers must be positive integers.')
    if end < start:
        raise ValueError("'end' must be greater than or equal to 'start'.")
    result = []
    for i in range(start, end + 1):
        if is_prime(i) and i % divisor == 0:
            result.append(i)
    return result