def prime_cipher(s: str):
    """
    Given a string s, write a function that performs the following operations:
    - Replace each letter in the string s with the k-th prime number, where a is the 1st prime number, b is the 2nd prime number, z is the 26th prime number.
    - If the character in the string is not a lowercase letter a-z, leave it unchanged.
    - Return the new string.

    Notes:
    - The 1st prime number is 2, the 2nd is 3, the 3rd is 5, and so on.
    - The function should be case sensitive. Only lowercase letters should be replaced with prime numbers.

    Examples:
    >>> prime_cipher("hello")
    '1911373747'
    >>> prime_cipher("world")
    '834761377'
    >>> prime_cipher("Python!")
    'P9771194743!'
    >>> prime_cipher("12345")
    '12345'
    >>> prime_cipher("abc")
    '235'
    """
    prime_map = {'a': 2, 'b': 3, 'c': 5, 'd': 7, 'e': 11, 'f': 13, 'g': 17, 'h': 19, 'i': 23, 'j': 29, 'k': 31, 'l': 37, 'm': 41, 'n': 43, 'o': 47, 'p': 53, 'q': 59, 'r': 61, 's': 67, 't': 71, 'u': 73, 'v': 79, 'w': 83, 'x': 89, 'y': 97, 'z': 101}
    result = ''
    for char in s:
        if char.islower():
            result += str(prime_map[char])
        else:
            result += char
    return result