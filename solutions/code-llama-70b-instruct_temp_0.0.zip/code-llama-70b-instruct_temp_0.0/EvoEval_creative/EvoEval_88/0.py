def planet_population(dict_of_planets):
    if not dict_of_planets:
        return {}
    result = {}
    for (planet, features) in dict_of_planets.items():
        if len(features) != 2:
            continue
        (population, size) = features
        if population is None or size is None:
            continue
        if not isinstance(population, int) or not isinstance(size, int):
            continue
        if population < 0 or size < 0:
            continue
        if size == 0:
            continue
        population_density = population / size
        result[planet] = round(population_density, 2)
    return result