def magical_transformation(s):
    vowels = 'aeiouAEIOU'
    consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    result = ''
    for (i, char) in enumerate(s):
        if char in vowels:
            result += vowels[(vowels.index(char) + 1) % len(vowels)]
        elif char in consonants:
            result += consonants[(consonants.index(char) + 1) % len(consonants)]
        elif char == '?':
            if i % 2 == 0:
                result += '!'
            else:
                result += '?'
        elif char == '!':
            if i % 2 == 0:
                result += '?'
            else:
                result += '!'
        else:
            result += char
    return result