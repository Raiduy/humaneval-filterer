def alien_language_translator(english_word: str):
    """
    Translates an English word into an alien language.

    Args:
        english_word (str): The English word to translate.

    Returns:
        str: The translated word in the alien language.
    """
    alien_symbols = {'a': '+', 'b': '-', 'c': '*', 'd': '/', 'e': '%', 'f': '@', 'g': '!', 'h': '#', 'i': '$', 'j': '^', 'k': '&', 'l': '(', 'm': ')', 'n': '=', 'o': '?', 'p': ':', 'q': ';', 'r': '`', 's': '~', 't': '>', 'u': '<', 'v': '{', 'w': '}', 'x': '[', 'y': ']', 'z': '|'}
    alien_word = ''
    for letter in english_word:
        alien_word += alien_symbols[letter]
    return alien_word