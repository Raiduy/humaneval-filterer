def create_pyramid(lst):
    pyramid = []
    for num in lst:
        pyramid.append('#' * num)
    return pyramid