def treasure_hunt(grid, bag_capacity):
    import math
    '\n    You are an intrepid treasure hunter in a mysterious pyramid. The pyramid is represented by a rectangular grid, \n    where each row represents a different chamber and each 1 represents a single treasure chest. \n    Each chamber has a certain number of treasures and you have a bag that can carry a limited number of chests at a time. \n    Your task is to collect as many treasures as possible. \n    Output the number of trips you need to collect all treasures.\n    A trip is defined as a going in or out of the pyramid (i.e., enter is a separate trip to exist)\n\n    Example 1:\n        Input: \n            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]\n            bag_capacity : 1\n        Output: 12\n\n    Example 2:\n        Input: \n            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]\n            bag_capacity : 2\n        Output: 10\n    \n    Example 3:\n        Input: \n            grid : [[0,0,0], [0,0,0]]\n            bag_capacity : 5\n        Output: 0\n\n    Constraints:\n        * all chambers have the same number of chests\n        * grid[i][j] -> 0 | 1\n    '
    if not grid:
        return 0
    num_chambers = len(grid)
    num_chests = len(grid[0])
    if bag_capacity >= num_chests:
        return num_chambers * 2
    trips = 0
    current_chamber = 0
    while current_chamber < num_chambers:
        num_chests_in_chamber = sum(grid[current_chamber])
        trips_in_chamber = math.ceil(num_chests_in_chamber / bag_capacity)
        trips += trips_in_chamber
        current_chamber += 1
    return trips