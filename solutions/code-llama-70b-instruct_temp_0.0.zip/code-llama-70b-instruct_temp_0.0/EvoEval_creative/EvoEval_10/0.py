from typing import List

def count_animals(animal_string: str) -> List[int]:
    """
    Input to this function is a string representing animals and their sounds in a special ASCII format.
    Your task is to parse this string and return a list of integers corresponding to how many times each
    animal made a sound.

    Here is a legend:
    'C' - Cat, makes sound 'meow'
    'D' - Dog, makes sound 'woof'
    'B' - Bird, makes sound 'chirp'

    Each sound is represented by a '|', and each animal-sound pair is separated by a space.

    For example, a 'Cat' making sound 3 times will be represented as 'C|||'.

    The function should return a list of integers representing how many sounds each animal made, in the order
    they appear in the string. Skip invalid animals and also skip animals that has already appeared twice before. Furthermore, skip any animals after total animals (invalid and valid) has reached 5

    >>> count_animals('C||| D|| B| C| B||| D|||')
    [3, 2, 1, 1, 3]
    """
    animal_sounds = {'C': 'meow', 'D': 'woof', 'B': 'chirp'}
    animal_counts = []
    seen_animals = set()
    total_animals = 0
    animal_sound_pairs = animal_string.split()
    for animal_sound_pair in animal_sound_pairs:
        if total_animals >= 5:
            break
        animal = animal_sound_pair[0]
        sound = animal_sound_pair[1:]
        if animal in animal_sounds and animal not in seen_animals:
            if sound == '|' * len(animal_sounds[animal]):
                animal_counts.append(len(sound))
                seen_animals.add(animal)
                total_animals += 1
    return animal_counts