def prime_anagram_pairs(n):
    primes = [i for i in range(2, n) if is_prime(i)]
    anagram_pairs = []
    for i in range(len(primes)):
        for j in range(i + 1, len(primes)):
            if sorted(str(primes[i])) == sorted(str(primes[j])):
                anagram_pairs.append((primes[i], primes[j]))
    return sorted(anagram_pairs)