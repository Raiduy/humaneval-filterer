def word_frequency_analysis(text: str, word: str):
    """Return the frequency of the given word in a text. Also, return the sentence in which the word appears the most times.

    The function will return a tuple where the first element is the frequency of the word, and the second element is the sentence with the max frequency of the word. If the word is not found in the text, return (0, "").

    Assume that sentences end with a period.
    """
    sentences = text.split('.')
    frequency = 0
    max_frequency = 0
    sentence_with_max_frequency = ''
    for sentence in sentences:
        sentence_frequency = sentence.lower().count(word.lower())
        frequency += sentence_frequency
        if sentence_frequency > max_frequency:
            max_frequency = sentence_frequency
            sentence_with_max_frequency = sentence
    return (frequency, sentence_with_max_frequency)