from typing import List, Tuple

def find_path(maze: List[List[int]], start: Tuple[int], end: Tuple[int]) -> List[Tuple[int]]:
    """Returns the shortest path from start to end in a maze represented by a 2D array.

    The maze is a 2D array where 0s represent walls and 1s represent open paths. The start and end points 
    are tuples representing coordinates in the 2D array. The function should return a list of points 
    representing the shortest path from start to end. If no path is possible, return an empty list.

    >>> maze = [[1,0,1,1,1], [1,0,1,0,1], [1,1,1,0,1], [1,0,0,0,1], [1,1,1,1,1]]
    >>> start = (0,0)
    >>> end = (4, 4)
    >>> find_path(maze, start, end)
    [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (4, 1), (4, 2), (4, 3), (4, 4)]

    >>> maze = [[1,0,1], [0,0,1], [1,1,1]]
    >>> start = (0,0)
    >>> end = (2, 2)
    >>> find_path(maze, start, end)
    []
    """
    if not maze or not maze[0] or start not in maze or (end not in maze):
        return []
    if maze[start[0]][start[1]] == 0 or maze[end[0]][end[1]] == 0:
        return []
    queue = [(start, [start])]
    visited = set()
    while queue:
        ((x, y), path) = queue.pop(0)
        if (x, y) == end:
            return path
        visited.add((x, y))
        for (dx, dy) in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            (new_x, new_y) = (x + dx, y + dy)
            if 0 <= new_x < len(maze) and 0 <= new_y < len(maze[0]):
                if maze[new_x][new_y] == 1 and (new_x, new_y) not in visited:
                    queue.append(((new_x, new_y), path + [(new_x, new_y)]))
    return []