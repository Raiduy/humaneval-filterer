def magicTrick(cards, magicNumber):
    card_dict = {}
    for (i, card) in enumerate(cards):
        if magicNumber / card in card_dict:
            return (card_dict[magicNumber / card], i)
        card_dict[card] = i
    return 'No magic today'