def reverse_vowels(s):
    vowels = 'aeiouAEIOU'
    vowel_indices = [i for (i, c) in enumerate(s) if c in vowels]
    vowel_chars = [s[i] for i in vowel_indices]
    reversed_vowel_chars = vowel_chars[::-1]
    result = list(s)
    for (i, c) in zip(vowel_indices, reversed_vowel_chars):
        result[i] = c
    return ''.join(result)