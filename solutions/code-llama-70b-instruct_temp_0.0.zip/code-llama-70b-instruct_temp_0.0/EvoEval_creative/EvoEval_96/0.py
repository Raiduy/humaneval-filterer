def get_magic_indices(lst):
    magic_indices = []
    for (i, value) in enumerate(lst):
        if value % (i + 1) == 0 and product_of_digits(abs(value)) == i + 1:
            magic_indices.append(i)
    return sorted(magic_indices)