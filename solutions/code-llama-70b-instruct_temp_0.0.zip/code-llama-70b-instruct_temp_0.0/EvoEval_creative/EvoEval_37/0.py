def string_transform(s):
    """Write a function string_transform which takes a string representing
    a sentence as input and returns the sentence in a transformed format.
    The transformation rules are as follows: 
    - Every vowel in the sentence should be replaced with the next vowel in the sequence: 'a' -> 'e', 'e' -> 'i', 'i' -> 'o', 'o' -> 'u', 'u' -> 'a'.
    - Every consonant should be replaced with the next consonant in the alphabet. For instance, 'b' becomes 'c', 'm' becomes 'n', etc. 'z' wraps around to 'b'.
    - Every punctuation, space, and digit remains the same. 

    All transformations should preserve the original case. For example, 'A' transforms to 'E', 'M' to 'N', etc. 

    Example:
    >>> string_transform("Hello, World!")
    'Jimmu, Xusmf!'
    >>> string_transform("Coding is Fun!")
    'Dufoph jt Gap!'
    """
    vowels = 'aeiouAEIOU'
    consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    z_to_b = 'zZ'
    punctuation = '.,!?'
    digits = '0123456789'
    transformed_string = ''
    for char in s:
        if char in vowels:
            transformed_string += vowels[(vowels.index(char) + 1) % len(vowels)]
        elif char in consonants:
            transformed_string += consonants[(consonants.index(char) + 1) % len(consonants)]
        elif char in z_to_b:
            transformed_string += 'b' if char.islower() else 'B'
        elif char in punctuation or char in digits:
            transformed_string += char
        else:
            transformed_string += char
    return transformed_string