def transform_string(s):
    transformed_chars = []
    for (idx, char) in enumerate(s):
        if char == ' ':
            transformed_chars.append(char)
        elif char.isalpha():
            if idx % 2 == 1:
                transformed_chars.append(char.swapcase())
            else:
                transformed_chars.append(char)
        else:
            transformed_chars.append(char)
    transformed_string = ''.join(transformed_chars)
    vowels = 'aeiouAEIOU'
    next_vowels = 'eiouaEIOUA'
    transformed_string = transformed_string.translate(str.maketrans(vowels, next_vowels))
    consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    prev_consonants = 'zbcdfghjklmnpqrstvwxyZBCDFGHJKLMNPQRSTVWXY'
    transformed_string = transformed_string.translate(str.maketrans(consonants, prev_consonants))
    return transformed_string