def asciiArt(n, s):
    top_row = '*' + s * n + '*'
    bottom_row = '*' * (len(s) * n + 1)
    middle_rows = []
    for _ in range(n):
        middle_rows.append(top_row)
    return '\n'.join([top_row] + middle_rows + [bottom_row])