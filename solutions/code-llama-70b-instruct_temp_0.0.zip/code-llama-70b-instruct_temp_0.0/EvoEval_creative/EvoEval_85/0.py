def princess_rescue(coord, grid):
    if not grid:
        return -1
    if coord[0] >= len(grid) or coord[1] >= len(grid[0]):
        return -1
    if grid[coord[0]][coord[1]] == 1:
        return -1
    min_moves = float('inf')

    def dfs(row, col, moves):
        nonlocal min_moves
        if row == coord[0] and col == coord[1]:
            min_moves = min(min_moves, moves)
            return
        if row < len(grid) - 1 and grid[row + 1][col] == 0:
            dfs(row + 1, col, moves + 1)
        if col < len(grid[0]) - 1 and grid[row][col + 1] == 0:
            dfs(row, col + 1, moves + 1)
    dfs(0, 0, 0)
    if min_moves == float('inf'):
        return -1
    return min_moves