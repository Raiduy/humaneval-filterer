def happy_ants(path_length, sugar_locations, ant_positions):
    sugar_locations = sorted(sugar_locations)
    ants = sorted(ant_positions, key=lambda x: x[0])
    happy_ants = []
    for ant in ants:
        ant_position = ant[0]
        if ant_position < path_length:
            if ant[1] == 'right':
                for sugar_location in sugar_locations:
                    if ant_position <= sugar_location:
                        happy_ants.append(ant)
                        break
            elif ant[1] == 'left':
                for sugar_location in sugar_locations[::-1]:
                    if ant_position >= sugar_location:
                        happy_ants.append(ant)
                        break
    return len(happy_ants)