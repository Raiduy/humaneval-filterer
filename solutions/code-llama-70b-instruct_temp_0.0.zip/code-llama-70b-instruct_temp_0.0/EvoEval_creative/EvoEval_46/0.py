def hidden_message(test_cases):
    secret_messages = []
    for test_case in test_cases:
        secret_message = ''
        for word in test_case:
            if word == 'Take the cannoli.':
                secret_message += word
                break
            else:
                secret_message += word[0].lower()
        secret_messages.append(secret_message)
    return secret_messages