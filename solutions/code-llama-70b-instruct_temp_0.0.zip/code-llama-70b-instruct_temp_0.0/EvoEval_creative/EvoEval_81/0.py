def alien_language(word_list, alien_dictionary):
    if len(word_list) == 0:
        return 'CORRECT'
    for i in range(len(word_list) - 1):
        word1 = word_list[i]
        word2 = word_list[i + 1]
        for j in range(min(len(word1), len(word2))):
            if word1[j] != word2[j]:
                if alien_dictionary.index(word1[j]) > alien_dictionary.index(word2[j]):
                    return 'INCORRECT'
                break
            elif len(word1) > len(word2):
                return 'INCORRECT'
    return 'CORRECT'