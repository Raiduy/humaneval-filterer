def morse_decoder(msg):
    morse_code_mapping = {'01': 'A', '1000': 'B', '1010': 'C', '100': 'D', '0': 'E', '0010': 'F', '110': 'G', '0000': 'H', '00': 'I', '0111': 'J', '101': 'K', '0100': 'L', '11': 'M', '10': 'N', '111': 'O', '0110': 'P', '1101': 'Q', '010': 'R', '000': 'S', '1': 'T', '001': 'U', '0001': 'V', '011': 'W', '1001': 'X', '1011': 'Y', '1100': 'Z', '01111': '1', '00111': '2', '00011': '3', '00001': '4', '00000': '5', '10000': '6', '11000': '7', '11100': '8', '11110': '9', '11111': '0'}
    characters = msg.split('/')
    decoded_characters = []
    for character in characters:
        dots_and_dashes = character.split(' ')
        decoded_dots_and_dashes = []
        for dot_and_dash in dots_and_dashes:
            if dot_and_dash in morse_code_mapping:
                decoded_dots_and_dashes.append(morse_code_mapping[dot_and_dash])
        decoded_characters.append(''.join(decoded_dots_and_dashes))
    decoded_message = ''.join(decoded_characters)
    return decoded_message