def transform_canvas(canvas: str) -> str:
    """
    You have an canvas containing either '#' (representing a wall), '-' (representing 
    an empty space), or 'P' (representing the point at which a painter starts). The painter 
    can move horizontally on the canvas and paints all empty spaces he encounters
    with '*' without crossing or hitting the walls.
    
    The task is to return an updated canvas with all the accessible spaces painted, 
    keeping wall configuration and unaccessible spaces same. If the canvas contains no painter 'P', 
    return the canvas as it is. If there are more than one 'P' or the number of painted space divides the empty spaces evenly, return 'Invalid canvas'.

    Examples:

    >>> transform_canvas('P----#-----#-----#-----')
    'P****#-----#-----#-----'
    
    >>> transform_canvas('--#-P#-----#-----#--#--')
    'Invalid canvas'
    
    >>> transform_canvas('-----#--P--#-----#-----')
    '-----#**P**#-----#-----'
    
    >>> transform_canvas('-----#-----#--P---#P----')
    'Invalid canvas'
    """
    if not canvas or not isinstance(canvas, str):
        return 'Invalid canvas'
    painter_count = canvas.count('P')
    if painter_count == 0:
        return canvas
    elif painter_count > 1:
        return 'Invalid canvas'
    painter_index = canvas.find('P')
    if painter_index == 0:
        return 'Invalid canvas'
    if painter_index == len(canvas) - 1:
        return 'Invalid canvas'
    if canvas[painter_index - 1] == '#' and canvas[painter_index + 1] == '#':
        return 'Invalid canvas'
    if canvas[painter_index - 1] == '-' and canvas[painter_index + 1] == '-':
        return 'Invalid canvas'
    if canvas[painter_index - 1] == '#' and canvas[painter_index + 1] == '-':
        return 'Invalid canvas'
    if canvas[painter_index - 1] == '-' and canvas[painter_index + 1] == '#':
        return 'Invalid canvas'
    if canvas[painter_index - 1] == '#' and canvas[painter_index + 1] == '#':
        return 'Invalid canvas'
    if canvas[painter_index - 1] == '-' and canvas[painter_index + 1] == '-':
        return 'Invalid canvas'