def potion_mixing(potions, target):
    potions_list = [(potion.split()[0], int(potion.split()[-1])) for potion in potions]
    potions_list.sort(key=lambda x: x[1], reverse=True)
    best_combination = []
    best_sum = 0

    def find_combination(current_combination, current_sum, potions_list):
        nonlocal best_combination, best_sum
        if current_sum > target:
            return
        if current_sum == target:
            if not best_combination or len(current_combination) < len(best_combination) or (len(current_combination) == len(best_combination) and ''.join(current_combination) < ''.join(best_combination)):
                best_combination = current_combination[:]
                best_sum = current_sum
            return
        for (i, (potion, power)) in enumerate(potions_list):
            if potion in current_combination:
                continue
            current_combination.append(potion)
            find_combination(current_combination, current_sum + power, potions_list[i + 1:])
            current_combination.pop()
    find_combination([], 0, potions_list)
    return best_combination