def wizard_battle(dragon_hp, wizards):
    for (wizard, power) in wizards:
        dragon_hp -= power
        if dragon_hp <= 0:
            return wizard
    return 'The dragon won!'