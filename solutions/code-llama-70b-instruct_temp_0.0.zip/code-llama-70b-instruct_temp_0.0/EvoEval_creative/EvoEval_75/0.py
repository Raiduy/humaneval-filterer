def magical_string_transformer(input_str):
    vowels = 'aeiouAEIOU'
    consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    digits = '0123456789'
    punctuation = '!?.,'
    output_str = ''
    for (i, char) in enumerate(input_str):
        if char in vowels:
            output_str += vowels[(vowels.index(char) + 1) % len(vowels)]
        elif char in consonants:
            output_str += consonants[(consonants.index(char) + 1) % len(consonants)]
        elif char in digits:
            output_str += str((int(char) + 1) % 10)
        elif char in punctuation:
            if char == '?' and i % 2 == 0:
                output_str += '!'
            elif char == '!' and i % 2 == 1:
                output_str += '?'
            else:
                output_str += char
        else:
            output_str += char
    return output_str