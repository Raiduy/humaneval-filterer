from typing import List, Tuple

def minesweeper_clicked(grid: List[List[int]], position: Tuple[int, int]) -> List[List[int]]:
    """
    The grid is a representation of a Minesweeper game.
    The position represents the coordinates (x, y) that the player clicked.

    Here, 0 means an empty cell, 1 means a mine, and -1 represents an unknown cell (which has not been clicked yet).
    If the player clicks on a cell, and it is a mine, return the initial grid.
    If the cell is empty, convert all the adjacent cells (horizontal, vertical, and diagonal cells) to a 0 too (don't change cell if its a mine).

    If the cell clicked is already revealed (i.e., is a 0), return the initial grid.
    If the cell clicked is out of the grid, return the initial grid.

    Parameters:
    grid (List[List[int]]): The game grid represented as a 2D list.
    position (Tuple[int, int]): A tuple representing the coordinates the player clicked.

    Returns:
    List[List[int]]: The updated game grid.

    Examples:
    >>> minesweeper_clicked([[0, 1, -1], [1, -1, 0], [0, 1, 1]], (1, 2))
    [[0, 1, -1], [1, -1, 0], [0, 1, 1]]

    >>> minesweeper_clicked([[0, 1, -1], [1, -1, 0], [0, 1, 1]], (2, 2))
    [[0, 1, -1], [1, -1, 0], [0, 1, 1]]

    >>> minesweeper_clicked([[0, 1, -1], [1, -1, 0], [0, 1, 1]], (1, 1))
    [[0, 1, 0], [1, 0, 0], [0, 1, 1]]
    """
    if grid[position[0]][position[1]] == 0 or position[0] not in range(len(grid)) or position[1] not in range(len(grid[0])):
        return grid
    if grid[position[0]][position[1]] == 1:
        return grid
    if grid[position[0]][position[1]] == -1:
        grid[position[0]][position[1]] = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                if 0 <= position[0] + i < len(grid) and 0 <= position[1] + j < len(grid[0]) and (grid[position[0] + i][position[1] + j] != 1):
                    grid[position[0] + i][position[1] + j] = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                if 0 <= position[0] + i < len(grid) and 0 <= position[1] + j < len(grid[0]) and (grid[position[0] + i][position[1] + j] != 1):
                    grid[position[0] + i][position[1] + j] = 0
    return grid