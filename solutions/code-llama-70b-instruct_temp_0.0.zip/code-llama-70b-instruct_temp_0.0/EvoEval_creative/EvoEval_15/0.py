def evaluate_poker_hand(hand):
    card_counts = {}
    for card in hand:
        value = card[0]
        if value in card_counts:
            card_counts[value] += 1
        else:
            card_counts[value] = 1
    score = 0
    for (value, count) in card_counts.items():
        if count == 2:
            score += int(value)
        elif count == 3:
            score += 2 * int(value)
        elif count == 4:
            score += 3 * int(value)
        elif count == 5:
            score += 4 * int(value)
    return score