def magical_seven(n: int):
    if n < 1:
        raise ValueError('n must be a positive integer')
    current_number = 0
    num_magical_sevens = 0
    while num_magical_sevens < n:
        current_number += 1
        if current_number % 7 == 0:
            if sum((int(digit) for digit in str(current_number))) == 7:
                num_magical_sevens += 1
    return current_number