def paint_fountain(n):
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    fountain = ''
    for i in range(n):
        width = 2 * i + 1
        layer = ''
        for j in range(width):
            index = (i + j) % len(alphabet)
            layer += alphabet[index]
        fountain += layer.center(2 * n - 1) + '\n'
    return fountain