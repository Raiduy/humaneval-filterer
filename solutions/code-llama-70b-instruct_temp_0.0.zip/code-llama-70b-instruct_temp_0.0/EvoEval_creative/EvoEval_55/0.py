def treasure_map(message, shift):
    """
    Create a function called 'treasure_map' that takes two parameters: a 'message' string and an integer 'shift'.
    The function should encrypt the message using a Caesar cipher, a type of substitution cipher in which 
    each character in the message is 'shifted' a certain number of places down the alphabet. 
    
    However, there's a twist: instead of a regular Caesar cipher, you should implement a 'jumping' Caesar cipher. 
    That is, for the first character of the message, you should shift it by one place. For the second character 
    of the message, you should shift it by two places, and so on, increasing the shift by one for each subsequent 
    character. The 'shift' parameter determines the initial shift for the first character.

    Note that the shifting should be cyclical - if it reaches the end of the alphabet, it should wrap around to the 
    beginning. The function needs to handle both lower and upper case letters, but should ignore non-alphabet 
    characters (they should not be modified).

    Examples:
    treasure_map('Hallo', 1) returns 'Icopt'
    treasure_map('XyZ', 2) returns 'ZbD'
    treasure_map('Treasure', 3) returns 'Wvjgzcao'
    treasure_map('Map', 4) returns 'Qfv'
    """
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    alphabet_upper = alphabet.upper()
    encrypted_message = ''
    for (i, char) in enumerate(message):
        if char.isalpha():
            shift_value = shift + i
            if char.islower():
                char_index = alphabet.find(char)
                shifted_char_index = (char_index + shift_value) % 26
                shifted_char = alphabet[shifted_char_index]
                encrypted_message += shifted_char
            else:
                char_index = alphabet_upper.find(char)
                shifted_char_index = (char_index + shift_value) % 26
                shifted_char = alphabet_upper[shifted_char_index]
                encrypted_message += shifted_char
        else:
            encrypted_message += char
    return encrypted_message