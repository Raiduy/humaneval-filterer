def find_castle(arr):
    max_hills_seen = 0
    for i in range(len(arr)):
        hills_seen = 1
        for j in range(i - 1, -1, -1):
            if arr[j] <= arr[i]:
                hills_seen += 1
            else:
                break
        for j in range(i + 1, len(arr)):
            if arr[j] <= arr[i]:
                hills_seen += 1
            else:
                break
        max_hills_seen = max(max_hills_seen, hills_seen)
    return max_hills_seen