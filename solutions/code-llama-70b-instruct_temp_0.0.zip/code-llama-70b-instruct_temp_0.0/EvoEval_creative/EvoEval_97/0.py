def alien_invasion(alien, humans):
    if not isinstance(alien, str) or not isinstance(humans, dict):
        return []
    continents = ['Asia', 'Africa', 'Europe', 'North America', 'South America']
    humans_by_continent = {}
    for (human, continent) in humans.items():
        if not isinstance(human, str) or not isinstance(continent, str):
            return []
        if continent not in continents:
            return []
        if continent not in humans_by_continent:
            humans_by_continent[continent] = []
        humans_by_continent[continent].append(human)
    humans_encountered = []
    for continent in continents:
        if continent in humans_by_continent:
            humans_encountered.extend(humans_by_continent[continent])
    return humans_encountered