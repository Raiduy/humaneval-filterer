def nature_sequence_generator(n, a, b):
    sequence = [a, b]
    for i in range(2, n):
        sequence.append(sequence[i - 2] + sequence[i - 1] + i)
    for i in range(len(sequence)):
        if is_prime(sequence[i]):
            sequence[i] = 'prime'
    return sequence