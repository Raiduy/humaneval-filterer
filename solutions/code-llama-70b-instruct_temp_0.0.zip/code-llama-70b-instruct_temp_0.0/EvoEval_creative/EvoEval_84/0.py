def tree_traversal(tree):

    def dfs(node, path):
        if not node:
            return
        if not node.get('left') and (not node.get('right')):
            result.append(path + [node['value']])
        dfs(node.get('left'), path + [node['value']])
        dfs(node.get('right'), path + [node['value']])
    result = []
    dfs(tree, [])
    return result