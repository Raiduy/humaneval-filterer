def pathfinder(maze, start, end):
    if start == end:
        return []
    if not (0 <= start[0] < len(maze) and 0 <= start[1] < len(maze[0])):
        return []
    if not (0 <= end[0] < len(maze) and 0 <= end[1] < len(maze[0])):
        return []
    if maze[start[0]][start[1]] != 0:
        return []
    if maze[end[0]][end[1]] != 0:
        return []
    queue = [(start, [])]
    visited = set()
    while queue:
        ((x, y), path) = queue.pop(0)
        if (x, y) == end:
            return path
        if (x, y) in visited:
            continue
        visited.add((x, y))
        for (x2, y2, direction) in [(x + 1, y, 'right'), (x - 1, y, 'left'), (x, y + 1, 'down'), (x, y - 1, 'up')]:
            if 0 <= x2 < len(maze) and 0 <= y2 < len(maze[0]) and (maze[x2][y2] == 0) and ((x2, y2) not in visited):
                queue.append(((x2, y2), path + [direction]))
    return []