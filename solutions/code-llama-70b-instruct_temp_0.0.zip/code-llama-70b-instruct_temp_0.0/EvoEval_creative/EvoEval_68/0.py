def magical_sorting(arr):
    if not arr:
        return True
    if all((arr[i] <= arr[i + 1] for i in range(len(arr) - 1))):
        return True
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            if arr[i] > arr[j]:
                (arr[i], arr[j]) = (arr[j], arr[i])
                break
    for i in range(len(arr)):
        if all((arr[j] <= arr[(j + 1) % len(arr)] for j in range(len(arr)))):
            return True
        arr.append(arr.pop(0))
    return False