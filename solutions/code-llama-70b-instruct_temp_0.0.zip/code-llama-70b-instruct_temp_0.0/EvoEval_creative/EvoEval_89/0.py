def space_invaders(aliens, ray):
    destroyed_aliens = set()
    destroyed_aliens.add(ray)
    destroyed_aliens.add(ray - 1)
    destroyed_aliens.add(ray + 1)
    remaining_aliens = []
    for alien in aliens:
        if alien not in destroyed_aliens:
            remaining_aliens.append(alien)
    return remaining_aliens