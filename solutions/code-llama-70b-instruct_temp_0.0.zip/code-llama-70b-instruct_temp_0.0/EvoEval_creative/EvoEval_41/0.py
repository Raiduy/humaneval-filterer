def spider_web_jump(arr: List[List[int]]) -> int:
    energy_required = float('inf')
    (safe_cell_row, safe_cell_col) = find_safe_cell(arr)

    def dfs(row, col, energy):
        nonlocal energy_required
        if row == safe_cell_row and col == safe_cell_col:
            energy_required = min(energy_required, energy)
            return
        if row < 0 or row >= len(arr) or col < 0 or (col >= len(arr[0])) or (arr[row][col] > energy):
            return
        arr[row][col] = -1
        for (dr, dc) in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            dfs(row + dr, col + dc, energy + arr[row][col])
        arr[row][col] = energy
    dfs(0, 0, 0)
    return energy_required