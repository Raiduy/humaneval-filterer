from typing import List, Union

def calculate_shipping_cost(items: List[Union[str, float]], location: str) -> float:
    """
    Given a list of items (represented by their weights in kg) and a location,
    calculate the cost of shipping. Each item has a base shipping cost of $5.0.
    The location multiplies the total cost by a certain factor:
    - "Local": no additional factor
    - "National": factor of 1.5
    - "International": factor of 2.5
    - other location: no additional factor
    If the item's weight is more than 5kg, an additional charge of $10.0 is added.
    
    If an item is passed as a string instead of a float, consider its weight as 1kg and all previous factors are multiplied by 1.5. This multiplication only occurs once even if there are multiple string items.
    
    Return the total shipping cost rounded to two decimal places as a string.
    
    >>> calculate_shipping_cost([3.0, 'Book', 7.0], 'National')
    "56.25"
    >>> calculate_shipping_cost([1.0, 2.0, 3.0, 4.0], 'Local')
    "20.00"
    >>> calculate_shipping_cost([5.5, 2.0, 3.0], 'International')
    "62.50"
    """
    base_cost = 5.0
    base_costs = [base_cost for _ in range(len(items))]
    has_string_item = False
    for (i, item) in enumerate(items):
        if isinstance(item, str):
            base_costs[i] *= 1.5
            has_string_item = True
    total_costs = []
    for (item, base_cost) in zip(items, base_costs):
        if isinstance(item, float):
            item_cost = base_cost * item
            if item > 5:
                item_cost += 10
        else:
            item_cost = base_cost * 1
        total_costs.append(item_cost)
    total_cost = sum(total_costs)
    if location == 'National':
        total_cost *= 1.5
    elif location == 'International':
        total_cost *= 2.5
    if has_string_item:
        total_cost *= 1.5
    return f'{total_cost:.2f}'