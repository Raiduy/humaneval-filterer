def fibonacci_sum(n):
    """
    Given a positive integer n, return the sum of the first n numbers in the Fibonacci sequence.
    The Fibonacci sequence is a series of numbers where a number is the sum of the two preceding ones, starting with 0 and 1.
    """
    if n < 1:
        return 0
    elif n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        (a, b) = (0, 1)
        total = 1
        for _ in range(n - 2):
            (a, b) = (b, a + b)
            total += b
        return total