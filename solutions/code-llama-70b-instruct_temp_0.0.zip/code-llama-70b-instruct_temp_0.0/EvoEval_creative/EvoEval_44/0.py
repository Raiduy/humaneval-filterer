def fairy_tale_transport(q, w, e):
    if sum(q) <= 3 * e:
        return True
    elif sum(q) <= w + 2 * e:
        return True
    else:
        return False