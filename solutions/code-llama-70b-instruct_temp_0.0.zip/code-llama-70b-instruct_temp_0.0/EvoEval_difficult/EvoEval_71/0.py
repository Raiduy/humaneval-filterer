def triangle_area(a, b, c, d, e, f):
    if (d - b) * (f - b) == (e - c) * (c - a):
        return 'Invalid'
    area = abs(1 / 2 * (a * (d - f) + c * (f - b) + e * (b - d)))
    rounded_area = round(area, 3)
    return rounded_area