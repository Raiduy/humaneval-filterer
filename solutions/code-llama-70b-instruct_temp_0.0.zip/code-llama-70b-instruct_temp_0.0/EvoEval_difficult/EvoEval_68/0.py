def pluck_and_replace(arr, replacement):
    if not arr:
        return []
    smallest_value = float('inf')
    smallest_index = -1
    for (i, value) in enumerate(arr):
        if value % 2 == 0 and value < smallest_value:
            smallest_value = value
            smallest_index = i
    if smallest_value == float('inf'):
        return []
    if replacement in arr:
        return [-1, -1, replacement, -1]
    arr[smallest_index] = replacement
    return [smallest_value, smallest_index, replacement, smallest_index]