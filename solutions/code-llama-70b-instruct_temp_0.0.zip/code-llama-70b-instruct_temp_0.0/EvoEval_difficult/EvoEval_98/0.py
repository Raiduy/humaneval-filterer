def count_spec_chars(s, m, n):
    if len(s) < m or len(s) > n:
        return -1
    vowels = 'AEIOU'
    consonants = 'BCDFGHJKLMNPQRSTVWXYZ'
    uppercase_vowels_sum = 0
    lowercase_consonants_sum = 0
    for (i, char) in enumerate(s):
        if i % 2 == 0:
            if char.isalpha() and char.isupper() and (char in vowels):
                uppercase_vowels_sum += ord(char)
        elif char.isalpha() and char.islower() and (char in consonants):
            lowercase_consonants_sum += ord(char)
    return (uppercase_vowels_sum, lowercase_consonants_sum)