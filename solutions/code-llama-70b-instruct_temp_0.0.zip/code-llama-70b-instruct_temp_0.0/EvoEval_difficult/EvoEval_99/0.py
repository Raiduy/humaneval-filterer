def closest_integer(value, base):
    decimal_value = int(value, base)
    rounded_value = round(decimal_value)
    closest_integer = convert_to_base(rounded_value, base)
    return closest_integer