def add(lst, n):
    if not lst:
        return -1
    total_sum = 0
    prime_count = 0
    for i in range(n):
        if is_prime(lst[i]):
            prime_count += 1
        if i % 2 == 1 and lst[i] % 2 == 0:
            total_sum += lst[i]
    if prime_count == 0:
        return -1
    return total_sum * prime_count