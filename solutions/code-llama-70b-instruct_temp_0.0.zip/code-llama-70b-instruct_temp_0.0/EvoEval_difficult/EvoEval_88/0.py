def sort_array(array, pivot):
    if not array:
        return []
    if len(array) == 1:
        return array
    pivot_value = array[pivot]
    left_part = [num for num in array if num < pivot_value]
    right_part = [num for num in array if num > pivot_value]
    if (array[0] + pivot_value) % 2 == 0:
        left_part.sort(reverse=True)
    else:
        left_part.sort()
    right_part.sort()
    return left_part + [pivot_value] + right_part