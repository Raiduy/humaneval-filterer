def prime_sequences(n, m):
    if n <= 0 or m <= 0:
        return []
    primes = []
    for i in range(2, n):
        if is_prime(i):
            primes.append(i)
    if len(primes) < m:
        return []
    sequences = []
    for i in range(len(primes) - m + 1):
        sequences.append(primes[i:i + m])
    return sequences