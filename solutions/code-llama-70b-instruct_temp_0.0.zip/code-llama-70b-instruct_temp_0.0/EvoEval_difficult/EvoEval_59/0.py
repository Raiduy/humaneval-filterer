def largest_prime_factor(n, m):

    def is_prime(num):
        if num <= 1:
            return False
        if num <= 3:
            return True
        if num % 2 == 0 or num % 3 == 0:
            return False
        i = 5
        while i * i <= num:
            if num % i == 0 or num % (i + 2) == 0:
                return False
            i += 6
        return True

    def prime_factors(num):
        factors = []
        for i in range(2, int(num ** 0.5) + 1):
            while num % i == 0:
                factors.append(i)
                num //= i
        if num > 1:
            factors.append(num)
        return factors
    if is_prime(m):
        return max(prime_factors(n))
    else:
        return min(prime_factors(n))