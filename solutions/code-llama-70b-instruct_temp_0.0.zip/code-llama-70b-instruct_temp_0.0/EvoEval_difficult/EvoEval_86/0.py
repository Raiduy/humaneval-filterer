def advanced_anti_shuffle(s, n):
    words = re.findall("[\\w']+|[.,!?;]", s)
    result = []
    for word in words:
        if not word.isalpha():
            result.append(word)
        else:
            sorted_word = ''.join(sorted(word))
            shifted_word = sorted_word[-n:] + sorted_word[:-n]
            result.append(shifted_word)
    return ''.join(result)