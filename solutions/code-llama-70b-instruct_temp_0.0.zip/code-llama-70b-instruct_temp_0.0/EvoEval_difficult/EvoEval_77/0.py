def iscube(a, b):
    if a < 0 or b < 0:
        return False
    if a % 2 != 0 or b % 2 != 0:
        return False
    if a % 4 != 0 or b % 4 != 0:
        return False
    if a % 8 == 0 and b % 16 == 0:
        return True
    return False