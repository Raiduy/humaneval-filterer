def multi_pairs_sum_to_zero(l, n):
    if n > len(l):
        return False
    zero_count = 0
    positive_numbers = set()
    negative_numbers = set()
    for num in l:
        if num == 0:
            zero_count += 1
        elif num > 0:
            positive_numbers.add(num)
        else:
            negative_numbers.add(num)
    if zero_count >= n:
        return True
    for positive_number in positive_numbers:
        for negative_number in negative_numbers:
            if positive_number + negative_number == 0:
                n -= 1
                if n == 0:
                    return True
    return False