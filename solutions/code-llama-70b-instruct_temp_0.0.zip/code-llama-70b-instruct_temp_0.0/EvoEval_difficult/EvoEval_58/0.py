def common(l1: list, l2: list, n: int):
    common_strings = []
    for string in l1:
        if string in l2:
            common_strings.append(string)
    common_strings.sort(key=len)
    return common_strings[-n:]