def is_multiply_prime(a, b):
    primes = []
    for i in range(2, a + 1):
        if is_prime(i):
            primes.append(i)
    for i in range(len(primes)):
        for j in range(i + 1, len(primes)):
            product = primes[i] * primes[j]
            while product <= a:
                primes.append(product)
                product *= primes[j]
    primes.sort()
    for i in range(len(primes)):
        product = 1
        for j in range(i, i + b):
            if j >= len(primes):
                return (False, [])
            product *= primes[j]
        if product == a:
            return (True, primes[i:i + b])
    return (False, [])