def complexity_increased(lst, n):
    if not lst or all((num <= 0 for num in lst)):
        return -1
    primes = [num for num in lst if is_prime(num)]
    if not primes:
        return -1
    sum_of_powers = 0
    for prime in primes:
        power = 0
        while prime > 0:
            power += (prime % 10) ** n
            prime //= 10
        sum_of_powers += power
    return sum_of_powers