def smallest_change(arr, k):
    if not arr:
        return 0
    if arr == arr[::-1]:
        return 0
    arr_sum = sum(arr)
    if arr_sum % k == 0:
        return 1
    min_change = float('inf')
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            (arr[i], arr[j]) = (arr[j], arr[i])
            if arr == arr[::-1]:
                new_arr_sum = sum(arr)
                if new_arr_sum % k == 0:
                    min_change = min(min_change, 2)
                    break
            (arr[i], arr[j]) = (arr[j], arr[i])
    return min_change