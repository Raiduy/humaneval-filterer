def decimal_to_binary(decimal, padding_length):
    if not isinstance(decimal, int) or not isinstance(padding_length, int):
        return 'Invalid Input'
    if decimal < 0 or padding_length < 0:
        return 'Invalid Input'
    binary_representation = bin(decimal)[2:]
    if len(binary_representation) > padding_length:
        return 'Padding length is too small'
    padded_binary = binary_representation.rjust(padding_length, '0')
    return f'db{padded_binary}db'