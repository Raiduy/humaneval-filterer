def circular_shift(x, shift, direction):
    if not isinstance(shift, int) or shift < 1 or direction not in ('R', 'L'):
        return 'Invalid Input'
    digits = list(str(x))
    shift = shift % len(digits)
    if direction == 'R':
        shifted_digits = digits[-shift:] + digits[:-shift]
    else:
        shifted_digits = digits[shift:] + digits[:shift]
    return ''.join(shifted_digits)