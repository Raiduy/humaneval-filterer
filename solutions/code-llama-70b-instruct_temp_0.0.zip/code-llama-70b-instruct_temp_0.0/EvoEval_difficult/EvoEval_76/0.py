def complex_power(x, n, m):
    if n == 1 or m == 1:
        return False
    if n == m:
        return x == n ** int(log(x, n))
    else:
        return False