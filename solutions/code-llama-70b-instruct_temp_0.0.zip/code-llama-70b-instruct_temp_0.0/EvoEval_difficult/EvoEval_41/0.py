def car_race_collision(n, speeds):
    collisions = 0
    for i in range(n):
        if speeds[i] > 0:
            for j in range(n - 1, i, -1):
                if speeds[j] > 0:
                    if speeds[i] <= speeds[j]:
                        collisions += 1
                        break
    return collisions