def starts_one_ends(n, x, y):
    if n > 5 or x < 0 or y < 0 or (x > 9) or (y > 9):
        return -1
    count = 0
    for i in range(10 ** (n - 1), 10 ** n):
        if str(i)[0] == str(x) or str(i)[-1] == str(y):
            count += 1
    return count