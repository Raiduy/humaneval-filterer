def total_match(lst1, lst2, k):
    if len(lst1) == 0 or len(lst2) == 0:
        return lst1 if len(lst1) == 0 else lst2
    lst1_total_chars = sum((len(s) for s in lst1))
    lst2_total_chars = sum((len(s) for s in lst2))
    if lst1_total_chars < lst2_total_chars:
        return lst1
    elif lst2_total_chars < lst1_total_chars:
        return lst2
    else:
        lst1_count = sum((1 for s in lst1 if len(s) <= k))
        lst2_count = sum((1 for s in lst2 if len(s) <= k))
        if lst1_count > lst2_count:
            return lst1
        elif lst2_count > lst1_count:
            return lst2
        else:
            return lst1