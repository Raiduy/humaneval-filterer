def advanced_fruit_distribution(s, n, m):
    (apples, oranges) = s.split(' and ')
    apples = int(apples.split(' ')[0])
    oranges = int(oranges.split(' ')[0])
    mangoes = n - apples - oranges
    if mangoes < m:
        return -1
    return mangoes