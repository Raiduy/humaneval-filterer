def advanced_encrypt(s, n):
    alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    encrypted_s = ''
    for char in s:
        if char in alphabet:
            index = alphabet.index(char)
            if n % 2 == 0:
                shifted_index = (index + n * 2) % len(alphabet)
            else:
                shifted_index = (index - n * 2) % len(alphabet)
            encrypted_s += alphabet[shifted_index]
        else:
            encrypted_s += char
    return encrypted_s