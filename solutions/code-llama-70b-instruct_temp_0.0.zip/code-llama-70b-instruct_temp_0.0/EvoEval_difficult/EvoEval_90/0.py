def next_smallest_and_largest(lst):
    if len(lst) < 3:
        return (None, None)
    smallest = lst[0]
    largest = lst[0]
    second_smallest = None
    second_largest = None
    for num in lst:
        if num < smallest:
            second_smallest = smallest
            smallest = num
        elif second_smallest is None or num < second_smallest:
            if num != smallest:
                second_smallest = num
        if num > largest:
            second_largest = largest
            largest = num
        elif second_largest is None or num > second_largest:
            if num != largest:
                second_largest = num
    return (second_smallest, second_largest)