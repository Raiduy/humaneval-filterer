def will_it_fly_advanced(q, w, r):

    def is_palindrome(lst):
        return lst == lst[::-1]

    def is_balanced(lst):
        return is_palindrome(lst) and sum(lst) <= w

    def is_uncertain(lst, r):
        return not is_palindrome(lst) and is_balanced([lst[i] for i in range(len(lst)) if i not in r])
    if is_balanced(q):
        return True
    elif is_uncertain(q, r):
        return None
    else:
        return False