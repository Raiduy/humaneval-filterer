def advanced_search(lst, f):
    freq = {}
    for num in lst:
        if num in freq:
            freq[num] += 1
        else:
            freq[num] = 1
    for num in sorted(freq, reverse=True):
        if freq[num] >= num and f % freq[num] == 0:
            return num
    return -1