def sort_even_odd(l, m):
    m_dict = {value: index for (index, value) in enumerate(m)}
    sorted_values = []
    for (index, value) in enumerate(l):
        if index % 2 == 0:
            sorted_values.append(value)
        elif value in m_dict:
            sorted_values.insert(m_dict[value], value)
        else:
            sorted_values.append(value)
    return sorted_values