def customFibFib(n, startSequence, p):
    if n < 0:
        raise ValueError('n must be a non-negative integer.')
    if n < len(startSequence):
        return startSequence[n]
    if len(startSequence) != 3:
        raise ValueError('startSequence must have exactly 3 elements.')
    if p < 0:
        raise ValueError('p must be a positive integer.')
    (a, b, c) = startSequence
    for _ in range(n - 2):
        (a, b, c) = (b, c, a + b + c)
        if c > p:
            return 'Limit Exceeded'
    return c