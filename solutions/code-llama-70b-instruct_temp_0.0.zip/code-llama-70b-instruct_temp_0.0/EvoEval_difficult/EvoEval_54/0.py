def same_chars_in_order(s0, s1):
    s0_index = 0
    for char in s1:
        if char == s0[s0_index]:
            s0_index += 1
            if s0_index == len(s0):
                return True
    return False