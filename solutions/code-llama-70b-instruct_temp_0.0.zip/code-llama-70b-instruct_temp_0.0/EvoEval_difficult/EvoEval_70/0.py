def strange_sort_list(lst, lst2):
    merged_list = list(set(lst + lst2))
    odd_numbers = [num for num in merged_list if num % 2 != 0]
    even_numbers = [num for num in merged_list if num % 2 == 0]
    odd_numbers.sort()
    even_numbers.sort()
    sorted_odd_numbers = [odd_numbers[i] if i % 2 == 0 else odd_numbers[i - 1] for i in range(len(odd_numbers))]
    sorted_even_numbers = [even_numbers[i] if i % 2 == 0 else even_numbers[i - 1] for i in range(len(even_numbers))]
    sorted_list = sorted_odd_numbers + sorted_even_numbers
    return sorted_list