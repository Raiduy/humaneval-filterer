def enhanced_solve(N, M):
    N_bin = bin(N)[2:]
    M_bin = bin(M)[2:]
    N_sum = sum((int(digit) for digit in N_bin))
    M_sum = sum((int(digit) for digit in M_bin))
    total_sum = N_sum + M_sum
    primes_count = 0
    for i in range(N, M + 1):
        if isprime(i):
            primes_count += 1
    result = total_sum * primes_count
    result_bin = bin(result)[2:]
    return result_bin