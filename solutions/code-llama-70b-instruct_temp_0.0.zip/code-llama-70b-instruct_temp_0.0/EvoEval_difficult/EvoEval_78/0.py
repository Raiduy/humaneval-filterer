def hex_key_primes(num):
    decimal_num = int(num, 16)
    hex_prime_digits = ['2', '3', '5', '7', 'B', 'D']
    count_prime_digits = 0
    sum_prime_digits = 0
    for digit in num:
        if digit in hex_prime_digits:
            count_prime_digits += 1
            sum_prime_digits += int(digit, 16)
    if count_prime_digits >= len(num) - count_prime_digits:
        return (count_prime_digits, 'Dominant', sum_prime_digits)
    else:
        return (count_prime_digits, 'Non-dominant', sum_prime_digits)