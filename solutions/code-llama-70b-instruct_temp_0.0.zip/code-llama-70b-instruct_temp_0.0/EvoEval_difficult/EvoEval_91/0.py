def detect_boredom(S, substrings):
    S = re.sub('\\([^)]*\\)', '', S)
    S = re.sub('\\[[^]]*\\]', '', S)
    S = re.sub('\\{[^}]*\\}', '', S)
    S = re.sub('".*?"', '', S)
    sentences = re.split('[.!?]\\s*', S)
    boredoms = 0
    for sentence in sentences:
        for substring in substrings:
            if sentence.startswith(substring):
                boredoms += 1
                break
    return boredoms