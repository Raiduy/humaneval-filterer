def prime_length(string, opt):
    if opt == 'letters':
        unique_letters = set(string)
        num_unique_letters = len(unique_letters)
        if num_unique_letters > 1 and all((num_unique_letters % i != 0 for i in range(2, int(num_unique_letters ** 0.5) + 1))):
            return True
        else:
            return False
    elif opt == 'words':
        words = [word for word in string.split() if word]
        num_words = len(words)
        if num_words > 1 and all((num_words % i != 0 for i in range(2, int(num_words ** 0.5) + 1))):
            return True
        else:
            return False
    else:
        length = len(string)
        if length > 1 and all((length % i != 0 for i in range(2, int(length ** 0.5) + 1))):
            return True
        else:
            return False