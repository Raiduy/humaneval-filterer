def triples_sum_to_target(l: list, k: int):
    l.sort()
    total_triplets = 0
    for i in range(len(l) - 2):
        left = i + 1
        right = len(l) - 1
        while left < right:
            triplet_sum = l[i] + l[left] + l[right]
            if triplet_sum == k:
                total_triplets += 1
                left += 1
                right -= 1
            elif triplet_sum < k:
                left += 1
            else:
                right -= 1
    if total_triplets == 0:
        return -1
    return total_triplets