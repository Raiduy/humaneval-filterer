def get_row(lst, x, y):
    result = []
    for (row_index, row) in enumerate(lst):
        for (col_index, col) in enumerate(row):
            for (depth_index, depth) in enumerate(col):
                if depth == x and depth_index != y:
                    result.append((row_index, col_index, depth_index))
    result.sort(key=lambda tup: (tup[0], -tup[1], tup[2]))
    return result