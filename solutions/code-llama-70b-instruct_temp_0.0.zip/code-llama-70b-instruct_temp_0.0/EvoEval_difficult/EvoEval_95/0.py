def check_dict_case_content(dict):
    if not dict:
        return False
    keys_are_strings = all((isinstance(key, str) for key in dict.keys()))
    values_are_strings = all((isinstance(value, str) for value in dict.values()))
    if not keys_are_strings or not values_are_strings:
        return False
    keys_are_lowercase = all((key.islower() for key in dict.keys()))
    keys_are_uppercase = all((key.isupper() for key in dict.keys()))
    values_are_capitalized = all((value.istitle() for value in dict.values()))
    if not keys_are_lowercase and (not keys_are_uppercase):
        return False
    if not values_are_capitalized:
        return False
    keys_are_equal_length = len(set((len(key) for key in dict.keys()))) == 1
    if not keys_are_equal_length:
        return False
    return True