
def starts_one_ends(n):
    if n == 1:
        return 2
    else:
        return (10 ** (n - 1) - 1) * 2