
def next_largest(lst):
    if len(lst) < 2:
        return None
    sorted_lst = sorted(lst, reverse=True)
    if sorted_lst[0] == sorted_lst[1]:
        return None
    return sorted_lst[1]