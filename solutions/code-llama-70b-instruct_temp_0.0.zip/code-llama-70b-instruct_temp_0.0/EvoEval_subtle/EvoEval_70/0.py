
def strange_sort_list(lst):
    if not lst:
        return []
    sorted_list = sorted(lst, reverse=True)
    result = []
    i = 0
    j = len(sorted_list) - 1
    while i <= j:
        result.append(sorted_list[i])
        if i != j:
            result.append(sorted_list[j])
        i += 1
        j -= 1
    return result