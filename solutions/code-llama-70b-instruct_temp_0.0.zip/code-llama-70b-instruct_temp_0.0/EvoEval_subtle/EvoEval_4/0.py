
from typing import List


def median_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Median Absolute Deviation
    around the median of this dataset.
    Median Absolute Deviation is the median absolute difference between each
    element and a centerpoint (median in this case):
    MAD = median | x - x_median |
    >>> median_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    numbers_sorted = sorted(numbers)
    n = len(numbers)
    if n % 2 == 0:
        median = (numbers_sorted[n // 2 - 1] + numbers_sorted[n // 2]) / 2
    else:
        median = numbers_sorted[n // 2]
    deviations = [abs(x - median) for x in numbers]
    deviations_sorted = sorted(deviations)
    n_deviations = len(deviations)
    if n_deviations % 2 == 0:
        median_absolute_deviation = (deviations_sorted[n_deviations // 2 - 1] + deviations_sorted[n_deviations // 2]) / 2
    else:
        median_absolute_deviation = deviations_sorted[n_deviations // 2]
    return median_absolute_deviation