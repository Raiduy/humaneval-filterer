
def solve(N):
    N_str = str(N)
    sum_of_digits = sum((int(digit) for digit in N_str))
    hex_str = hex(sum_of_digits)[2:]
    return hex_str