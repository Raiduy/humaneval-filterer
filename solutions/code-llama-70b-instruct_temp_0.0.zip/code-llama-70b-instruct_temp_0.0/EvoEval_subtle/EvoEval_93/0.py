

def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 3 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'THST'
    >>> encode('This is a message')
    'tHLS LS D MHSSDGH'
    """
    vowel_map = {'a': 'd', 'e': 'h', 'i': 'l', 'o': 'p', 'u': 'w', 'A': 'D', 'E': 'H', 'I': 'L', 'O': 'P', 'U': 'W'}
    encoded_message = ''
    for char in message:
        if char in vowel_map:
            encoded_message += vowel_map[char]
        else:
            encoded_message += char
    encoded_message = encoded_message.swapcase()
    return encoded_message