
def anti_shuffle(s):
    words = s.split()
    result = []
    for word in words:
        if word.isalpha():
            sorted_word = ''.join(sorted(word, key=lambda x: ord(x), reverse=True))
            result.append(sorted_word)
        else:
            result.append(word)
    return ' '.join(result)