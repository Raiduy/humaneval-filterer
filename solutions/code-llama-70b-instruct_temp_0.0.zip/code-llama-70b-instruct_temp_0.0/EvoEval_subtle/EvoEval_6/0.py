
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses. Additionally, return the list in descending order.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [3, 3, 2, 1]
    """
    paren_groups = paren_string.split()
    max_nesting_levels = []
    for group in paren_groups:
        current_nesting_level = 0
        max_nesting_level = 0
        for char in group:
            if char == '(':
                current_nesting_level += 1
            elif char == ')':
                current_nesting_level -= 1
            if current_nesting_level > max_nesting_level:
                max_nesting_level = current_nesting_level
        max_nesting_levels.append(max_nesting_level)
    max_nesting_levels.sort(reverse=True)
    return max_nesting_levels