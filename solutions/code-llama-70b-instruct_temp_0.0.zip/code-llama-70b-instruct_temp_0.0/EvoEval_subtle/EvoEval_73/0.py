
def smallest_change(arr):
    n = len(arr)
    mid = n // 2
    changes = 0
    if n % 2 == 1:
        mid = n // 2 + 1
    for i in range(mid):
        if arr[i] != arr[n - i - 1]:
            changes += 1
    return changes