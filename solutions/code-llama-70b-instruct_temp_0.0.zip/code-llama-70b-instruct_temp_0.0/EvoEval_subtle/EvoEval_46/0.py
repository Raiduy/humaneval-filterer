
def fib4(n):
    if n < 0:
        raise ValueError('Input must be a non-negative integer.')
    if n == 0:
        return '0'
    if n == 1:
        return '0'
    if n == 2:
        return '2'
    if n == 3:
        return '0'
    sequence = ['0', '0', '2', '0']
    for i in range(4, n + 1):
        next_term = int(sequence[i - 1]) + int(sequence[i - 2]) + int(sequence[i - 3]) + int(sequence[i - 4])
        sequence.append(str(next_term))
    return sequence[n]