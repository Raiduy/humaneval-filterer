
def numerical_letter_grade(grades):
    gpa_to_letter_grade = {(4.0, 5.0): 'A+', (3.7, 4.0): 'A', (3.3, 3.7): 'A-', (3.0, 3.3): 'B+', (2.7, 3.0): 'B', (2.3, 2.7): 'B-', (2.0, 2.3): 'C+', (1.7, 2.0): 'C', (1.3, 1.7): 'C-', (1.0, 1.3): 'D+', (0.7, 1.0): 'D', (0.0, 0.7): 'D-', (0.0, 0.0): 'E'}
    letter_grades = []
    for gpa in grades:
        for (gpa_range, letter_grade) in gpa_to_letter_grade.items():
            if gpa_range[0] <= gpa < gpa_range[1]:
                letter_grades.append(letter_grade)
                break
    letter_grades.sort()
    return letter_grades