
def fib(n: int):
    """Return (n+1)-th Fibonacci number.
    >>> fib(10)
    89
    >>> fib(1)
    1
    >>> fib(8)
    34
    """
    if n < 0:
        raise ValueError('n must be non-negative')
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)