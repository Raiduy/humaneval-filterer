
def is_bored(S):
    sentences = S.split('.')
    boredoms = 0
    for sentence in sentences:
        words = sentence.split()
        if words[0] == 'I' and words[-1] == 'boredom':
            boredoms += 1
    return boredoms