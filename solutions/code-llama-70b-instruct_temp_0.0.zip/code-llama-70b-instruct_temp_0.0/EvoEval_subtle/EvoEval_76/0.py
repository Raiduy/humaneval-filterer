
def is_simple_power(x, n):
    if n == 1:
        return (False, None)
    if n == 0 and x != 1:
        return (False, None)
    if n == 0 and x == 1:
        return (True, 0)
    if x == 1:
        return (True, 0)
    if x == 0:
        return (False, None)
    power = 1
    while True:
        if n ** power == x:
            return (True, power)
        if n ** power > x:
            return (False, None)
        power += 1