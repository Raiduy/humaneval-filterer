
def iscube(a):
    if a < 0:
        return False
    if a == 0:
        return True
    for i in range(1, int(a ** (1 / 3)) + 1):
        if i ** 3 == a:
            return True
    return False