

def monotonic(l: list):
    if len(l) == 0:
        return False
    if all((x <= y for (x, y) in zip(l, l[1:]))):
        return True
    if all((x >= y for (x, y) in zip(l, l[1:]))):
        return True
    return False