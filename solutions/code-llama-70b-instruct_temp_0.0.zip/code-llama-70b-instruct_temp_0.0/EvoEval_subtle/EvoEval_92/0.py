
def any_int(x, y, z):
    if isinstance(x, int) and isinstance(y, int) and isinstance(z, int):
        if x == abs(y) + abs(z):
            return True
        elif y == abs(x) + abs(z):
            return True
        elif z == abs(x) + abs(y):
            return True
        else:
            return False
    else:
        return False