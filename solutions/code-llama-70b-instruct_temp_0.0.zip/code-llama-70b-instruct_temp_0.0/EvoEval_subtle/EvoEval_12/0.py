
from typing import List, Optional


def shortest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    shortest_string = min(strings, key=len)
    return shortest_string