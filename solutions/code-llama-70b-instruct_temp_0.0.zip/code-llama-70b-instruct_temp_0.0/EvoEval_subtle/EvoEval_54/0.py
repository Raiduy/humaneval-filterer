
def same_chars(s0: str, s1: str):
    if len(s0) != len(s1):
        return False
    s0_chars = sorted(s0)
    s1_chars = sorted(s1)
    return s0_chars == s1_chars