
def count_up_to(n):
    primes = []
    for i in range(n, 0, -1):
        if is_prime(i):
            primes.append(i)
    return primes