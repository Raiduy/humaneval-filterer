
def prime_fib(n):
    if n < 1:
        return None
    (a, b) = (0, 1)
    for _ in range(n ** 2):
        (a, b) = (b, a + b)
        if is_prime(b):
            n -= 1
            if n == 0:
                return b
    return None