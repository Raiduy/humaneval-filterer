from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string. 
    Return the list in ascending alphabetical order 
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['(()())', '(())', '()']
    """
    paren_string = paren_string.replace(' ', '')
    current_group = ''
    groups = []
    current_nesting_level = 0
    open_parentheses = 0
    for char in paren_string:
        if char == '(':
            open_parentheses += 1
            if current_nesting_level == 0:
                current_group = ''
            current_group += char
            current_nesting_level += 1
        elif char == ')':
            open_parentheses -= 1
            if open_parentheses < 0:
                raise ValueError('Unbalanced parentheses')
            current_group += char
            current_nesting_level -= 1
            if current_nesting_level == 0:
                groups.append(current_group)
        else:
            raise ValueError('Invalid character')
    if open_parentheses != 0:
        raise ValueError('Unbalanced parentheses')
    groups.sort()
    return groups