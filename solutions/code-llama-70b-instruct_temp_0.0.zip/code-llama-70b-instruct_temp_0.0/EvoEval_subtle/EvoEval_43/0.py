
def pairs_sum_to_one(l):
    if len(l) < 2:
        return False
    sum_to_one = set()
    for num in l:
        if 1 - num in sum_to_one:
            return True
        sum_to_one.add(num)
    return False