

def derivative(xs: list):
    """
    xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Return derivative of this polynomial in the same form, but in descending order of the power of x.
    """
    if not xs:
        return []
    derivative_list = []
    for i in range(1, len(xs)):
        derivative_list.append(xs[i] * i)
    derivative_list.reverse()
    return derivative_list