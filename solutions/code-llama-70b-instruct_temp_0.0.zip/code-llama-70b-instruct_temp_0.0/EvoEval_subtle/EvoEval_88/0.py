
def sort_array(array):
    if not array:
        return []
    if (array[0] + array[-1]) % 2 == 0:
        sorted_array = sorted(array, reverse=True)
    else:
        sorted_array = sorted(array)
    unique_array = []
    for num in sorted_array:
        if num not in unique_array:
            unique_array.append(num)
    return unique_array