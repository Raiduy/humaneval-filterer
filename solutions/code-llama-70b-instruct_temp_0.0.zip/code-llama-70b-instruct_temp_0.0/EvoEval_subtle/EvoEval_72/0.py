
def will_it_fly(q, w):
    if q[0] == q[-1]:
        if sum(q) % 2 == 0:
            if sum(q) <= w:
                return True
    return False