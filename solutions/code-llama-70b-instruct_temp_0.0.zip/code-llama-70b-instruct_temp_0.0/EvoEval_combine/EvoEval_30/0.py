
from typing import List

def parse_music_simplify(x: str, music_string: str) -> List[bool]:
    """ 
    Input to this function is a string, x, which is a fraction in the format of <numerator>/<denominator> where both numerator 
    and denominator are positive whole numbers and a string, music_string, representing musical notes in a special ASCII format.
    
    Your task is to parse the music_string and return a list of booleans corresponding to whether the beats of each note simplifies 
    the fraction x. 

    If x * beats evaluates to a whole number, add True to the list, otherwise add False. 

    Here is the legend for music_string:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    Example:
    parse_music_simplify("1/4", 'o o| .| o| o| .| .| .| .| o o')
    [True, False, False, False, False, False, False, False, False, True, True]
    """
    (numerator, denominator) = x.split('/')
    numerator = int(numerator)
    denominator = int(denominator)
    results = []
    for note in music_string.split():
        if note == 'o':
            beats = 4
        elif note == 'o|':
            beats = 2
        elif note == '.|':
            beats = 1
        else:
            raise ValueError('Invalid note: ' + note)
        if numerator * beats % denominator == 0:
            results.append(True)
        else:
            results.append(False)
    return results