
def modp_count(arr, n, p):
    mod = pow(2, n, p)
    count = 0
    for num in arr:
        if num < 0:
            digit_sum = -1
        else:
            digit_sum = 0
        while num != 0:
            digit_sum += num % 10
            num //= 10
        if digit_sum > mod:
            count += 1
    return count