
def find_max_triple_sum(x, y, n):
    largest_even_integer = -1
    for i in range(x, y + 1):
        if i % 2 == 0:
            largest_even_integer = i
    a = []
    for i in range(1, n + 1):
        a.append(i * i - i + 1)
    largest_triple_sum = -1
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            for k in range(j + 1, len(a)):
                if (a[i] + a[j] + a[k]) % 3 == 0 and a[i] + a[j] + a[k] > largest_triple_sum:
                    largest_triple_sum = a[i] + a[j] + a[k]
    if largest_even_integer != -1 and largest_triple_sum != -1:
        return largest_even_integer + largest_triple_sum
    else:
        return -1