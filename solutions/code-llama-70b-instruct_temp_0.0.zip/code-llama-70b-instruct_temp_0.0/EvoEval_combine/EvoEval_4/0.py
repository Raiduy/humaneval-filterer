
def largest_prime_divisor_digit_sum(lst):

    def is_prime(n):
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i * i <= n:
            if n % i == 0 or n % (i + 2) == 0:
                return False
            i += 6
        return True

    def sum_of_digits(n):
        return sum((int(digit) for digit in str(n)))

    def largest_prime_divisor(n):
        if is_prime(n):
            return n
        for i in range(n - 1, 1, -1):
            if n % i == 0 and is_prime(i):
                return i
        return 0
    largest_prime_divisors = [largest_prime_divisor(n) for n in lst]
    largest_prime_divisor_sum = sum_of_digits(max(largest_prime_divisors))
    return largest_prime_divisor_sum