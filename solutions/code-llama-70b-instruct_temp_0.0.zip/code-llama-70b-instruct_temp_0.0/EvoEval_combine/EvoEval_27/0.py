
def list_prime_exchange(lst1, lst2, x, y):
    if all((is_prime(num) for num in lst1)):
        return x
    if all((is_prime(num) for num in lst2)):
        return x
    if all((is_prime(num) for num in lst1 + lst2)):
        return x
    for i in range(len(lst1)):
        for j in range(len(lst2)):
            (lst1[i], lst2[j]) = (lst2[j], lst1[i])
            if all((is_prime(num) for num in lst1 + lst2)):
                return x
            (lst1[i], lst2[j]) = (lst2[j], lst1[i])
    return y