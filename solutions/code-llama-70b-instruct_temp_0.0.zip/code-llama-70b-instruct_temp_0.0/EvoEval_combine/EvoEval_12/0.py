
def grade_students(student_info, n):

    def count_consonants(s):
        consonants = 'bcdfghjklmnpqrstvwxyz'
        return sum((1 for char in s.lower() if char in consonants))

    def gpa_to_grade(gpa):
        if gpa >= 4.0:
            return 'A+'
        elif gpa >= 3.7:
            return 'A'
        elif gpa >= 3.3:
            return 'A-'
        elif gpa >= 3.0:
            return 'B+'
        elif gpa >= 2.7:
            return 'B'
        elif gpa >= 2.3:
            return 'B-'
        elif gpa >= 2.0:
            return 'C+'
        elif gpa >= 1.7:
            return 'C'
        elif gpa >= 1.3:
            return 'C-'
        elif gpa >= 1.0:
            return 'D+'
        elif gpa >= 0.7:
            return 'D'
        elif gpa >= 0.0:
            return 'D-'
        else:
            return 'E'
    final_grades = []
    for student in student_info:
        name = student['name']
        gpa = student['GPA']
        num_consonants = count_consonants(name)
        if num_consonants == n:
            grade = gpa_to_grade(gpa)
            if grade != 'A+':
                if grade == 'A':
                    grade = 'A+'
                elif grade == 'A-':
                    grade = 'A'
                elif grade == 'B+':
                    grade = 'A-'
                elif grade == 'B':
                    grade = 'B+'
                elif grade == 'B-':
                    grade = 'B'
                elif grade == 'C+':
                    grade = 'B-'
                elif grade == 'C':
                    grade = 'C+'
                elif grade == 'C-':
                    grade = 'C'
                elif grade == 'D+':
                    grade = 'C-'
                elif grade == 'D':
                    grade = 'D+'
                elif grade == 'D-':
                    grade = 'D'
                elif grade == 'E':
                    grade = 'D-'
        else:
            grade = gpa_to_grade(gpa)
        final_grades.append({'name': name, 'grade': grade})
    return final_grades