
def sorted_fib4_sequence(n: int):
    """
    Computes the sorted Fib4 sequence up to the n-th element.

    Args:
        n (int): The number of elements in the sequence.

    Returns:
        list: The sorted Fib4 sequence up to the n-th element.
    """
    sequence = [0, 0, 2, 0]
    for i in range(4, n):
        sequence.append(sequence[i - 1] + sequence[i - 2] + sequence[i - 3] + sequence[i - 4])
    if sequence[0] + sequence[-1] % 2 == 0:
        sequence.sort(reverse=True)
    else:
        sequence.sort()
    return sequence