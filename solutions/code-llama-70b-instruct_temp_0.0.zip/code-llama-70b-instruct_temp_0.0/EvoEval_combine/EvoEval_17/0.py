
def fibfib_search(n: int, lst: list) -> int:

    def fibfib(n: int) -> int:
        if n <= 2:
            return n
        else:
            return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)
    fibfib_n = fibfib(n)
    freq_dict = {}
    for num in lst:
        if num > 0:
            if num in freq_dict:
                freq_dict[num] += 1
            else:
                freq_dict[num] = 1
    max_val = -1
    for (num, freq) in freq_dict.items():
        if freq >= fibfib_n and num > max_val:
            max_val = num
    return max_val