from typing import List, Tuple, Optional

def account_operations(operations: List[int]) -> Tuple[Optional[int], Optional[int], bool]:
    """ 
    You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. 
    Deposit are positive numberss and withdrawal are negative numbers

    Your task is to:
    - Detect if at any point the balance of account falls below zero, and at that point return True. 
    Otherwise, return False.
    - Find the largest valid withdrawal and smallest valid deposit operation. If balance falls below zero then the current operation and all later operations are invalid.
    If there is no withdrawal or deposit 
    operation, return them as None.

    The function should return a tuple (a, b, c), where 'a' is the largest withdrawal operation, 
    'b' is the smallest deposit operation, and 'c' is a boolean that checks if the balance ever 
    falls below zero.

    Examples: 
    account_operations([1, 2, 3]) == (None, 1, False)
    account_operations([1, 2, -4, 5]) == (None, 1, True)
    account_operations([1, 2, -3, 2, -3, 5]) == (-3, 1, True)
    account_operations([]) == (None, None, False)
    account_operations([0]) == (None, None, False)
    """
    balance = 0
    largest_withdrawal = None
    smallest_deposit = None
    balance_fell_below_zero = False
    for operation in operations:
        balance += operation
        if balance < 0:
            balance_fell_below_zero = True
            break
        if operation < 0:
            if largest_withdrawal is None or operation < largest_withdrawal:
                largest_withdrawal = operation
        elif smallest_deposit is None or operation < smallest_deposit:
            smallest_deposit = operation
    return (largest_withdrawal, smallest_deposit, balance_fell_below_zero)