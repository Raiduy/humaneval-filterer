
def prime_avg_range(n, m):
    if n > m:
        return -1
    primes = [num for num in range(n, m + 1) if is_prime(num)]
    if not primes:
        return -1
    avg = sum(primes) / len(primes)
    rounded_avg = round(avg)
    binary_avg = bin(rounded_avg)
    return binary_avg