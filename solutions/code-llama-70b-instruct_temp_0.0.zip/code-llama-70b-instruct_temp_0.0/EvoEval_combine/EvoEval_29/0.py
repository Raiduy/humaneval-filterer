def largest_prime_factor_or_value(n, x, y):
    """A program which should return the largest prime factor of n if n is not a prime number, should return the value of x if n is a prime number and y if n is 1. 

    Examples:
    for largest_prime_factor_or_value(13195, 34, 12) == 29
    for largest_prime_factor_or_value(7, 8, 5) == 8
    for largest_prime_factor_or_value(1, 8, 5) == 5
    """
    if n == 1:
        return y
    elif is_prime(n):
        return x
    else:
        return largest_prime_factor(n)