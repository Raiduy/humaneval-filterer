
def len_base_conversion(x: int, base: int) -> int:
    """ 
    Convert the numerical base of input number x to base and 
    return the length of string representation after the conversion. 
    base numbers are less than 10.
    
    >>> len_base_conversion(8, 3)
    2
    >>> len_base_conversion(8, 2)
    4
    >>> len_base_conversion(7, 2)
    3
    """
    if base < 2 or base > 9:
        raise ValueError('Base must be an integer between 2 and 9.')
    if x == 0:
        return 1
    digits = []
    while x:
        digits.append(str(x % base))
        x //= base
    return len(digits)