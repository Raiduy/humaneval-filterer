def get_music_notes(word: str, music_string: str):
    beats = []
    if len(word) < 3:
        return beats
    if len(music_string) == 0:
        return beats
    vowel_index = -1
    for i in range(len(word) - 1, 0, -1):
        if word[i].lower() in ['a', 'e', 'i', 'o', 'u']:
            if word[i - 1] not in ['a', 'e', 'i', 'o', 'u'] and word[i + 1] not in ['a', 'e', 'i', 'o', 'u']:
                vowel_index = i
                break
    if vowel_index != -1:
        music_index = 0
        for i in range(len(music_string)):
            if music_string[i] == word[vowel_index]:
                beats.append(music_index + 1)
                break
            if music_string[i] == 'o':
                music_index += 4
            elif music_string[i] == 'o|':
                music_index += 2
            elif music_string[i] == '.|':
                music_index += 1
    return beats