def filter_exchange(arr, lst1):

    def sum_of_digits(n):
        return sum((int(digit) for digit in str(abs(n))))
    filtered_arr = [num for num in arr if sum_of_digits(num) > 0]
    if not filtered_arr:
        return 'NO'
    odd_count = 0
    even_count = 0
    for num in lst1:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    if odd_count > len(filtered_arr):
        return 'NO'
    return 'YES'