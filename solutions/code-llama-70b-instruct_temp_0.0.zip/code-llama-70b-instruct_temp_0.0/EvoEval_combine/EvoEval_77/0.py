
def mixed_solution(arr):
    if not arr:
        return 0
    sum_of_odd_elements = 0
    for i in range(len(arr)):
        if i % 2 == 1 and arr[i] % 2 == 1:
            sum_of_odd_elements += arr[i]
    return sum_of_odd_elements