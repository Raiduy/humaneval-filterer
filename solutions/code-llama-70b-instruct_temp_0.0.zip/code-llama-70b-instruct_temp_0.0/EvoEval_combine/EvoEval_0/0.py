def compare_happiness(a, b):
    a_is_happy = len(a) >= 3 and len(set((a[i:i + 3] for i in range(len(a) - 2)))) == len(a) - 2
    b_is_happy = len(b) >= 3 and len(set((b[i:i + 3] for i in range(len(b) - 2)))) == len(b) - 2
    if not a_is_happy and (not b_is_happy):
        return None
    if a_is_happy and (not b_is_happy):
        return a
    if not a_is_happy and b_is_happy:
        return b
    a_num = float(a.replace(',', '.'))
    b_num = float(b.replace(',', '.'))
    if a_num > b_num:
        return a
    elif b_num > a_num:
        return b
    else:
        return None