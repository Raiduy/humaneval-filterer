
import math

def minSubArraySumEvenOdd(nums):
    min_sum = float('inf')
    min_sum_even_count = 0
    min_sum_odd_count = 0
    for i in range(len(nums)):
        for j in range(i, len(nums)):
            sub_array_sum = sum(nums[i:j + 1])
            if sub_array_sum < min_sum:
                min_sum = sub_array_sum
                min_sum_even_count = 0
                min_sum_odd_count = 0
                for num in nums[i:j + 1]:
                    if num % 2 == 0:
                        min_sum_even_count += 1
                    else:
                        min_sum_odd_count += 1
    return (min_sum_even_count, min_sum_odd_count)