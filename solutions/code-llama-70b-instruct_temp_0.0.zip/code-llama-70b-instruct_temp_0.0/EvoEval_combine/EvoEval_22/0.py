def binary_planet_distance(planet1, planet2):
    planet_order = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune']
    if planet1 not in planet_order or planet2 not in planet_order:
        return ''
    planet1_index = planet_order.index(planet1)
    planet2_index = planet_order.index(planet2)
    if planet1_index > planet2_index:
        (planet1_index, planet2_index) = (planet2_index, planet1_index)
    planets_between = planet_order[planet1_index + 1:planet2_index]
    binary_number = bin(len(planets_between))[2:]
    binary_string = 'bd' + binary_number + 'bd'
    return binary_string