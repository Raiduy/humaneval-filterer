
def even_odd_zero_sum(l, n):
    even_palindromes = 0
    odd_palindromes = 0
    for i in range(1, n + 1):
        if is_palindrome(i):
            if i % 2 == 0:
                even_palindromes += 1
            else:
                odd_palindromes += 1
    even_sum_exists = False
    odd_sum_exists = False
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            if l[i] + l[j] == even_palindromes:
                even_sum_exists = True
            if l[i] + l[j] == odd_palindromes:
                odd_sum_exists = True
    return (even_sum_exists, odd_sum_exists)