
from typing import List

def base_change_prefixes(x: int, base: int) -> List[str]:
    """ For a given number x and a base less than 10, first change the numerical base of x to the given base.
    Then return a list of all prefixes from the shortest to the longest of the new base representation of x.
    
    >>> base_change_prefixes(8, 3)
    ['2', '22']
    >>> base_change_prefixes(8, 2)
    ['1', '10', '100', '1000']
    >>> base_change_prefixes(7, 2)
    ['1', '11', '111']
    """
    if base < 2 or base > 9:
        raise ValueError('Base must be between 2 and 9.')
    digits = []
    while x > 0:
        digits.append(str(x % base))
        x //= base
    digits.reverse()
    x_base = ''.join(digits)
    prefixes = []
    for i in range(1, len(x_base) + 1):
        prefixes.append(x_base[:i])
    return prefixes