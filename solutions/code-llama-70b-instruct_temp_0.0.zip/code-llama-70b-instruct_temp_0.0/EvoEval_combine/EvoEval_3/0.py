
from typing import List

def sort_parentheses(lst: List[str]) -> str:
    numbers = []
    for s in lst:
        for c in s:
            if c.isdigit():
                numbers.append(int(c))
    numbers.sort()
    stack = []
    for n in numbers:
        s = f'({n})'
        for c in s:
            if c == '(':
                stack.append(c)
            elif c == ')':
                if len(stack) == 0 or stack[-1] != '(':
                    return 'No'
                stack.pop()
    return 'Yes'