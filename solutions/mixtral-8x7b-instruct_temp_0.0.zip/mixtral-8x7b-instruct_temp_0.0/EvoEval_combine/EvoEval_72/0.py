
from typing import List
from math import factorial

def special_close_factorials(numbers: List[int], threshold: int) -> bool:
    """
    Check if in given list of numbers, are any two special factorials closer to each other than
    given threshold. The special factorial (Brazilian factorial) is defined as
    n! * (n-1)! * (n-2)! * ... * 1!  where n > 0.

    Args:
    numbers (List[int]): List of integers
    threshold (int): Threshold distance

    Returns:
    bool: True if any two special factorials are closer than the threshold, False otherwise

    Examples:
    >>> special_close_factorials([2, 3], 10)
    False
    >>> special_close_factorials([1, 2, 3, 4], 100)
    True
    """
    special_fact = [factorial(n) * prod for (n, prod) in enumerate(factorials, start=1)]
    factorials = [factorial(n) for n in range(max(special_fact) + 1)]
    for i in range(len(special_fact) - 1):
        for j in range(i + 1, len(special_fact)):
            if abs(special_fact[i] - special_fact[j]) < threshold:
                return True
    return False