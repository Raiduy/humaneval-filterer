
from typing import List

def prime_prefixed_strings(strings: List[str], prefix: str) -> List[str]:
    """
    Return a list of strings from the input list which start with the given prefix and their lengths are prime numbers.
    """
    prime_strings = [s for s in strings if s.startswith(prefix) and is_prime(len(s))]
    return prime_strings