
def grade_with_same_chars(grades, s0, s1):
    """
    Returns a list of grades for the students that have the same characters in their name 
    and the course title, or an empty list if no student passes.
    """
    same_chars = set(s0) & set(s1)
    eligible_grades = [g for (g, student) in zip(grades, s0) if not student or same_chars.issubset(set(student))]
    grade_mapping = {4.0: 'A+', 3.7: 'A', 3.3: 'A-', 3.0: 'B+', 2.7: 'B', 2.3: 'B-', 2.0: 'C+', 1.7: 'C', 1.3: 'C-', 1.0: 'D+', 0.7: 'D', 0.0: 'D-', -1.0: 'E'}
    return [grade_mapping[max(grade - 0.1, 0.0)] for grade in eligible_grades]