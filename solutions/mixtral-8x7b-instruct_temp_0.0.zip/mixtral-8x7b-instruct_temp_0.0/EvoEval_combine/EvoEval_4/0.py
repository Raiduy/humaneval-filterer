
def largest_prime_divisor_digit_sum(lst):
    max_sum = 0
    for num in lst:
        if num == 0:
            max_sum = 0
        elif is_prime(num):
            max_sum = max(max_sum, sum((int(digit) for digit in str(num))))
        else:
            for i in range(num // 2, 1, -1):
                if num % i == 0 and is_prime(i):
                    max_sum = max(max_sum, sum((int(digit) for digit in str(i))))
                    break
    return max_sum