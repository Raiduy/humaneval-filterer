def next_smallest_sorted_binary(lst):
    """
    You are given a list of non-negative integers.
    First, sort the input list based on the number of ones in their binary representation in ascending order. 
    For the same number of ones, sort based on original value. 
    
    Then, return the 2nd smallest element from the sorted list. 
    Return None if there is no such element.

    :param lst: list of non-negative integers
    :return: the 2nd smallest element from the sorted list or None if there is no such element
    """
    if not lst:
        return None

    def count_set_bits(num):
        return bin(num).count('1')
    sorted_lst = sorted(lst, key=lambda x: (count_set_bits(x), x))
    if len(sorted_lst) < 2:
        return None
    return sorted_lst[1]