def largest_prime_factor_or_value(n, x, y):
    """A program which returns the largest prime factor of n if n is not a prime number,
    returns the value of x if n is a prime number and y if n is 1.

    Args:
        n (int): The number to find the largest prime factor or value of.
        x (int): The value to return if n is a prime number.
        y (int): The value to return if n is 1.

    Returns:
        int: The largest prime factor of n or the value of x or y.

    Examples:
        for largest_prime_factor_or_value(13195, 34, 12) == 29
        for largest_prime_factor_or_value(7, 8, 5) == 8
        for largest_prime_factor_or_value(1, 8, 5) == 5
    """
    if n <= 1:
        return y
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            if i != 2:
                return n // i
            else:
                return x
    return x