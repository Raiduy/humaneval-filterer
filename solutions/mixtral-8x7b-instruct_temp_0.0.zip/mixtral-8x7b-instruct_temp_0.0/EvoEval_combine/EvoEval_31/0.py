
from typing import List

def special_prime_factorial(n: int) -> int:
    """
    Calculates the special factorial of a given positive integer 'n'.
    The special factorial is the product of factorials of all the prime factors of 'n',
    each factor calculated the number of times it appears in the factorization.

    :param n: a positive integer
    :return: the special factorial of 'n'
    """

    def factorial(x: int) -> int:
        """
        Calculates the factorial of a given positive integer 'x'.

        :param x: a positive integer
        :return: the factorial of 'x'
        """
        if x == 0:
            return 1
        else:
            return x * factorial(x - 1)

    def prime_factors(x: int) -> List[int]:
        """
        Returns the list of prime factors of a given positive integer 'x'.

        :param x: a positive integer
        :return: the list of prime factors of 'x'
        """
        i = 2
        factors = []
        while i * i <= x:
            if x % i:
                i += 1