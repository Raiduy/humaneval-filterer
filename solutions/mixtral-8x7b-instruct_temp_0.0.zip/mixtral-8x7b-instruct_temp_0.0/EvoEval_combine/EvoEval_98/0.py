
def check_dict_bracketing(dictionary):
    """
    Given a dictionary where all keys and values are strings, return True if all keys and values 
    follow these two rules, else return False. The function should return False if the given
    dictionary is empty. 

    Rule 1: All keys are strings in lower case or all keys are strings in upper case.
    Rule 2: All values are strings of "(" and ")" and have correct bracketing - every opening 
    bracket has a corresponding closing bracket.

    Examples:
    check_dict_bracketing({"a":"()", "b":"(())"}) should return True.
    check_dict_bracketing({"a":"()", "A":"()"}) should return False.
    check_dict_bracketing({"a":"(", "b":"()"}) should return False.
    check_dict_bracketing({"Name":"()", "Age":"(())"}) should return False.
    check_dict_bracketing({"STATE":"()", "ZIP":"(())"}) should return True.
    """
    if not dictionary:
        return False
    key_case = (dictionary.keys() & {'az'}).issuperset(dictionary.keys()) or (dictionary.keys() & {'AZ'}).issuperset(dictionary.keys())
    if not key_case:
        return False
    for value in dictionary.values():
        open_brackets = 0
        for char in value:
            if char == '(':
                open_brackets += 1
            elif char == ')' and open_brackets == 0:
                return False
            elif char == ')' and open_brackets > 0:
                open_brackets -= 1
            else:
                continue
        if open_brackets != 0:
            return False
    return True