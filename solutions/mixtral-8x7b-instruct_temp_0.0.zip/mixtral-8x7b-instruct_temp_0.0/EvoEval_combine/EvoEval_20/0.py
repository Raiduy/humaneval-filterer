
def grade_and_case(s, grades):
    """
    Function to output student names in reverse case and assign letter grades
    based on their GPAs.

    Parameters:
    s (list): List of student names in string format
    grades (list): List of GPAs corresponding to the students

    Returns:</s>ef{</s>ef{
    list: List of tuples containing reversed case student name and their
    corresponding letter grade
    }
    """
    grade_table = {4.0: 'A+', 3.7: 'A', 3.3: 'A-', 3.0: 'B+', 2.7: 'B', 2.3: 'B-', 2.0: 'C+', 1.7: 'C', 1.3: 'C-', 1.0: 'D+', 0.7: 'D', 0.0: 'D-', 0.0: 'E'}
    result = []
    for (name, gpa) in zip(s, grades):
        reversed_name = ''.join([char.upper() if char.islower() else char.lower() for char in name])
        letter_grade = next((grade for (g, grade) in grade_table.items() if gpa > g), 'E')
        result.append((reversed_name, letter_grade))
    return result