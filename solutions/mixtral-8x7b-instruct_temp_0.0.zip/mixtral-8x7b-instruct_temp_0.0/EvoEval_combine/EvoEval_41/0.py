
def shifted_upper_count(s, shift):
    """
    Given a string s and an integer shift, perform a circular shift on the ASCII values of the characters in string 
    by the shift value. Return the count of uppercase vowels in even indices after the shift.

    If shift > length of string, reverse the string before counting.

    For example:
    shifted_upper_count('aBCdEf', 1) returns 0
    shifted_upper_count('abcdefg', 2) returns 0
    shifted_upper_count('dBBE', 3) returns 1
    """
    shifted_s = [chr((ord(c) - ord('a') + shift) % 26 + ord('a')) if c.islower() else chr((ord(c) - ord('A') + shift) % 26 + ord('A')) for c in s]
    if shift > len(s):
        shifted_s = shifted_s[::-1]
    count = 0
    for i in range(0, len(shifted_s), 2):
        if shifted_s[i].isupper() and shifted_s[i] in 'AEIOU':
            count += 1
    return count