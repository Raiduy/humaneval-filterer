
def class_grades_with_flip(name_grade_list):
    """
    Function to convert student names and GPAs into proper case and letter grades respectively.

    Parameters:
    name_grade_list (list): List of tuples containing student names and their GPAs.

    Returns:
    list: List of tuples containing student names in proper case and their corresponding letter grades.
    """

    def proper_case(string):
        return string[0].upper() + string[1:].lower()

    def grade_determiner(gpa):
        if gpa >= 4.0:
            return 'A+'
        elif gpa > 3.7:
            return 'A'
        elif gpa > 3.3:
            return 'A-'
        elif gpa > 3.0:
            return 'B+'
        elif gpa > 2.7:
            return 'B'
        elif gpa > 2.3:
            return 'B-'
        elif gpa > 2.0:
            return 'C+'
        elif gpa > 1.7:
            return 'C'
        elif gpa > 1.3:
            return 'C-'
        elif gpa > 1.0:
            return 'D+'
        elif gpa > 0.7:
            return 'D'
        elif gpa > 0.0:
            return 'D-'
        else:
            return 'E'
    output_list = [(proper_case(name), grade_determiner(grade)) for (name, grade) in name_grade_list]
    return output_list