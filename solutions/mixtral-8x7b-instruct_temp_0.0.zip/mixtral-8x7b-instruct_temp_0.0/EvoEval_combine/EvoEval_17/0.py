
def fibfib_search(n, lst):
    """
    Compute the n-th element of the FibFib sequence and find the greatest integer in the list that
    has a frequency greater than or equal to the n-th FibFib element. If no such value exists,
    return -1.
    """
    n_fibfib = fibfib(n)
    freq_dict = {}
    for num in lst:
        if num in freq_dict:
            freq_dict[num] += 1
        else:
            freq_dict[num] = 1
    max_freq_num = -1
    for (num, freq) in freq_dict.items():
        if freq >= n_fibfib:
            max_freq_num = max(max_freq_num, num)
    return max_freq_num