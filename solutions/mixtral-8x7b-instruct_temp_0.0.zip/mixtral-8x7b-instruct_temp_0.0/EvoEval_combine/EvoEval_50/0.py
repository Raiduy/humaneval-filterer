
def get_closest_upper_vowel(word):
    """
    Find the closest uppercase vowel between two consonants from the right side of the word.
    Return empty string if no such vowel is found. The vowel must stand at an even index.
    """
    vowels = set('AEIOU')