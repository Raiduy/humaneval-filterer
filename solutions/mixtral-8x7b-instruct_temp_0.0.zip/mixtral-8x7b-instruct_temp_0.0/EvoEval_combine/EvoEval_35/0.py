def check_dict_happiness(dictionary):
    """
    Given a dictionary, where all keys are strings, return True if the following conditions are met:
    1. All keys are either all lower case or all upper case.
    2. Each key is a happy string. A string is happy if its length is at least 3 and every 3 consecutive letters are distinct.
    The function should return False if the given dictionary is empty or if any of the conditions are not met.
    """
    if not dictionary:
        return False
    key_case = dictionary.keys().__next__().islower()
    if key_case != all([k.islower() for k in dictionary.keys()]) and key_case != all([k.isupper() for k in dictionary.keys()]):
        return False
    for key in dictionary.keys():
        if len(key) < 3 or any([key[i] == key[i + 1] == key[i + 2] for i in range(len(key) - 2)]):
            return False
    return True