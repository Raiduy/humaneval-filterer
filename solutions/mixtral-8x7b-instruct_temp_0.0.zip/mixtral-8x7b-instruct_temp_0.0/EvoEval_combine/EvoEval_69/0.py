def sorted_happy_strings(lst):
    """
    Function to accept a list of strings, delete strings that are not happy or have odd lengths,
    and return the sorted resulted list.
    
    A string is considered happy if its length is at least 3 and every 3 consecutive letters are distinct.
    The list may contain duplicates and is always a list of strings.

    :param lst: list of strings
    :return: sorted list of happy strings
    """

    def is_happy(word):
        """Check if a word is happy."""
        if len(word) < 3 or len(word) % 2 != 0:
            return False
        chars = set(word[:3])
        for i in range(3, len(word), 3):
            if word[i] in chars:
                return False
            chars.add(word[i])
        return True
    return sorted(filter(is_happy, lst), key=lambda x: (len(x), x))