
def common_pairs_with_zero_sum(l1: list, l2: list) -> bool:
    """
    common_pairs_with_zero_sum takes two lists of integers as an input.
    It first identifies the common elements between the two lists.
    Then, it checks if there are two distinct elements in the common elements that sum to zero.

    Returns True if such pair exists and False otherwise.
    """
    common_elements = [value for value in set(l1) if value in set(l2)]
    for element in common_elements:
        if -element in common_elements and common_elements.count(element) == 1 and (common_elements.count(-element) == 1):
            return True
    return False