
def sort_prime_even(l, x, y):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted. If the sorted element at an even index
    is prime, replace it with x. Otherwise, replace it with y.

    Examples:
    sort_prime_even([2, 3, 4, 5, 6], 10, 20) == [10, 3, 20, 5, 20]
    sort_prime_even([7, 1, 9, 2, 8], 15, 30) == [15, 1, 30, 2, 30]
    """
    even_indices = [i for (i, _) in enumerate(l) if i % 2 == 0]
    sorted_even_values = sorted([l[i] for i in even_indices])
    prime_even_values = [val for val in sorted_even_values if is_prime(val)]
    x_even_values = [x if val in prime_even_values else val for val in sorted_even_values]
    for (i, val) in zip(even_indices, x_even_values):
        l[i] = val
    return l