
def evaluate_common_expressions(operators, operand_lists):
    common_operands = set.intersection(*[set(operand_list) for operand_list in operand_lists])
    if not common_operands:
        return None
    common_operands = sorted(common_operands)
    expression = ' * '.join([str(elem) for elem in common_operands])
    for operator in operators:
        for i in range(1, len(common_operands)):
            expression = expression.replace(f'{common_operands[i - 1]}{common_operands[i]}', f'{common_operands[i - 1]} {operator} {common_operands[i]}')
    result = eval(expression)
    return result