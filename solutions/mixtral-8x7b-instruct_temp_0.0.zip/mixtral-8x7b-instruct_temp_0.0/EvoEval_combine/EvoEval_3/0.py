
from typing import List

def sort_parentheses(lst: List[str]) -> str:
    sorted_lst = sorted(lst, key=lambda x: (x[1:].isdigit() and int(x), x))
    stack = []
    for s in sorted_lst:
        if s[1:].isdigit():
            stack.append(s)
        elif s[0] == ')':
            if not stack or stack.pop()[-1] != '(':
                return 'No'
        else:
            continue
    return 'Yes' if not stack else 'No'