
from typing import List

def filter_sort_strings(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain a given substring and have an even length. 
    Return the resulted list in ascending order by the length of each word. 
    If two words have the same length, sort the list alphabetically.
    The list may contain duplicate strings.
    
    Parameters:
    strings (List[str]): The input list of strings.
    substring (str): The substring to filter the strings by.
    
    Returns:
    List[str]: The filtered and sorted list of strings.
    
    Examples:
    >>> filter_sort_strings([], 'a')
    []
    >>> filter_sort_strings(['abc', 'bacd', 'cd', 'array'], 'a')
    ['bacd']
    >>> filter_sort_strings(['abc', 'bacd', 'cd', 'array', 'play'], 'a')
    ['bacd', 'play']
    """
    filtered_strings = [s for s in strings if substring in s and len(s) % 2 == 0]
    return sorted(filtered_strings, key=len) if not filtered_strings else sorted(filtered_strings, key=lambda x: (len(x), x))