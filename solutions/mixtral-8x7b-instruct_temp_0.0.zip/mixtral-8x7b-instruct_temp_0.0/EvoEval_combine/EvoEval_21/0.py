
from typing import List

def base_change_prefixes(x: int, base: int) -> List[str]:
    """
    For a given number x and a base less than 10, first change the numerical base of x to the given base.
    Then return a list of all prefixes from the shortest to the longest of the new base representation of x.

    :param x: The integer number to convert to a new base.
    :param base: The base to convert the number to.
    :return: A list of all prefixes from the shortest to the longest of the new base representation of x.
    """
    if x == 0:
        return ['0']
    result = []
    while x > 0:
        (x, remainder) = divmod(x, base)
        result.append(str(remainder))
    result.reverse()
    return result