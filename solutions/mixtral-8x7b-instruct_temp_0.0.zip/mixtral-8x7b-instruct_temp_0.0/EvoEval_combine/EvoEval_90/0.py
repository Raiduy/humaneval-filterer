
def vowels_in_dict_keys(dictionary):
    """
    Given a dictionary, check if all the keys are strings in either lower case or upper case
    and returns a dictionary where keys are the same keys from the input dictionary and the values are the count of vowels in each key.
    If the keys are not all in lower case nor all in upper case, return an empty dictionary.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a vowel, but only when it is at the end of the given word.
    The function should return an empty dictionary if the input dictionary itself is empty.
    
    Parameters:
    dictionary (dict): The input dictionary.
    
    Returns:
    dict: A dictionary where keys are the same keys from the input dictionary and the values are the count of vowels in each key.
           An empty dictionary if the input dictionary is empty or the keys are not all in lower case nor all in upper case.
    
    Examples:
    vowels_in_dict_keys({"a":"apple", "b":"banana"}) should return {"a":1, "b":0}.
    vowels_in_dict_keys({"a":"apple", "A":"banana", "B":"banana"}) should return {}.
    vowels_in_dict_keys({"a":"apple", 8:"banana", "a":"apple"}) should return {}.
    vowels_in_dict_keys({"Name":"John", "Age":"36", "City":"Houston"}) should return {}.
    vowels_in_dict_keys({"STATE":"NC", "ZIP":"12345" }) should return {"STATE": 2, "ZIP": 1}.
    """
    if not dictionary:
        return dictionary
    vowels = set('aeiouy')
    is_consistent_case = all((isinstance(k, str) and (k.islower() or k.isupper()) for k in dictionary.keys()))
    if not is_consistent_case:
        return {}
    result = {k: sum((char in vowels for char in k)) for k in dictionary.keys()}
    return result