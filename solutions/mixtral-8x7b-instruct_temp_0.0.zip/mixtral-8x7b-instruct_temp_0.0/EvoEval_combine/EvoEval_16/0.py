def get_music_notes(word: str, music_string: str):
    vowels = set('aeiouAEIOU')
    beats = []
    i = len(word) - 1
    while i >= 0 and (word[i] not in vowels or i == len(word) - 1):
        i -= 1
    if i < 0:
        return beats
    for (j, note) in enumerate(music_string):
        if j > i:
            break
        if note == 'o':
            beats.append(4)
        elif note == 'o|':
            beats.append(2)
        elif note == '.|':
            beats.append(1)
    return beats