
from typing import List

def sort_and_check(numbers: List[float], threshold: float) -> List[float]:
    for i in range(len(numbers) - 1):
        if abs(numbers[i] - numbers[i + 1]) < threshold:
            return sorted(numbers, reverse=sum(numbers) % 2 == 0)
    return numbers