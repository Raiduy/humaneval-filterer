
def modp_largest_divisor(n: int, p: int) -> Optional[int]:
    """Return the largest number smaller than 'p' which divides (2^n modulo p) evenly. 
    If no such number exists, return None.
    
    >>> modp_largest_divisor(3, 5)
    3
    >>> modp_largest_divisor(1101, 101)
    2
    >>> modp_largest_divisor(0, 101) is None
    True
    >>> modp_largest_divisor(3, 11)
    8
    
    """
    if n == 0 or p == 1:
        return None
    power = 2 ** n % p
    (divisor, _) = divmod(power, p - 1)
    if divisor == 1:
        return None
    else:
        return p - divisor