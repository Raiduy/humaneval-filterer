
def happy_case_string(s):
    """
    Function to check if a string is happy and reverse the case for each letter or reverse the string.

    :param s: str, the given string
    :return: str, the resulted string
    """
    if len(s) < 3 or any((s[i] == s[i + 1] == s[i + 2] for i in range(len(s) - 2))):
        return s[::-1]
    return ''.join((chr(ord(c) ^ 32) if c.isalpha() else c for c in s))