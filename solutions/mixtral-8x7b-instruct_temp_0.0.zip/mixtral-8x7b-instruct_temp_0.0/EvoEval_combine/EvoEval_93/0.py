
def prime_vowel(string):
    """Return the closest vowel between two consonants from the right side of the string if the string length is a prime number.
    Otherwise, return an empty string. Vowels in the beginning and ending don't count.

    Parameters:
    string (str): The input string containing English letters only.

    Returns:
    str: The closest vowel between two consonants from the right side of the string if the string length is a prime number.
    An empty string otherwise.
    """

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    vowels = set('aeiou')
    consonants = set('bcdfghjklmnpqrstvwxyz')
    if not is_prime(len(string)):
        return ''
    for i in range(len(string) - 1, -1, -1):
        if string[i] in vowels:
            if i + 1 < len(string) and string[i + 1] in consonants:
                return string[i]
        elif string[i] in consonants:
            if i - 1 >= 0 and string[i - 1] in vowels:
                return string[i - 1]
    return ''