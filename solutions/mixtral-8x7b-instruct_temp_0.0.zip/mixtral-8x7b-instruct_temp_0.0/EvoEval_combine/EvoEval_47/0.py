def count_odd_upper(s, lst):
    """
    Given a string 's' and a list of strings 'lst', where 's' consists of only uppercase and lowercase English letters and each string in 'lst' consists of digits only, return a list the same length as 'lst'.

    The function first counts the number of uppercase vowels in even indices in 's' (denoted by 'n'),
    and then counts the number of odd digits in each string in 'lst' (denoted by 'm').

    Each element i of the output list is:
    "In the string, the number of uppercase vowels in even indices is 'n', and the number of odd digits is 'm'."
    """
    n = sum((1 for c in s[::2] if c.isupper() and c in 'AEIOU'))
    output = []
    for item in lst:
        m = sum((int(digit) for digit in item if int(digit) % 2 != 0))
        output.append(f'In the string, the number of uppercase vowels in even indices is {n}, and the number of odd digits is {m}.')
    return output