def unique_paths(m: int, n: int):
    """
    A robot is located at the top-left corner of a m x n grid (marked 'Start' in the diagram below).
    The robot can only move either down or right at any point in time. 
    The robot is trying to reach the bottom-right corner of the grid (marked 'Finish' in the diagram below).
    How many possible unique paths are there from start to finish?

    :param m: the number of rows in the grid
    :param n: the number of columns in the grid
    :return: the number of possible unique paths from start to finish
    """