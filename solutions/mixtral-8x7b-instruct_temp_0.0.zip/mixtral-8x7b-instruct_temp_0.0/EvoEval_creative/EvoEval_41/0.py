def spider_web_jump(arr):
    """
    Calculate the minimum energy required for a spider to reach the safe cell in a 2D array.

    Parameters:
    arr (list of list of int): A 2D array representing a spider's web.

    Returns:
    int: The minimum energy required for the spider to reach the safe cell.

    """
    if not arr or not arr[0]:
        return 0
    (n_rows, n_cols) = (len(arr), len(arr[0]))
    distances = [[float('inf')] * n_cols for _ in range(n_rows)]
    distances[0][0] = 0
    heap = [(0, 0, 0)]
    while heap:
        (curr_distance, curr_row, curr_col) = heappop(heap)
        if (curr_row, curr_col) == (n_rows - 1, n_cols - 1):
            return curr_distance
        if curr_distance > distances[curr_row][curr_col]:
            continue
        for (dr, dc) in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            (new_row, new_col) = (curr_row + dr, curr_col + dc)
            if 0 <= new_row < n_rows and 0 <= new_col < n_cols:
                new_distance = curr_distance + arr[new_row][new_col]
                if new_distance < distances[new_row][new_col]:
                    distances[new_row][new_col] = new_distance
                    heappush(heap, (new_distance, new_row, new_col))
    return distances[-1][-1]