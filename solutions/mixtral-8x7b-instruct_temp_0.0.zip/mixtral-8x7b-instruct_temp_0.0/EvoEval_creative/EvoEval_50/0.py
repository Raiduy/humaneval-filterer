def text_to_morse(text):
    """
    Converts a string of text to Morse code.

    Parameters:
    text (str): The string to convert.

    Returns:
    str: The Morse code equivalent of the input text.
    """
    morse_dict = {'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--', 'Z': '--..', ' ': '  '}
    morse_code = []
    words = text.split(' ')
    for word in words:
        letter_codes = [morse_dict[letter.upper()] for letter in word if letter.upper() in morse_dict]
        morse_code.extend(letter_codes)
        morse_code.append(' ')
    return ''.join(morse_code).strip()