def calculate_integral_coefficients(xs):
    """
    xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Return indefinite integral of this polynomial in the same form,
    with the constant of integration set to zero,
    i.e. you should generate the coefficients for the polynomial
    representing the integral of the input polynomial.
    So for example, if the input is [3, 2, 1], then the output would
    represent the polynomial 3*x + x^2 + x^3/3
    """
    n = len(xs)
    integral_coefficients = [0] * (n + 1)
    for i in range(n):
        if xs[i] != 0:
            coefficient = xs[i] / (i + 1)
            integral_coefficients[i + 1] = coefficient
    return integral_coefficients