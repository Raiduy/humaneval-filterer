from typing import List, Union

def calculate_shipping_cost(items: List[Union[str, float]], location: str) -> float:
    base_cost_per_item = 5.0
    location_multipliers = {'Local': 1, 'National': 1.5, 'International': 2.5}
    additional_charge = 10.0
    string_item_multiplier = 1.5
    total_weight = sum((item if isinstance(item, float) else 1 for item in items))
    num_of_string_items = sum((isinstance(item, str) for item in items))
    if num_of_string_items > 0:
        total_weight *= string_item_multiplier
    total_cost_before_location = base_cost_per_item * total_weight + additional_charge * (total_weight > 5)
    total_cost = total_cost_before_location * location_multipliers.get(location, 1)
    return round(total_cost, 2)