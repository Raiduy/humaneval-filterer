def generate_pattern(n: int):
    """
    Given an integer 'n', return a list of strings where each string represents a pattern. 
    The pattern is composed of the numbers from 1 to n in ascending order, then descending back to 1, 
    with each number separated by a comma. If n is 0 or negative, return an empty list.

    :param n: The integer to generate the pattern for
    :return: A list of strings representing the pattern
    """
    if n <= 0:
        return []
    patterns = []
    for i in range(1, n + 1):
        patterns.append(str(i))
        for j in range(i + 1, n + 1):
            patterns.append(f"{','.join((str(k) for k in range(1, i + 1)))},{j}")
        for j in range(i - 1, 0, -1):
            patterns.append(f"{','.join((str(k) for k in range(1, j + 1)))},{j}")
    return patterns