def adventure_game(map, instructions):
    (start_row, start_column) = (0, 0)
    for row in range(len(map)):
        if 'S' in map[row]:
            (start_row, start_column) = (row, map[row].index('S'))
            map[row][start_column] = '.'
            break
    path = [(start_row, start_column)]
    directions = {'up': (-1, 0), 'down': (1, 0), 'left': (0, -1), 'right': (0, 1)}
    for instruction in instructions:
        (row_move, column_move) = directions[instruction]
        (next_row, next_column) = (start_row + row_move, start_column + column_move)
        if 0 <= next_row < len(map) and 0 <= next_column < len(map[0]) and (map[next_row][next_column] != 'X'):
            (start_row, start_column) = (next_row, next_column)
            path.append((start_row, start_column))
            if map[start_row][start_column] == 'E':
                break
            map[start_row][start_column] = '.'
    return path