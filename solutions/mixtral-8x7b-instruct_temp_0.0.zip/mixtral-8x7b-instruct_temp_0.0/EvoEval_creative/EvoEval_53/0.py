def magical_transformation(s):
    """
    Magically transform a string by replacing vowels and consonants
    and swapping '?' and '!' in strings with odd and even indices.
    
    Parameters:
    s (str): The string to transform

    Returns:
    str: The transformed string
    """
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    result = ''
    for (i, char) in enumerate(s):
        if char.lower() in vowels:
            index = vowels.index(char.lower())
            next_vowel = vowels[(index + 1) % len(vowels)].upper() if char.isupper() else vowels[(index + 1) % len(vowels)]
            result += next_vowel
        elif char.lower() in consonants:
            index = consonants.index(char.lower())
            next_consonant = consonants[(index + 1) % len(consonants)].upper() if char.isupper() else consonants[(index + 1) % len(consonants)]
            result += next_consonant
        else:
            result += char
        if char in ('?', '!'):
            if i % 2 == 0:
                result = result[:-1] + '!' if char == '?' else result[:-1] + '?'
    return result