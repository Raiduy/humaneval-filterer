def tree_traversal(tree, path=[]):
    """
    Function to return all possible paths from root to leaves in a binary tree.

    Parameters:
    tree (dict): A nested dictionary representing the binary tree.
    path (list, optional): A list of node values along the current path. Defaults to [].

    Returns:
    list of lists: A list of all possible paths from root to leaves.
    """
    if not tree:
        return []
    path = path + [tree[0]]
    if not tree[0]:
        return [path]
    paths = []
    for branch in (1, 2):
        if branch in tree and tree[branch]:
            newpaths = tree_traversal(tree[branch], path.copy())
            for newpath in newpaths:
                paths.append(newpath)
    return sorted(paths, key=len)