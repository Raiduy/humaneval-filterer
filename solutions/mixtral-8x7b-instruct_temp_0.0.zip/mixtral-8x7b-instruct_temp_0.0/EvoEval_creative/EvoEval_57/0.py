def magical_cafe(menu, magic_spell):
    """
    Transform dish names in a menu using a magic spell.

    Parameters:
    menu (dict): A dictionary containing dishes as keys and their prices as values.
    magic_spell (str): A string containing the magic spell.

    Returns:
    dict: A new dictionary containing the transformed menu.
    """
    transformed_menu = {}
    for (dish, price) in menu.items():
        transformed_dish = ''
        for letter in dish:
            transformed_dish += magic_spell[ord(letter) % len(magic_spell)]
        transformed_menu[transformed_dish] = price
    return transformed_menu