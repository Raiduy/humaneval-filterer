def magicTrick(cards, magicNumber):
    """
    Given a list of cards and a magic number, determine if it's possible to select two cards
    such that their product equals the magic number. Return the indices of the two cards
    if it's possible, and "No magic today" if it's not.

    Parameters:
    cards (list): A list of integers representing the card numbers.
    magicNumber (int): A positive integer representing the magic number.

    Returns:
    tuple or str: A tuple of two indices if possible, or "No magic today" if not.
    """
    card_set = set(cards)
    for card in card_set:
        if magicNumber / card in card_set:
            return sorted((card_set.index(card), card_set.index(magicNumber / card)))
    return 'No magic today'