def word_spiral(arr):
    """Create a function which takes in a 2D array of characters and returns a 
    string which represents the words in the array read in a clockwise spiral starting
    from the top left corner. If the array is empty, return an empty string. 

    Args:
    arr (List[List[str]]): A 2D array of characters.

    Returns:
    str: A string containing the spiral word.

    Examples:
    assert word_spiral([['h','i','!'],['b','y','e']]) == 'hi!eyb'
    assert word_spiral([['l','o','v','e'],['i','s','i','n'],['t','h','e','a'],['i','r', '!','!!']]) == 'lovena!!!ritisieh'
    assert word_spiral([]) == ''
    """
    if not arr:
        return ''
    result = ''
    (r, c, d) = (0, 0, 0)
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    while True:
        result += arr[r][c]
        arr[r][c] = ''
        (nr, nc) = (r + directions[d][0], c + directions[d][1])
        if not (0 <= nr < len(arr) and 0 <= nc < len(arr[0])) or arr[nr][nc] == '':
            d = (d + 1) % 4
            if not (0 <= nr < len(arr) and 0 <= nc < len(arr[0])) or arr[nr][nc] == '':
                break
        (r, c) = (nr, nc)
    return result