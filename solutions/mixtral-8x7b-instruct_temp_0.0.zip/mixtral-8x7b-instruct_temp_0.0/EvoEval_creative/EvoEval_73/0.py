def treasure_hunt(grid, bag_capacity):
    import math