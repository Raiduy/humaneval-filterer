def alien_language_translator(english_word: str):
    """
    Translates an English word into the alien language.

    :param english_word: The English word to translate.
    :return: The alien language equivalent of the given English word.
    """
    alien_language = {'a': '+', 'b': '-', 'c': '*', 'd': '/', 'e': '%', 'f': '@', 'g': '!', 'h': '#', 'i': '$', 'j': '^', 'k': '&', 'l': '(', 'm': ')', 'n': '=', 'o': '?', 'p': ':', 'q': ';', 'r': '`', 's': '~', 't': '>', 'u': '<', 'v': '{', 'w': '}', 'x': '[', 'y': ']', 'z': '|'}
    return ''.join((alien_language.get(char.lower()) for char in english_word))