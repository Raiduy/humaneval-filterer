def asciiArt(n, s):
    """
    Function to create a 2D ASCII art with n copies of each character in the string s in each row and column.
    The ASCII art is framed by the '*' character in a "U" shape.

    Parameters:
    n (int): The number of copies of each character in the string s.
    s (str): The string containing alphanumeric characters.

    Returns:
    str: The ASCII art as a string.
    """
    length = n * len(s) + 2 * (n + 1)
    ascii_art = '*' * length + '\n'