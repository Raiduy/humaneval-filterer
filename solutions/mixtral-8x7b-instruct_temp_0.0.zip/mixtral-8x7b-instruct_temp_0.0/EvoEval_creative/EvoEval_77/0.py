def magical_sequence(sequence, k):
    """
    Given a sequence of positive integers and a positive integer k,
    return a list sorted in decreasing order of the total points each number in the sequence can achieve.

    Each number in the sequence is associated with a certain number of points,
    which is equivalent to the number of times the number can be divided by k until it reaches 1.

    :param sequence: A list of positive integers
    :param k: A positive integer
    :return: A list of integers sorted in decreasing order of points
    """
    points = [calculate_points(num, k) for num in sequence]
    sorted_points = sorted(points, reverse=True)
    return sorted_points