def string_transform(s):
    """
    Function to transform a string by applying the following rules:
    - Replace every vowel with the next vowel in the sequence
    - Replace every consonant with the next consonant in the alphabet
    - Keep punctuation, spaces, and digits unchanged
    Preserve the original case.

    Args:
        s (str): Input string

    Returns:
        str: Transformed string
    """
    result = ''
    vowel_map = {'a': 'e', 'e': 'i', 'i': 'o', 'o': 'u', 'u': 'a'}
    for char in s:
        if char.isalpha() and char.isupper():
            result += chr((ord(char) - 65 + 1) % 26 + 65)
        elif char.isalpha() and char.islower():
            if char in vowel_map:
                result += vowel_map[char]
            else:
                result += chr((ord(char) - 97 + 1) % 26 + 97)
        else:
            result += char
    return result