def magical_multiply(s1, s2):
    """
    This function takes two strings s1 and s2 representing positive integers,
    and returns their product according to the mystical laws of Pyth.

    In the mystical land of Pyth, numbers behave quite differently. Here, when two numbers are multiplied,
    the result is given by the sum of all possible unique combinations of their digits.

    Parameters:
    s1 (str): A string representing a positive integer.
    s2 (str): A string representing a positive integer.

    Returns:
    int: The product of s1 and s2 according to the laws of Pyth.

    Examples:
    >>> magical_multiply('24', '13')
    20
    >>> magical_multiply('56', '79')
    54
    """
    digits1 = [int(digit) for digit in s1]
    digits2 = [int(digit) for digit in s2]
    unique_sums = set()
    for i in range(len(digits1)):
        for j in range(len(digits2)):
            sum_of_digits = digits1[i] + digits2[j]
            unique_sums.add(sum_of_digits)
    unique_sums = sorted(list(unique_sums))
    result = sum(unique_sums)
    return result