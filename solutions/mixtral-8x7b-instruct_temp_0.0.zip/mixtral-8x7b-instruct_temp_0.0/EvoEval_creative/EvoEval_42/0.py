def find_legendary_item(player_input):
    """
    Determines if the player has acquired a legendary item (rarity 5) in the game and returns the rarity of
    the second most valuable item that the player has acquired if a legendary item has been acquired.

    Parameters:
    player_input (list): List representing the items acquired by a player in a single game.

    Returns:
    tuple: A tuple containing a boolean indicating if a legendary item has been acquired and the rarity of
           the second most valuable item if a legendary item has been acquired, otherwise -1.
    """
    if 5 in player_input:
        legendary_index = player_input.index(5)
        player_input.pop(legendary_index)
        if len(player_input) == 0:
            return (True, -1)
        else:
            return (True, max(player_input))
    else:
        return (False, None)