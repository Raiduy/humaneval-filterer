
from typing import List

def find_rarest_element(elems: List[str]) -> str:
    """ Find the rarest element in a list of strings. If there are multiple rarest elements, return the one that appears first. 
    If the list is empty, return None.
    """
    if not elems:
        return None
    counter = {}
    for elem in elems:
        if elem not in counter:
            counter[elem] = 0
        counter[elem] += 1
    min_count = min(counter.values())
    for (elem, count) in counter.items():
        if count == min_count:
            return elem