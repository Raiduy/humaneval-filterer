def alien_encoding(string, list_of_alphabets):
    """
    Replace each character in the input string with the corresponding character in the list of alphabets.
    If the list of alphabets is shorter than the string, loop back to the beginning of the list.
    If the string is empty, return an empty string. If the list is empty, return the original string.
    
    Parameters:
    string (str): The string to be encoded.
    list_of_alphabets (List[str]): The list of alphabets to use for encoding.

    Returns:
    str: The encoded string.
    """
    if not string:
        return ''
    if not list_of_alphabets:
        return string
    encoded_string = ''
    for char in string:
        encoded_string += list_of_alphabets[ord(char) % len(list_of_alphabets)]
    return encoded_string