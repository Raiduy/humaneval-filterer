from typing import List, Tuple

def find_path(maze: List[List[int]], start: Tuple[int], end: Tuple[int]) -> List[Tuple[int]]:
    """Returns the shortest path from start to end in a maze represented by a 2D array.

    The maze is a 2D array where 0s represent walls and 1s represent open paths. The start and end points 
    are tuples representing coordinates in the 2D array. The function should return a list of points 
    representing the shortest path from start to end. If no path is possible, return an empty list.

    Parameters:
    maze (List[List[int]]): A 2D array representing the maze.
    start (Tuple[int]): The starting point in the maze, as a tuple of (x, y) coordinates.
    end (Tuple[int]): The ending point in the maze, as a tuple of (x, y) coordinates.

    Returns:
    List[Tuple[int]]: A list of points representing the shortest path from start to end.
    """

    def in_bounds(point):
        (x, y) = point
        return 0 <= x < len(maze) and 0 <= y < len(maze[0])

    def neighbors(point):
        (x, y) = point
        results = [(x + dx, y + dy) for (dx, dy) in [(-1, 0), (1, 0), (0, -1), (0, 1)]]
        results = filter(in_bounds, results)
        results = filter(lambda point: maze[point[0]][point[1]] == 1, results)
        return results
    frontier = [start]
    came_from = {start: None}
    cost_so_far = {start: 0}
    while frontier:
        current = min(frontier, key=lambda point: cost_so_far[point])
        if current == end:
            break
        frontier.remove(current)
        for next_point in neighbors(current):
            new_cost = cost_so_far[current] + 1
            if next_point not in cost_so_far or new_cost < cost_so_far[next_point]:
                cost_so_far[next_point] = new_cost
                priority_queue.put((new_cost, next_point))
                came_from[next_point] = current
                frontier.add(next_point)
    if end not in came_from:
        return []
    path = [end]
    while path[-1] != start:
        path.append(came_from[path[-1]])
    path.reverse()
    return path