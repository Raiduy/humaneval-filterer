def find_star_map(lst, star):
    """
    Given a 2D data (nested list) representing a star map, find the coordinates of a given star.
    
    :param lst: a nested list of integers representing a star map
    :param star: an integer, the star to be found
    :return: a list of tuples, each containing a row and column index of the star
    """
    result = []