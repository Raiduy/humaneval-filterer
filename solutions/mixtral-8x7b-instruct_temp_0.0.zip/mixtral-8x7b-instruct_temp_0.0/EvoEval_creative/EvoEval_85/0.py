def princess_rescue(coord, grid):
    """
    A princess is trapped in a 2D grid filled with monsters. You are a brave warrior tasked with saving the princess.
    Your starting point is at the top-left corner of the grid and you need to reach the princess who is at a certain coordinate in the grid.
    However, there are monsters in some parts of the grid. You can move either to the right or down.
    You need to find out the minimum number of moves to reach the princess without encountering a monster. 
    If it's impossible to reach the princess without encountering a monster, return -1.
    
    The grid is represented as a 2D list. Each element in the list is either 0 or 1. 
    0 represents an open space where you can move, and 1 represents a monster. 
    The princess's coordinate is represented as a tuple (row, column).
    
    Parameters:
    coord (tuple): The princess's coordinate as a tuple (row, column).
    grid (list of list): A 2D list representing the grid.

    Returns:
    int: The minimum number of moves to reach the princess or -1 if it's impossible.
    """
    (row, col) = coord
    (num_rows, num_cols) = (len(grid), len(grid[0]))
    dp = [[-1 for _ in range(num_cols)] for _ in range(num_rows)]
    dp[0][0] = 0
    for i in range(num_rows):
        for j in range(num_cols):
            if grid[i][j] == 1:
                dp[i][j] = float('inf')
            elif i == 0 and j == 0:
                pass
            elif i == 0:
                dp[i][j] = dp[i][j - 1] + 1
            elif j == 0:
                dp[i][j] = dp[i - 1][j] + 1
            else:
                dp[i][j] = min(dp[i - 1][j], dp[i][j - 1]) + 1
    return dp[row - 1][col - 1] if dp[row - 1][col - 1] != float('inf') else -1