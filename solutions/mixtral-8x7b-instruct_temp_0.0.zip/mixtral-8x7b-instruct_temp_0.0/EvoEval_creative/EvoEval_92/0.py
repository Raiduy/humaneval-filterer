def paint_fountain(n):
    """
    This function will take a positive integer n as the number of fountain layers. It should return a string that represents a fountain with
    n layers, painted with letters starting from 'A'. Each fountain layer should be symmetrical, wider than the previous one,
    and painted with a new letter of the alphabet. The central column of the fountain, regardless of the number of layers, should always be 
    painted with the letter 'A'. If the number of layers exceeds the number of letters in the alphabet (26), the painting should restart 
    from 'A'.
    
    The function should return a string with newlines (
) between layers. Each layer should be centered. The maximal width of the 
    fountain (the last layer) should be 2n-1 characters wide.
    
    Examples:
    For n = 1, the output should be 'A'
    
    For n = 3, the output should be 
    '  A  
'
    ' BAB 
'
    'CCACC'
    
    For n = 27, the output should be a 27-layered fountain with 'A' in the central column and the same pattern as above.
    
    Note:
    - The input is guaranteed to be a positive integer.
    - Consider that the alphabet is always uppercase and has 26 letters from 'A' to 'Z'.
    """
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    alphabet_len = len(alphabet)

    def generate_layer(layer_num, alphabet_part):
        layer_width = 2 * layer_num - 1
        cols_to_paint = (layer_width - 1) // 2
        layer = alphabet_part[0] * (cols_to_paint + 1)
        for i in range(1, cols_to_paint):
            if i < len(alphabet_part):
                layer += alphabet_part[i] + alphabet_part[i]
            else:
                start_index = i - len(alphabet_part)
                layer += alphabet[start_index % alphabet_len] + alphabet[start_index % alphabet_len]
        layer += alphabet_part[0]
        return layer
    result = ''
    alphabet_part = alphabet[:n % alphabet_len]
    for i in range(1, n + 1):
        result += generate_layer(i, alphabet_part) + '\n'
    return result.rstrip()