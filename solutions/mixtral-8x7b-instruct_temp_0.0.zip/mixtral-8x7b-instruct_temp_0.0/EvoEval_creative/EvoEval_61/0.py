def transform_string(s):
    """
    Given a string s, perform the following operations:

    1. Swap the case of all alphabetic characters in odd indices.
    2. Replace all vowels (case-insensitive) with the next vowel in the sequence (a->e, e->i, i->o, o->u, u->a).
    3. Replace all consonants (case-insensitive) with the preceding consonant (b->z, c->b, ..., z->y, b->z)

    Assume that all characters in the input string s are either alphabetic characters or spaces.
    Ignore spaces while performing operations but maintain their position in the string.

    For example:
    transform_string('Hello World') returns 'GIkKu VUqKc'
    transform_string('Python') returns 'NXsGuM'
    transform_string('Java') returns 'HEtE'
    """
    result = []
    vowel_seq = 'aeiouAEIOU'
    consonant_seq = 'zbcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    for char in s:
        if char == ' ':
            result.append(char)
            continue
        vowel_idx = vowel_seq.index(char) if char in vowel_seq else -1
        consonant_idx = consonant_seq.index(char) if char in consonant_seq else -1
        if vowel_idx != -1 or consonant_idx != -1:
            if len(result) % 2 != 0:
                result.append(char.swapcase())
            else:
                result.append(char)
        if vowel_idx != -1:
            result.append(vowel_seq[(vowel_idx + 1) % len(vowel_seq)])
        if consonant_idx != -1:
            result.append(consonant_seq[(consonant_idx - 1) % len(consonant_seq)])
    return ''.join(result)