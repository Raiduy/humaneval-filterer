def create_pyramid(p):
    """
    Given a positive integer p, construct a pyramid and return a list containing the number of blocks in each layer.

    Parameters:
    p (int): The number of blocks in the bottom layer.

    Returns:
    list: A list containing the number of blocks in each layer from bottom to top.

    Examples:
    >>> create_pyramid(10)
    [10, 8, 6, 4, 2]

    >>> create_pyramid(9)
    [9, 6, 4, 2]
    """
    result = [p]
    while p > 0:
        p = p - 2 if result[-1] % 2 == 0 else p - 3
        if p > 0:
            result.append(p)
    return result