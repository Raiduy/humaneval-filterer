from typing import List, Tuple

def minesweeper_clicked(grid: List[List[int]], position: Tuple[int, int]) -> List[List[int]]:

    def in_bounds(x: int, y: int) -> bool:
        return 0 <= x < len(grid) and 0 <= y < len(grid[0])

    def adjacent_cells(x: int, y: int) -> List[Tuple[int, int]]:
        cells = [(x + dx, y + dy) for (dx, dy) in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]]
        return [cell for cell in cells if in_bounds(cell[0], cell[1])]

    def reveal_cell(x: int, y: int) -> None:
        if in_bounds(x, y) and grid[x][y] != -1:
            if grid[x][y] == 1:
                return
            grid[x][y] = 0
            for (dx, dy) in adjacent_cells(x, y):
                reveal_cell(dx, dy)
    reveal_cell(position[0], position[1])
    return grid