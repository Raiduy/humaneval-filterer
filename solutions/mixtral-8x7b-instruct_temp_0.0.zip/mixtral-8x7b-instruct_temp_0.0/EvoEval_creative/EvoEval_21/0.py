def crossword_validator(grid, words):
    """
    Determines if all the words from a provided list of words can be found in the grid.
    Words can be found left-to-right (in a row), right-to-left (in a row),
    top-to-bottom down (in a column), and bottom-to-top (in a column).

    Parameters:
    grid (list of list of char): where each char is a lowercase letter.
    words (list of str): where each str is a lowercase word.

    Returns:
    bool: return True all words are found in the grid, False otherwise.
    """
    rows = [''.join(row) for row in grid]
    cols = [''] + [''.join(col) for col in zip(*grid)]
    for word in words:
        if not any((word == row[i:i + len(word)] for i in range(len(rows) - len(word) + 1))) and (not any((word == col[i:i + len(word)][::-1] for i in range(len(cols) - len(word) + 1)))):
            return False
    return True