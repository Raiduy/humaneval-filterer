def zodiac_element(birthdays):
    """
    Return a dictionary with the elements as keys and the number of birthdays corresponding 
    to zodiac signs associated with each element as values.

    If there are no birthdays under a given element, do not include that element in the 
    returned dictionary. Return None if the birthdays list is empty.

    Parameters:
    birthdays (list): List of dates in the format YYYY-MM-DD, representing birthdays.

    Returns:
    dict or None: A dictionary with the elements as keys and the number of birthdays as values,
                  or None if the birthdays list is empty.
    """
    if not birthdays:
        return None
    element_count = {'Fire': 0, 'Earth': 0, 'Air': 0, 'Water': 0}
    zodiac_map = {'Aries': 'Fire', 'Taurus': 'Earth', 'Gemini': 'Air', 'Cancer': 'Water', 'Leo': 'Fire', 'Virgo': 'Earth', 'Libra': 'Air', 'Scorpio': 'Water', 'Sagittarius': 'Fire', 'Capricorn': 'Earth', 'Aquarius': 'Air', 'Pisces': 'Water'}
    for birthday in birthdays:
        date = datetime.strptime(birthday, '%Y-%m-%d')
        month = date.month
        if 3 <= month <= 5:
            element_count['Fire'] += 1
        elif 4 <= month <= 6:
            element_count['Earth'] += 1
        elif 6 <= month <= 8:
            element_count['Air'] += 1
        elif 9 <= month <= 11:
            element_count['Water'] += 1
    for (zodiac, element) in zodiac_map.items():
        if element_count[element] > 0:
            element_count[element] -= 1
    return {k: v for (k, v) in element_count.items() if v > 0}