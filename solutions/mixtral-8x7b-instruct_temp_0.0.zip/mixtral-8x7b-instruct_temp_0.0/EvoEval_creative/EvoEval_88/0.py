def planet_population(dict_of_planets):
    """
    Given a dictionary of planets with population and size features,
    return a new dictionary with population densities.
    If population or size is not provided, ignore that planet.
    """
    result = {}
    for (planet, data) in dict_of_planets.items():
        population = data[0]
        size = data[1]
        if population is not None and size is not None:
            density = round(population / size, 2)
            result[planet] = density
    return result