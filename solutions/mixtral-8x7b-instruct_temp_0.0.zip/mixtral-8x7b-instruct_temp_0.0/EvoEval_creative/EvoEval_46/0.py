def hidden_message(test_cases):
    """
    Function to decode the secret message from a list of strings
    """
    result = []
    for case in test_cases:
        message = ''
        for word in case:
            message += word[0].lower() if word.isalpha() else ''
        if 'take the cannoli' in message.lower():
            result.append('Take the cannoli.')
        else:
            result.append(message)
    return result