def nature_sequence_generator(n, a, b):
    sequence = [a, b]
    for i in range(2, n):
        next_number = sequence[i - 1] + sequence[i - 2] + 1
        sequence.append(next_number)
    for (index, number) in enumerate(sequence):
        if is_prime(number):
            sequence[index] = 'prime'
    return sequence