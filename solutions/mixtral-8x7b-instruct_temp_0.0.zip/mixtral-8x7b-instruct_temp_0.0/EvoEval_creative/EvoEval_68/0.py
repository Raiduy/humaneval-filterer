def magical_sorting(arr):
    """
    Determines if it is possible to sort the given array using a minimum amount of magic.

    :param arr: List[int], the enchanted array of integers
    :return: bool, True if the array can be sorted, False otherwise
    """
    if not arr:
        return True
    max_element = max(arr)
    max_index = arr.index(max_element)
    if max_index == 1 and arr[0] < max_element and all((x < max_element for x in arr[1:])):
        (arr[0], arr[max_index]) = (arr[max_index], arr[0])
        return True
    return False