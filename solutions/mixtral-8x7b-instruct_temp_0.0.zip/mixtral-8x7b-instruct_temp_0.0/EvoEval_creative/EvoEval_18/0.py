def magical_seven(n: int):
    """
    magical_seven returns the n-th number that is a multiple of 7 and its digits sum up to 7.
    
    :param n: The position of the desired "magical" number in the sequence.
    :return: The n-th "magical" number.
    :rtype: int
    """
    (i, count) = (7, 1)
    while count < n:
        if i % 7 == 0:
            digit_sum = sum((int(digit) for digit in str(i)))
            if digit_sum == 7:
                count += 1
        i += 1
    return i