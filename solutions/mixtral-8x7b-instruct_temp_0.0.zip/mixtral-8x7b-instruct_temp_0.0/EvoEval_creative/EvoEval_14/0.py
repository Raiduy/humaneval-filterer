def create_alias(name: str) -> str:
    """ For a given name, create an alias following these rules:
        If the name includes a vowel, replace it with the next vowel in the cycle a->e->i->o->u->a. 
        If the name includes a consonant, replace it with the next consonant in alphabetical order, once 'z' is reached, loop back to 'b'.
        The alias should maintain the original names case (upper or lower)
        Ignore any non-alphabetical characters.
    """
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    result = ''
    for char in name:
        if char.isalpha():
            if char.lower() in vowels:
                index = vowels.index(char.lower())
                new_char = vowels[(index + 1) % len(vowels)].upper() if char.isupper() else vowels[(index + 1) % len(vowels)]
            else:
                index = consonants.index(char.lower())
                new_char = consonants[(index + 1) % len(consonants)].upper() if char.isupper() else consonants[(index + 1) % len(consonants)]
            result += new_char
        else:
            result += char
    return result