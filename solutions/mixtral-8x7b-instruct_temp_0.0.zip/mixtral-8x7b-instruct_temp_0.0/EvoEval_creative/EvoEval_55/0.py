def treasure_map(message, shift):
    """
    Encrypt the message using a jumping Caesar cipher.

    Parameters:
    message (str): The message to be encrypted.
    shift (int): The initial shift for the first character.

    Returns:
    str: The encrypted message.
    """
    encrypted_message = ''
    for (i, char) in enumerate(message):
        if char.isalpha():
            shifted_char = ord(char) + i + shift - 65
            if char.islower():
                shifted_char %= 26
            else:
                shifted_char %= 26
                shifted_char += 65
            encrypted_message += chr(shifted_char)
        else:
            encrypted_message += char
    return encrypted_message