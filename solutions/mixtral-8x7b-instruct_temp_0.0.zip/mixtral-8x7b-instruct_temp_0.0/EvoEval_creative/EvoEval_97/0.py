def alien_invasion(alien, humans):
    """
    The alien invasion is on the brink and all the human race can do is to defend themselves.
    There are 5 continents on the earth in our scenario:  Asia, Africa, North America, South America, and Europe.
    Suppose the aliens start their invasion from Asia and then move to the other continents in the following order:
    Africa, Europe, North America, and then South America.
    Write a function that takes two parameters, a string representing the name of an alien,
    and a dictionary in which keys are human names and values are strings representing the continents where they live.
    This function should return a list containing all the human names that will encounter that alien,
    sorted by the order of their encounter.
    If the alien name or humans dictionary is not valid, the function should return an empty list.
    Examples:
    alien_invasion("Xenomorph", {"John": "Asia", "Sarah": "Europe", "Michael": "North America", "Ana": "Africa"}) 
    ==> ['John', 'Ana', 'Sarah', 'Michael']
    alien_invasion("Predator", {"Emily": "South America", "Bob": "Europe", "Alice": "Africa"}) 
    ==> ['Alice', 'Bob', 'Emily']
    alien_invasion("Klingon", {"Peter": "Asia", "Paul": "North America", "Mary": "Europe"}) 
    ==> ['Peter', 'Mary', 'Paul']
    """
    if not (isinstance(alien, str) and isinstance(humans, dict)):
        return []
    continent_order = ['Asia', 'Africa', 'Europe', 'North America', 'South America']
    encounter_order = []
    for (name, continent) in humans.items():
        if continent == alien:
            encounter_order.append(name)
        else:
            index = continent_order.index(continent)
            if index < continent_order.index(alien):
                encounter_order.append(name)
    encounter_order.sort(key=lambda x: continent_order.index(humans[x]))
    return encounter_order