def transform_canvas(canvas: str) -> str:
    """
    Transform the given canvas by painting all accessible empty spaces with '*' while
    preserving wall configuration and unaccessible spaces.

    Parameters:
    canvas (str): A string representing the canvas with '#' for walls, '-' for empty spaces,
                  and 'P' for the starting point of the painter.

    Returns:
    str: The transformed canvas with painted empty spaces. If there's no painter 'P',
         the function returns the canvas as it is. If there are multiple painters or
         the number of painted spaces divides the empty spaces evenly, it returns 'Invalid canvas'.
    """
    painter_pos = canvas.find('P')
    if painter_pos == -1:
        return canvas
    if canvas.count('P') > 1:
        return 'Invalid canvas'
    (painted, empty) = (0, 0)
    for c in canvas:
        if c == '-':
            empty += 1
    if painted * 2 == len(canvas) - canvas.count('#') - 1:
        return 'Invalid canvas'
    transformed_canvas = list(canvas)
    i = painter_pos
    while i < len(transformed_canvas) and transformed_canvas[i] != '#':
        transformed_canvas[i] = '*'
        painted += 1
        i += 1
    return ''.join(transformed_canvas)