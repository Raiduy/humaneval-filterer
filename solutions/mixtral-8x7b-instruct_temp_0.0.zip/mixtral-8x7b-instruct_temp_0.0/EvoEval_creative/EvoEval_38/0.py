def translate_emoticons(sentence):
    """Convert text-based emoticons in a string to their corresponding Unicode emojis and return the result as a string.

    If the sentence doesn't contain any text-based emoticons, return the original sentence.
    Some examples of text-based emoticons and their corresponding emojis are ":)" corresponds to "😊", 
    ":(" corresponds to "☹️", ":D" corresponds to "😀", ";)" corresponds to "😉". 

    Args:
        sentence (str): The input string containing text-based emoticons.

    Returns:
        str: The input string with text-based emoticons replaced by their corresponding Unicode emojis.
    """
    emoticon_map = {':)': '😊', ':(': '☹️', ':D': '😀', ';)': '😉'}
    words = sentence.split()
    translated_words = []
    for word in words:
        if word in emoticon_map:
            translated_words.append(emoticon_map[word])
        else:
            translated_words.append(word)
    translated_sentence = ' '.join(translated_words)
    return translated_sentence