def alien_language(word_list, alien_dictionary):
    """
    Verify if the given list of words is sorted correctly in ascending order according to the alien dictionary.
    
    [input/output] samples:
    alien_language(['cat', 'dog', 'elephant'], 'abcdefghijklmnopqrstuvwxyz') => "CORRECT"
    alien_language(['apple', 'banana', 'kiwi'], 'zyxwvutsrqponmlkjihgfedcba') => "INCORRECT"
    alien_language(['bee', 'ant', 'cat', 'dog'], 'bacdefghijklmnopqrstuvwxyz') => "CORRECT"
    alien_language([], 'bacdefghijklmnopqrstuvwxyz') => "CORRECT"
    """
    if not word_list:
        return 'CORRECT'
    prev_word = word_list[0]
    for word in word_list[1:]:
        for i in range(min(len(prev_word), len(word))):
            if prev_word[i] != word[i]:
                if alien_dictionary.index(prev_word[i]) > alien_dictionary.index(word[i]):
                    return 'INCORRECT'
                else:
                    break
        else:
            if len(prev_word) > len(word):
                return 'INCORRECT'
        prev_word = word
    return 'CORRECT'