from typing import List


def candles_relight(candles: List[int]) -> int:
    """
    Given a list of candle heights, return the number of candles that can be lit.
    A candle can be lit if it is taller than all the candles before it.
    The first candle is always lit.

    Parameters:
    candles (List[int]): List of candle heights

    Returns:
    int: Number of candles that can be lit
    """
    if not candles:
        return 0
    lit_candles = 1
    max_height = candles[0]
    for current_candle in candles[1:]:
        if current_candle > max_height:
            lit_candles += 1
            max_height = current_candle
    return lit_candles