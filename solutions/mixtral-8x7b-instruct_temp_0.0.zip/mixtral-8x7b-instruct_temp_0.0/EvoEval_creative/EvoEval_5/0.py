from typing import List, Tuple


def zigzag_traversal(matrix: List[List[int]]) -> List[int]:
    """Given a 2D list of integers, return a list that represents its elements traversed in a zigzag order starting from the top-left corner and moving rightwards.
    When the right end is reached, the direction should be downwards to the next row, then to the left end, and so on until all elements are covered. 

    Args:
        matrix (List[List[int]]): A 2D list of integers.

    Returns:
        List[int]: A list of integers representing the zigzag traversal of the input matrix.

    Examples:
        >>> zigzag_traversal([[1, 2], [3, 4], [5, 6, 7], [8, 9, 10]])
        [1, 2, 4, 3, 5, 6, 7, 10, 9, 8]
    """
    if not matrix:
        return []
    (row_start, row_end) = (0, len(matrix) - 1)
    (col_start, col_end) = (0, len(matrix[0]) - 1)
    (result, going_down) = ([], True)
    while row_start <= row_end and col_start <= col_end:
        result.append(matrix[row_start][col_start])
        if going_down:
            if col_start == col_end:
                row_start += 1
            elif row_start == row_end:
                col_start += 1
            else:
                (matrix[row_start][col_start], matrix[row_start + 1][col_start]) = (matrix[row_start + 1][col_start], matrix[row_start][col_start])
                row_start += 1
                col_start += 1
        elif col_start == col_end:
            row_end -= 1
        elif row_start == row_end:
            col_start += 1
        else:
            (matrix[row_end][col_start], matrix[row_end - 1][col_start]) = (matrix[row_end - 1][col_start], matrix[row_end][col_start])
            row_end -= 1
            col_start += 1
        going_down = not going_down
    return result