def prime_anagram_pairs(n):
    primes = [x for x in range(2, n) if is_prime(x)]
    anagram_pairs = []
    for prime in primes:
        anagrams = get_anagrams(prime)
        for anagram in anagrams:
            if anagram in primes and anagram > prime:
                anagram_pairs.append((prime, anagram))
    anagram_pairs.sort()
    return anagram_pairs