from typing import List

def magical_alphabet(input_string: str) -> List[str]:
    """
    Given a string where 'a' represents '1', 'b' represents '2', 'c' represents '3' ... 'z' represents '26'. 
    This function should return a list of all possible combinations based on the interpretation of the input string. 
    For example, if input is '123', it should return ['abc', 'lc', 'aw'] which represents ['1,2,3', '12,3', '1,23'].

    >>> magical_alphabet('123')
    ['abc', 'lc', 'aw']
    
    >>> magical_alphabet('111')
    ['aaa', 'ak', 'ka']
    
    Note: Assume all input strings will only contain digits
    """
    if not input_string:
        return []
    result = []
    for i in range(len(input_string)):
        prefix = input_string[:i]
        suffix = input_string[i:]
        if not prefix:
            first_digit = int(suffix[0])
            if first_digit == 1:
                result.append('a' + magical_alphabet(suffix[1:])[0])
            else:
                for j in range(ord('a'), ord('z') + 1):
                    result.append(chr(j) + magical_alphabet(suffix)[0])
        else:
            last_digit = int(prefix[-1])
            letter = chr(ord('a') + last_digit - 1)
            new_prefix = prefix[:-1]
            result += [letter + suf for suf in magical_alphabet(suffix)]
            if not new_prefix:
                continue
            first_suffix_digit = int(suffix[0])
            if first_suffix_digit == 1:
                for j in range(ord('a'), ord('z') + 1):
                    result.append(chr(j) + magical_alphabet(suffix[1:])[0])
    return result