def happy_ants(path_length, sugar_locations, ant_positions):
    sugar_locations = set(sugar_locations)
    ants = sorted(ant_positions, key=lambda x: x[0])
    right_ants = [ant for ant in ants if ant[1] == 'right']
    left_ants = [ant for ant in ants if ant[1] == 'left']
    right_ants.reverse()
    happy_ants = 0
    current_sugar = set(sugar_locations)
    for ant in right_ants:
        if ant[0] in current_sugar:
            happy_ants += 1
            current_sugar.remove(ant[0])
        elif ant[0] > min(current_sugar):
            break
    for ant in left_ants:
        if ant[0] in current_sugar:
            happy_ants += 1
            current_sugar.remove(ant[0])
        elif ant[0] < max(current_sugar):
            continue
        else:
            break
    return happy_ants