def interstellar_translator(earth_phrase):
    """
    Translates an earth phrase into an alien language based on a set of rules.
    
    Parameters:
    earth_phrase (str): The earth phrase to translate.
    
    Returns:
    str: The translated alien phrase.
    """
    alien_phrase = ''
    for (i, char) in enumerate(earth_phrase):
        if i == 0 or earth_phrase[i - 1] == ' ':
            if char.islower():
                char = char.upper()
        if char in 'aeiou':
            char = {'a': 'e', 'e': 'i', 'i': 'o', 'o': 'u', 'u': 'a'}[char]
        elif char in 'bcdfghjklmnpqrstvwxyz':
            char = chr(ord(char) + 1)
            if char == '{' or char == '[':
                char = 'b'
        elif char == ' ':
            char = '@'
        if i < len(earth_phrase) - 1 and earth_phrase[i + 1] != ' ':
            if char.islower():
                if earth_phrase[i - 1].islower():
                    char += 'yz'
                else:
                    char += 'xy'
        alien_phrase += char
    return alien_phrase