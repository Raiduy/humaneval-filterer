def letter_shift_cipher(s, n):
    """
    Applies a simple shift cipher to the string `s` by shifting the letters in the alphabet by `n` places.
    Returns a tuple containing the encrypted string and the number of vowels in it.

    Parameters:
    s (str): The string to encrypt.
    n (int): The number of places to shift the letters.

    Examples:
    letter_shift_cipher("hello", 1) -> ('ifmmp', 1)
    letter_shift_cipher("abcde", 3) -> ('defgh', 1)
    letter_shift_cipher("I love Python!", 13) -> ('V ybir Clguba!', 3)
    """
    encrypted_string = ''
    vowels_count = 0
    for char in s:
        if char.isalpha():
            shifted_char = chr((ord(char.lower()) - ord('a') + n) % 26 + ord('a'))
            if char.islower():
                shifted_char = shifted_char.lower()
            else:
                shifted_char = shifted_char.upper()
            encrypted_string += shifted_char
            if char in 'aeiou':
                vowels_count += 1
        else:
            encrypted_string += char
    return (encrypted_string, vowels_count)