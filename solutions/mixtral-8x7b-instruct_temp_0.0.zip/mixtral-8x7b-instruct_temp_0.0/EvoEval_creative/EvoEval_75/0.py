def magical_string_transformer(input_str):
    """
    Transforms the given string based on specific rules.
    
    Rule 1: Change vowels to the next vowel in the sequence.
    Rule 2: Change consonants to the next consonant in the alphabet.
    Rule 3: Increment digits by 1.
    Rule 4: Swap "?" and "!" in even and odd indices.
    
    :param input_str: The input string to transform.
    :return: The transformed string.
    """
    vowels = 'aeiouAEIOU'
    consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
    result = []
    for char in input_str:
        if char.isalpha():
            index = (vowels + consonants).index(char.lower())
            if char.islower():
                new_index = (index + 1) % len(vowels) if char in vowels else (index + 1) % len(consonants)
            else:
                new_index = (index + 1) % len(vowels) if char in vowels else (index + 1) % len(consonants)
            result.append(consonants[new_index] if char.islower() else consonants[new_index].upper())
        elif char.isdigit():
            result.append(str((int(char) + 1) % 10))
        elif char == '?':
            result.append('!' if input_str.index(char) % 2 != 0 else '?')
        elif char == '!':
            result.append('?' if input_str.index(char) % 2 != 0 else '!')
        else:
            result.append(char)
    return ''.join(result)