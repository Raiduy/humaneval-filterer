def musical_chairs(n, rounds, music):
    pos = 0
    for _ in rounds:
        num_seconds = _
        while num_seconds > 0:
            pos = (pos + music) % n
            num_seconds -= 1
        n -= 1
        if pos == 0:
            pos = n
    return [i for i in range(1, n + 1)]