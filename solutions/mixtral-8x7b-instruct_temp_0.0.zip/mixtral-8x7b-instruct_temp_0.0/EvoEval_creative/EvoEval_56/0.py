def str_to_morse_code(s):
    """
    You are given a string containing only lowercase letters a-z and spaces.
    Write a function str_to_morse_code() that translates the string into Morse Code.
    Each letter is separated by a space and each word is separated by a slash ( / ).
    Return the Morse Code string.

    Morse Code Dictionary: 
    {'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....', 
    'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 
    'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 
    'y': '-.--', 'z': '--..'}

    Examples:
    str_to_morse_code("hello world") returns ".... . .-.. .-.. --- / .-- --- .-. .-.. -.."
    str_to_morse_code("morse code") returns "-- --- .-. ... / -.-. --- -.. ."
    str_to_morse_code("") returns ""
    """
    morse_dict = {'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--', 'z': '--..'}
    morse_code = ''
    words = s.split(' ')
    i = 0
    while i < len(words):
        if words[i] == '':
            i += 1
            continue
        morse_code += morse_dict[words[i].lower()] + ' '
        if i != len(words) - 1 and words[i + 1] != '':
            morse_code += '/ '
        i += 1
    return morse_code