def decimal_to_binary(decimal, padding_length):
    """Convert a decimal number to binary form with specified padding length.

    Args:
    decimal (int): A non-negative integer.
    padding_length (int): A positive integer.

    Returns:
    str: A binary representation of the given decimal number padded with '0's at the beginning.
    The binary number is preceded by 'db' and followed by 'db'.

    Raises:
    ValueError: If the inputs are invalid.

    Examples:
    decimal_to_binary(15, 5)   # returns "db01111db"
    decimal_to_binary(32, 5)   # returns "Padding length is too small"
    decimal_to_binary(32, 10)   # returns "db0000100000db"
    """
    if not isinstance(decimal, int) or not isinstance(padding_length, int) or decimal < 0 or (padding_length <= 0):
        return 'Invalid Input'
    binary = bin(decimal)[2:]
    if len(binary) > padding_length:
        return 'Padding length is too small'
    padded_binary = binary.zfill(padding_length)
    return 'db' + padded_binary + 'db'