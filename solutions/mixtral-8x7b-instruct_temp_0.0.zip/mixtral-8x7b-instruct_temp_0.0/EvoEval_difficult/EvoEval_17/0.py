from typing import List, Tuple


def parse_music_advanced(music_string: str) -> Tuple[List[int], List[str]]:
    """
    Parses a string representing musical notes and rests in a special ASCII format,
    returning a tuple of two lists: the first list contains integers corresponding to
    the length of each note or rest, and the second list contains strings indicating
    whether the item is a note ('note') or a rest ('rest').
    
    Legend:
    - 'o'   : whole note, lasts four beats
    - 'o|'  : half note, lasts two beats
    - '.|'  : quarter note, lasts one beat
    - 'r'   : whole rest, lasts four beats
    - 'r|'  : half rest, lasts two beats
    - 'r.'  : quarter rest, lasts one beat
    - Any other character: treated as a rest with the same length as the previous item
    </s>(TPU)   
    """
    if not music_string:
        return ([], [])
    result = []
    prev_len = 4 if music_string[0] in 'o.' else 4 if music_string[0] == 'r' else 0
    prev_type = 'rest' if music_string[0] in 'r.' else 'note'
    for char in music_string:
        if char in 'o.|r':
            result.append(prev_len if prev_type == 'rest' else 1)
            result.append(prev_type)
            prev_len = 4 if char == 'o' else 2 if char == '.' else 1
            prev_type = 'note' if char != 'r' else 'rest'
        elif char == '|':
            prev_len //= 2
        else:
            result.append(prev_len if prev_type == 'rest' else 1)
            result.append(prev_type)
    result.append(prev_len if prev_type == 'rest' else 1)
    result.append(prev_type)
    return result[:-1] if result[-1] == 'rest' else result