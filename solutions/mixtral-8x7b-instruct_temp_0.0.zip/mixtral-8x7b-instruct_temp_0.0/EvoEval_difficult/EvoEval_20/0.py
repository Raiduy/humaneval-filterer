from typing import List, Tuple

def find_subset_closest_elements(numbers: List[float], subset_size: int) -> Tuple[float, ...]:
    if len(numbers) < subset_size or subset_size < 1:
        raise ValueError('Input list must have at least subset_size elements')
    distances = [max(numbers[i:i + subset_size]) - min(numbers[i:i + subset_size]) for i in range(len(numbers) - subset_size + 1)]
    min_distance_index = distances.index(min(distances))
    return tuple(sorted(numbers[min_distance_index:min_distance_index + subset_size]))