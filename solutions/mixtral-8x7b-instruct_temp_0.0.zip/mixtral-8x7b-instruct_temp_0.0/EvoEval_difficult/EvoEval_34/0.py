def unique(l, from_index, to_index):
    """Return sorted unique elements in a sub-list of a given list from a given start index to a given end index, inclusive.
    If the start or end index is out of range, return an error message 'Invalid range'.
    The function should not use built-in functions for removing duplicates or sorting.
    """
    if from_index < 0 or to_index >= len(l) or from_index > to_index:
        return 'Invalid range'
    unique_elements = []
    for i in range(from_index, to_index + 1):
        if l[i] not in unique_elements:
            unique_elements.append(l[i])
    unique_elements.sort()
    return unique_elements