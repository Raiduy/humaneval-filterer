def advanced_fruit_distribution(s, n, m):
    """
    Given a string s representing a distribution of apples, oranges, and mangoes in a basket,
    determine the number of mangoes in the basket such that the basket contains at least m mangoes.

    Parameters:
    s (str): A string representing the distribution of fruits in the basket.
    n (int): The total number of fruits in the basket.
    m (int): The minimum requirement for mangoes.

    Returns:
    int: The number of mangoes in the basket that meets the minimum requirement, or -1 if it's not possible.
    """
    (total_apples, total_oranges) = map(int, re.findall('\\d+', s))
    max_mangoes = n - total_apples - total_oranges
    if max_mangoes < m:
        return -1
    return max_mangoes