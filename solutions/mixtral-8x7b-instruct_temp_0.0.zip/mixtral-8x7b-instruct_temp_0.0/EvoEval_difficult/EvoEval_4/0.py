from typing import List, Tuple


