def check_dict_case_content(dictionary):
    """
    Given a dictionary, return True if all keys are strings either in lower 
    case or upper case, and all values are strings
    with only the first letter capitalized, else return False.
    If any of the keys or values are not strings, return False.
    The function should return False if the given dictionary is empty.
    Also, the function should return False if the keys are not of equal length.
    """
    if not dictionary:
        return False
    keys = list(dictionary.keys())
    values = list(dictionary.values())
    if not all((isinstance(key, str) for key in keys)) or len(set(map(len, keys))) != 1:
        return False
    if not all((key.islower() or key.isupper() for key in keys)):
        return False
    if not all((isinstance(value, str) for value in values)) or not all((value[0].isupper() and value[1:].islower() for value in values)):
        return False
    return True