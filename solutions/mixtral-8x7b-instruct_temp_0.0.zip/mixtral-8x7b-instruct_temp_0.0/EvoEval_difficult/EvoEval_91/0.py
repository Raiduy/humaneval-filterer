def detect_boredom(S, substrings):
    """
    You'll be given a string of words and a list of substrings. Your task is to count the number 
    of boredoms. A boredom is a sentence that starts with any substring from the list. 
    Sentences are delimited by '.', '?' or '!', however, consider continuous sentences inside brackets 
    "()", "[]" or "{}" or quotes are ignore.

    Note: The substrings are case sensitive and can consist of one or more words.

    Parameters:
    S (str): The string of words to search for boredoms.
    substrings (List[str]): The list of substrings that indicate the start of a boredom.

    Returns:
    int: The number of boredoms in the string S.
    """
    boredom_count = 0
    ignore_case = False
    for (i, char) in enumerate(S):
        if char in '.!?':
            if not ignore_case:
                for substring in substrings:
                    if S[i - len(substring):i].lower() == substring.lower():
                        boredom_count += 1
                        break
            ignore_case = False
        elif char in '([{':
            ignore_case = True
        elif char in ')]}':
            ignore_case = False
        elif not ignore_case and S[i - 1] in '.!?':
            ignore_case = False
    return boredom_count