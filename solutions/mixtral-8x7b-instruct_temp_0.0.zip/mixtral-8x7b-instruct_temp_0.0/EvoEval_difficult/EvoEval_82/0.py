def prime_length(string, opt=None):
    """Return True if the length of the string (or the number of unique letters or words) is a prime number.

    If opt is 'letters', count the number of unique letters. If opt is 'words', count the number of words
    (separated by spaces or commas, ignoring empty words). Otherwise, count the overall length of the string.
    """
    if opt == 'letters':
        count = len(set(string.lower()))
    elif opt == 'words':
        count = sum((1 for word in string.lower().split() if word != ''))
    else:
        count = len(string)
    if count < 2:
        return False
    for i in range(2, int(count ** 0.5) + 1):
        if count % i == 0:
            return False
    return True