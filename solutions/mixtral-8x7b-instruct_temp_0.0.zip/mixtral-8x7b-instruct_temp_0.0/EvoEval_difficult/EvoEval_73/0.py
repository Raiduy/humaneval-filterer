def smallest_change(arr, k):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic and the sum of its elements divisible by a given integer k.
    A palindromic array is an array that is read the same backwards and forwards.
    In one change, you can change one element to any other integer.

    :param arr: list[int] - the input array
    :param k: int - the given integer
    :return: int - the minimum number of changes needed
    """
    n = len(arr)
    total_sum = sum(arr)
    target_sum = (k - total_sum % k) % k
    changes = 0
    for i in range(n // 2):
        if arr[i] != arr[n - i - 1]:
            changes += 1
    if changes % 2 == 1 and target_sum != 0:
        return -1
    elif changes % 2 == 0 and target_sum != 0:
        return changes // 2 + 1
    elif changes % 2 == 1 and target_sum == 0:
        return changes // 2
    else:
        return changes // 2 - 1