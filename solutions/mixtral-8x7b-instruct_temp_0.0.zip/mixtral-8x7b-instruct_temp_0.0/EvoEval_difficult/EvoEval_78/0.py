def hex_key_primes(num):
    """
    Counts the number of hexadecimal prime digits and returns the sum of these hexadecimal prime digits in decimal form.
    Additionally, returns whether the prime digits are dominant or not.

    Parameters:
    num (str): A hexadecimal number as a string.

    Returns:
    int, str or tuple: If there is only one prime digit, returns the count of prime digits and the word 'Dominant'.
                       If there are multiple prime digits, returns the count of prime digits, the word 'Dominant' or 'Non-dominant',
                       and the sum of the prime digits in decimal form.
    """
    hex_primes = {2, 3, 5, 7, 'B', 'D'}
    (count, total) = (0, 0)
    for char in num:
        if char in hex_primes:
            count += 1