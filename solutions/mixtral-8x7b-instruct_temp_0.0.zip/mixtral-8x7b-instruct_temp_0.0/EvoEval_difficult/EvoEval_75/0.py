def is_multiply_prime(a, b):
    """
    Returns True if the given number (a) is the multiplication of exactly b prime numbers,
    and False otherwise. Also, returns the list of prime numbers in increasing order.
    If it is impossible to obtain the number with the given primes, returns an empty list.

    :param a: int
    :param b: int
    :return: tuple of bool and list of int
    """
    primes = generate_primes(int(a ** 0.5))
    primes.sort()
    if b > len(primes):
        return (False, [])

    def check_multiplication(multiplier, current_product):
        if multiplier == b:
            return current_product == a
        if current_product > a:
            return False
        for prime in primes:
            if not check_multiplication(multiplier + 1, current_product * prime):
                continue
            return True
        return False
    return (check_multiplication(1, 1), primes)