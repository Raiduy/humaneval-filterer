def complex_power(x, n, m):
    """Returns True if x is a complex power of n and m, and False otherwise.

    Args:
    x (complex): The number to check.
    n (int): The first base number.
    m (int): The second base number.

    Returns:
    bool: True if x is a complex power of n and m, False otherwise.

    """
    if n == 1 or m == 1:
        return False
    n_power = n ** int(m ** 0.5)
    m_power = m ** int(m ** 0.5)
    return n_power == x or m_power == x