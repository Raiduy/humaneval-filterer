def next_smallest_and_largest(lst):
    """
    Returns a tuple of the 2nd smallest and the 2nd largest elements of the list.
    Returns None if there is no such element.
    
    Time complexity: O(n)
    """
    if len(lst) < 4:
        return None
    smallest = float('inf')
    largest = float('-inf')
    second_smallest = None
    second_largest = None
    for num in lst:
        if num < smallest:
            (second_smallest, smallest) = (smallest, num)
        elif num > largest:
            (second_largest, largest) = (largest, num)
        elif num < smallest and num > second_smallest:
            second_smallest = num
        elif num > largest and num < second_largest:
            second_largest = num
    return (second_smallest, second_largest)