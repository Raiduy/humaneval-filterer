from typing import List, Optional, Tuple


def longest_substring(strings: List[str]) -> Tuple[Optional[str], Optional[int]]:
    longest_substring_so_far = None
    index_of_longest_substring = None
    for (i, string) in enumerate(strings):
        for j in range(len(string)):
            if string[j].lower() in 'aeiou':
                current_substring = string[j:]
                if longest_substring_so_far is None or len(current_substring) > len(longest_substring_so_far):
                    longest_substring_so_far = current_substring
                    index_of_longest_substring = i
    return (longest_substring_so_far, index_of_longest_substring)