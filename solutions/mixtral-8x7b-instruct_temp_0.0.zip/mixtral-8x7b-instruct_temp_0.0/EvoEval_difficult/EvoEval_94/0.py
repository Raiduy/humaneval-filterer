def complexity_increased(lst, n):
    if not all((isinstance(num, int) for num in lst)):
        return -1
    if not any((num > 0 for num in lst)):
        return -1
    prime_numbers = [num for num in lst if is_prime(num)]
    if not prime_numbers:
        return -1
    return sum((power_sum(num, n) for num in prime_numbers))