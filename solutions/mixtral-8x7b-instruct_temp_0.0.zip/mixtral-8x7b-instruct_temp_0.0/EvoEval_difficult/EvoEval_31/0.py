def is_prime_sum(lst, n):
    """
    Return true if a given list contains a pair of prime numbers that sum up to a given number 'n', and false otherwise.
    """

    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True
    complements = set()
    for num in lst:
        if is_prime(num):
            complements.add(n - num)
    for num in lst:
        if num in complements:
            return True
    return False