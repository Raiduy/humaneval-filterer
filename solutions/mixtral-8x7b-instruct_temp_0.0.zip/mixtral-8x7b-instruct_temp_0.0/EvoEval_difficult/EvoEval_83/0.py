def starts_one_ends(n, x, y):
    """
    Given three positive integers n, x, and y, return the count of the numbers of n-digit
    positive integers that start with digit x or end with digit y. The function should also handle
    inputs where n is up to 5. In addition, if there is no n-digit number that fits the criteria,
    or x or y is not a digit, return -1.
    """
    if not (x.isdigit() and y.isdigit()):
        return -1
    x = int(x)
    y = int(y)
    if n < 1 or n > 5:
        return -1
    start_count = 0
    if x == 0:
        start_count = 10 ** (n - 1)
    else:
        start_count = x * 10 ** (n - 1)
        for i in range(x + 1, 10):
            start_count += 10 ** (n - 1)
    end_count = 0
    if y == 0:
        end_count = 1
    elif y == 1:
        end_count = 10 ** (n - 1) + 1
    else:
        end_count = 10 ** (n - 1)
        for i in range(1, y):
            end_count += 10 ** (n - 1)
    if start_count + end_count == 0:
        return -1
    return start_count + end_count - 1