def get_row(lst, x, y):
    """
    Given a 3-dimensional data as a nested list, find integers x in the list
    and return a sorted list of tuples representing the coordinates of x,
    excluding coordinates with depth y.
    
    Parameters:
    lst (list): A nested list representing a 3-dimensional data structure.
    x (int): The value to find in the list.
    y (int): The depth value to exclude from the result.

    Returns:
    list: A sorted list of tuples representing the coordinates of x.
    """
    result = [(i, j, k) for (i, sublist) in enumerate(lst) for (j, row) in enumerate(sublist) for (k, val) in enumerate(row) if val == x]
    result = [(i, j, k) for (i, j, k) in result if k != y]
    result.sort(key=lambda x: (x[0], x[1], x[2]))
    result.sort(key=lambda x: (x[1], -x[2]))
    return result