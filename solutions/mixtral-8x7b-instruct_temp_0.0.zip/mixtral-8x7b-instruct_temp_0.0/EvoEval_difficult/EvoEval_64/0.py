def vowels_count(s, l=None):
    """
    Returns the number of occurrences of vowels in the string `s`.
    By default, vowels are 'a', 'e', 'i', 'o', 'u'. 'y' is also a vowel,
    but only when it is at the last position of a word, unless 'y' is
    specified in the list of custom vowels `l`.

    Args:
    - s (str): The string to count the vowels in.
    - l (list, optional): A list of custom vowels. Defaults to None.

    Returns:
    int: The number of vowels in the string `s`.
    """
    if l is None:
        vowels = 'aeiou'
    else:
        vowels = ''.join(sorted(set(l.lower())))
        if 'y' in vowels and vowels.index('y') != len(vowels) - 1:
            vowels += 'y'
    count = sum((char.lower() in vowels for char in s))
    return count