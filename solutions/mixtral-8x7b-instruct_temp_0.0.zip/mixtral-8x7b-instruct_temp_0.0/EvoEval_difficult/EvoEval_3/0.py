from typing import List, Tuple

def account_balance(operations: List[Tuple[str, int]], daily_limit: int) -> bool:
    balance = 0
    daily_withdrawal = 0
    for (operation, amount) in operations:
        if operation == 'withdrawal':
            if amount > daily_limit - daily_withdrawal:
                return 'Daily limit exceeded'
            daily_withdrawal += amount
            balance -= amount
            if balance < 0:
                return 'Balance below zero'
        else:
            balance += amount
    return 'All operations successful'