def prime_fib_matrix(n: int, m: int):
    """
    prime_fib_matrix returns an n x m matrix where the element at the i-th row and j-th column is the k-th
    number that is a Fibonacci number and it's also prime with k=i*j.
    The rows and columns are 0-indexed.
    """
    matrix = [[0] * m for _ in range(n)]
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
    fib_sequence = [0, 1]

    def is_prime(num):
        for prime in primes:
            if num % prime == 0:
                return False
            if prime > num ** 0.5:
                break
        return True

    def fibonacci(n):
        if n < len(fib_sequence):
            return fib_sequence[n]
        (a, b) = (fib_sequence[-1], fib_sequence[-2])
        fib_sequence.append(a + b)
        return fib_sequence[-1]
    for i in range(n):
        for j in range(m):
            k = i * j
            while True:
                fib_num = fibonacci(k)
                if is_prime(fib_num):
                    matrix[i][j] = fib_num
                    break
                k += 1
    return matrix