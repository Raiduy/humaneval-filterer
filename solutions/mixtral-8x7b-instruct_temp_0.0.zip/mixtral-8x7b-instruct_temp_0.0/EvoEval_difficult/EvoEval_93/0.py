def encode_complex(message, shift, key):
    """
    Encodes a message by swapping case of all letters, replacing vowels with a shifted version of that vowel,
    and replacing consonants with the corresponding character in the key based on its position in the alphabet.

    Parameters:
    message (str): The message to encode.
    shift (int): The amount to shift vowels by.
    key (str): The string of characters to replace consonants with.

    Returns:
    str: The encoded message.
    """
    vowel_map = {'a': 'e', 'e': 'i', 'i': 'o', 'o': 'u', 'u': 'a'}
    vowel_map = {k: chr((ord(vowel_map[k]) - 97 + shift) % 26 + 97) for k in vowel_map}
    consonant_map = {chr(i): key[i - 97] for i in range(97, 123) if chr(i) not in vowel_map}
    encoded_message = ''.join((consonant_map.get(c.lower(), c) if c.islower() and c not in vowel_map else vowel_map.get(c.lower(), c).upper() if c.islower() else c.lower() if c.isupper() and c not in vowel_map else vowel_map.get(c.lower(), c) for c in message))
    return encoded_message