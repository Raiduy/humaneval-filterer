
def count_nums(arr):
    """
    Function to count the number of elements in an array of integers
    with a sum of digits greater than 0.
    If a number is negative, its first signed digit is considered
    as negative.
    """
    def sum_of_digits(num):
        """
        Helper function to return the sum of digits of a number.
        """
        if num < 0:
            num = -num
        return sum(int(digit) for digit in str(num))

    return sum(1 for num in arr if sum_of_digits(num) > 0)
