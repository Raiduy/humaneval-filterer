
def check_dict_case(dct):
    """
    Given a dictionary, return True if all keys are strings in lower
    case or all keys are strings in upper case, else return False.
    The function should return False if the given dictionary is empty.
    """
    if not dct:
        return False
    
    key_case = dct[list(dct.keys())[0]].isupper() if dct else False
    for key in dct:
        if (key.isupper() and not key_case) or (key.islower() and key_case):
            return False
    return True
