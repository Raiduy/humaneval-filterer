from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.

    Args:
        strings (List[str]): List of strings to find the longest one.

    Returns:
        Optional[str]: The longest string in the list or None if the list is empty.

    Examples:
        >>> longest([])
        None
        >>> longest(['a', 'b', 'c'])
        'a'
        >>> longest(['a', 'bb', 'ccc'])
        'ccc'
    """
    if not strings:
        return None
    longest_string = strings[0]
    for s in strings[1:]:
        if len(s) > len(longest_string):
            longest_string = s
    return longest_string
