
def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers or 0, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.
    '''
    negatives = [num for num in lst if num <= 0]
    positives = [num for num in lst if num > 0]

    if not negatives and not positives:
        return (None, None)
    elif not negatives:
        return (None, min(positives))
    elif not positives:
        return (max(negatives), None)
    else:
        return (max(negatives), min(positives
