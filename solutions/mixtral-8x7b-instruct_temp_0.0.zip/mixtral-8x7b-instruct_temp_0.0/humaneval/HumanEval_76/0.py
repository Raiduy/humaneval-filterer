
def is_simple_power(x, n):
    """
    Returns True if x is a simple power of n, False otherwise.

    A number x is a simple power of n if there exists an integer k such that n**k = x.

    Args:
    x (int): The number to check.
    n (int): The base number.

    Returns:
    bool: True if x is a simple power of n, False otherwise.

    Examples:
    is_simple_power(1, 4) => True
    is_simple_power(2, 2) => True
    is_simple_power(8, 2) => True
    is_simple_power(3, 2) => False
    is_simple_power(3, 1) => False
    is_simple_power(5, 3) => False
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")
    return (x > 0 and (n ** int(x ** (1 / n))) == x) if x else False
