
def tri(n):
    """
    Calculate the first n + 1 numbers of the Tribonacci sequence.

    Parameters:
    n (int): A non-negative integer.

    Returns:
    list: A list of the first n + 1 numbers of the Tribonacci sequence.

    Examples:
    tri(3) = [1, 3, 2, 8]
    """
    if n == 0:
        return [0]
    elif n == 1:
        return [1]
    elif n == 2:
        return [1, 3]
    else:
        tri_seq = [1, 3, 2]
        for i in range(3, n + 1):
            if i % 2 == 0:
                tri_seq.append(1 + i // 2)
            else:
                tri_seq.append(tri_seq[i - 1] + tri_seq[i - 2] + tri_seq[i - 3])
        return tri_seq
