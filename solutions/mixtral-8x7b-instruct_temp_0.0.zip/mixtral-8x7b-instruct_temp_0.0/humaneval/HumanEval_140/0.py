
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
