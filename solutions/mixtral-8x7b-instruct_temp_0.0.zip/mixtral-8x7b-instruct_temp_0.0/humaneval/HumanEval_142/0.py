


def sum_squares(lst):
    """
    This function takes a list of integers and squares or cubes the integer entry based on the index.
    It then returns the sum of all entries.

    Parameters:
    lst (list): List of integers

    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """
    # Iterate over the indices of the list
    for i in range(len(lst)):
        # If the index is a multiple of 3
        if i % 3 == 0:
            # Square the integer entry
            lst[i] **= 2
        # If the index is a multiple of 4 and not a multiple of 3
        elif i % 4 == 0 and i % 3 != 0:
            # Cube the integer entry
            lst[i] **= 3
    # Return the sum of all entries
    return sum(lst)
