from typing import List


def separate_paren_groups(paren_string):
    def find_next_index(start, direction):
        count, index = 0, start
        while 0 <= index < length:
            if paren_string[index] == '(':
                count += direction
            elif paren_string[index]
