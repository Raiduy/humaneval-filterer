from typing import List


def string_xor(a: str, b: str) -> str:
