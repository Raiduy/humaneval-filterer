
def sorted_list_sum(lst):
    """
    Function to accept a list of strings as a parameter,
    delete strings that have odd lengths from it,
    and return the resulted list with a sorted order.
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word,
    and you should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    """
    # Filter out words with odd lengths
    lst = list(filter(lambda word: len(word) % 2 == 0, lst))

    # Sort the list by length first, then alphabetically
    lst.sort(key=lambda word: (len(word), word))

    return lst
