
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Return the number of vowels in the given word.
    Vowels are 'a', 'e', 'i', 'o', 'u', and 'y' if it is at the end of the word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    vowels = "aeiouAEIOU"
    s = s.strip()
    if s[-1] == "y":
        s = s[:-1]
    return sum(1 for char in s if char in vowels)
