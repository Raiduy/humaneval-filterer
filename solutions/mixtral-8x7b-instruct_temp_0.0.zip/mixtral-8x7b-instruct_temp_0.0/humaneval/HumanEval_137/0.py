
def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,
    """

    # Convert string inputs to float
    if isinstance(a, str):
        a = float(a.replace(',', '').replace(' ', ''))
    if isinstance(b, str):
        b = float(b.replace(',', '').replace(' ', ''))

    # Compare a and b, return the larger number with its original type
    if a > b:
        return a
    elif a < b:
        return b
    else:
        return None
