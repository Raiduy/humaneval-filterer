
def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    Parameters:
    n (int): An integer greater than 0

    Returns:
    int: The special factorial of the input integer

    Examples:
    >>> special_factorial(4)
    288
    """
    if n <= 0:
        raise ValueError("Input must be an integer greater than 0")

    result = 1
    for i in range(1, n+1):
        result *= i

    return result * special_factorial(n-1)
