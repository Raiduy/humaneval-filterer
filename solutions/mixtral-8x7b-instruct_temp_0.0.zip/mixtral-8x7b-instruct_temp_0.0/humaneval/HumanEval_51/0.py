

def remove_vowels(text):
    """
    remove_vowels is a function that takes a string as input and returns a new string with all the vowels removed.
    :param text: str, the input string
    :return: str, the string with vowels removed
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    vowels = set("aeiouAEIOU")
    return "".join(char for char in text if char not in vowels)
