from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.

    Args:
        numbers (List[int]): List of integers

    Returns:
        List[int]: List of rolling maximums

    Examples:
        >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
        [1, 2, 3, 3, 3, 4, 4]
    """

    # Initialize the rolling maximum list with the first element
    rolling_max_list = [numbers[0]]

    # Iterate over the input list starting from the second element
    for num in numbers[1:]:
        # Set the rolling maximum to the current number if it's greater than the previous rolling maximum
        rolling_max_list.append(max(num, rolling_max_list[-1]))

    return rolling_max_list
