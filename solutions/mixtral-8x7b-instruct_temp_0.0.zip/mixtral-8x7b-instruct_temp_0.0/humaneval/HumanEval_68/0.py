
def pluck(arr):
    """
    Given an array representing a branch of a tree that has non-negative integer nodes,
    pluck one of the nodes and return it.
    The plucked node should be the node with the smallest even value.
    If multiple nodes with the same smallest even value are found,
