from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """
    Function to parse a string representing multiple groups of nested parentheses separated by spaces,
    and output the deepest level of nesting for each group.

    Parameters:
    paren_string (str): String of parentheses groups separated by spaces.

    Returns:
    List[int]: List of deepest nesting levels for each parentheses group.

    Examples:
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def find_deepest_nesting(paren_sub_string):
        open_parens_count = 0
        deepest_nesting = 0

        for paren in paren_sub_string:
            if paren == '(':
                open_parens_count += 1
                deepest_nesting = max(deepest_nesting, open_parens_count)
            elif paren == ')':
                open_parens_count -= 1

        return deepest_nesting

    result = []
    for group in paren_string.split():
        result.append(find_deepest_nesting(group))

    return result
