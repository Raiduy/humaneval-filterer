
def is_bored(S):
    """
    Given a string of words, count the number of boredoms which are sentences
    starting with the word "I". Sentences are delimited by '.', '?' or '!'.
    """
    # Split the string into sentences based on delimiters
    sentences = S.split('.') + S.split('?') + S.split('!')
    boredom_count = 0

    # Iterate through the sentences
    for sentence in sentences:
        # If the sentence starts with "I", increment the boredom count
        if sentence.strip().startswith('I'):
            boredom_count += 1

    return boredom_count
