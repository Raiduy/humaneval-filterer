
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    :param a: The first positive integer.
    :param b: The second positive integer.
    :return: A list of even digits between a and b, in ascending order.
    :rtype: List[int]
    """
    result = []
    # Iterate over the range of numbers from a to b
    for num in range(min(a, b), max(a, b) + 1):
        # Convert the number to a string
        num_str = str(num)
        # Iterate over each digit in the number
        for digit in num_str:
            # Check if the digit is even and not already in the result list
            if int(digit) % 2 == 0 and int(digit) not in result:
                # Add the digit to the result list
                result.append(int(digit))
    # Sort the result list in ascending order
    result.sort()
    # Return the sorted result list
    return result
