
def match_parens(lst):
    '''
    Check if it is possible to concatenate the two strings in some order,
    that the resulting string will be balanced.
    
    Parameters:
    lst (list): A list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
