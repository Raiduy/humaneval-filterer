
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.
    '''
    def is_valid(string):
        count = 0
        for char in string:
            if char == '[':
                count += 1
            elif char == ']':
                count -= 1
                if count < 0:
                    return False
        return count == 0

    for i in range(len(string)):
        if string[i] == '[':
            for j in range(i + 1, len(string)):
                if is_valid(string[i:j + 1]):
                    return True

    return False
