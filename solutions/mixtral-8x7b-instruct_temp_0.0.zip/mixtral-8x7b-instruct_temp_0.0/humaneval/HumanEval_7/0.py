from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """
    Filter an input list of strings only for ones that contain given substring.

    :param strings: List[str] - the list of strings to filter
    :param substring: str - the substring to match in the strings
    :return: List[str] - the list of strings containing the given substring

    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'c
