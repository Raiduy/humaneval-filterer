
def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    :param n: int
    :return: tuple
    """
    # Initialize counters for even and odd palindromes
    even_count, odd_count = 0, 0

    # Loop through all numbers from 0 to n-1
    for i in range(n):
        # Convert the number to a string
        num_str = str(i)

        # Check if the string is a palindrome
        if num_str == num_str[::-1]:
            # If the palindrome has an even number of digits, it's even
            if len(num_str) % 2 == 0:
                even_count += 1
            # If the palindrome has an odd number of digits, it's odd
            else:
                odd_count += 1

    # Return the number of even and odd palindromes
    return even_count, odd_count
