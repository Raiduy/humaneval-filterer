
def reverse_delete(s, c):
    """
    Function to delete all characters in s that are equal to any character in c
    and check if the result string is palindrome.

    Parameters:
    s (str): The string to process.
    c (str): The string containing characters to be deleted from s.

    Returns:
    tuple: A tuple containing the result string and a boolean indicating
           if the result string is a palindrome.
    """
    s = ''.join(ch for ch in s if ch not in c)
    result = s[::-1] if s else ''
    return result, result == s
