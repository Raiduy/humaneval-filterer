
def search(lst):
    '''
    Given a non-empty list of positive integers, return the greatest integer that is greater than 0, 
    and has a frequency greater than or equal to the value of the integer itself. The frequency of an integer
    is the number of times it appears in the list. If no such a value exists, return -1.

    Parameters:
    lst (list): A list of positive integers

    Returns:
    int: The greatest integer with a frequency greater than or equal to its value, or -1 if no such value exists

    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''
    from collections import Counter

    # Calculate the frequency of each integer in the list
    freq = Counter(lst)

    # Iterate through the list of integers in descending order
    for num in sorted(lst, reverse=True):
        # If the frequency of the current number is greater than or equal to its value, return it
        if freq[num] >= num:
            return num

    # If no such value exists, return -1
    return -1
