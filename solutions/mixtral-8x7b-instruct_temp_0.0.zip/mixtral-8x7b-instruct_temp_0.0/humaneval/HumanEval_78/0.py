
def hex_key(num):
    """
    Counts the number of hexadecimal digits that are primes.
    Hexadecimal digits are 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F.
    Prime numbers are 2, 3, 5, 7, 11, 13, 17,...
    Args:
        num (str): A string representing a hexadecimal number.

    Returns:
        int: The number of prime hexadecimal digits in the input string.
    """
    prime_hex_digits = {'2', '3', '5', '7', 'B', 'D', 'F'}
    return sum(digit in prime_hex_digits for digit in num.upper())
