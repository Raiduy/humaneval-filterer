
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers"""
    if n < 8 or n % 2 != 0:
        return False
    for i in range(4, n + 1, 2):
        if n - i <= 6 and (n - i) % 2 == 0:
            return True
        for j in range(4, i + 1, 2):
            if i - j <= 6 and (i - j) % 2 == 0 and is_equal_to_sum_even(n - i):
                return True
    return False

