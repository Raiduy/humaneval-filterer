

def get_positive(l: list):
    """Return only positive numbers in the list.

    Parameters:
    l (list): A list of numbers
