

def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    :param s0: The first string.
    :param s1: The second string.
    :return: True if the words have the same characters, False otherwise.
    """
    return sorted(s0) == sorted(s1)

