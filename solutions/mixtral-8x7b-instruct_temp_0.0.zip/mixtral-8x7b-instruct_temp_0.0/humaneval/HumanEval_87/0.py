
def get_row(lst, x):
    """
    Given a 2-dimensional data represented as a list of lists
    (with potentially different lengths), and an integer x,
    return a list of tuples representing the coordinates of x
    in the list, sorted by rows in ascending order and columns
    in descending order.

    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """
    result = []
    for i, row in enumerate(lst):
        if x in row:
            result.extend((i, j) for j in range(len(row))
