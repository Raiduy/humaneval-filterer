
def count_up_to(n):
    """Return a list of prime numbers less than n"""
    primes = []
    for possiblePrime in range(2, n):
        isPrime = True
        for num in range(2, int(possiblePrime ** 0.5) + 1):
            if possiblePrime % num == </s> code 0:
                isPrime = False
                break
        if isPrime:
            primes.append(possiblePrime)
    return primes
