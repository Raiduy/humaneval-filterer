
def simplify(x, n):
    """
    Simplifies the expression x * n and returns True if it evaluates to a whole number,
    and False otherwise. Both x and n are string representation of a fraction,
    in the format <numerator>/<denominator>, where both numerator and denominator
    are positive whole numbers.

    Parameters:
    x (str): A valid fraction in the format <numerator>/<denominator>.
