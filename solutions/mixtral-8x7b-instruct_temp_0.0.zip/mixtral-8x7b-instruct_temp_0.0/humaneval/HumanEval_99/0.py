
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    # Convert the input string to a float
    num = float(value)
    
    # Round the number to the nearest integer, rounding away from zero
    # if the number is equidistant from two integers
    closest_int = round(num, 0, math.floor if num-math.floor(num)>=0.5 else math.ceil)
    
    return int(closest_int)
