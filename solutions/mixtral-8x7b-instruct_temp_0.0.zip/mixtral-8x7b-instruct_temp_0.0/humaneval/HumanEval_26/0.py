from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep the order of elements left the same as in the input.

    Args:
        numbers (List[int]): List of integers
