

def how_many_times(string: str, substring: str) -> int:
    """
    Find how many times a given substring can be found in the original string. Count overlapping cases. The function is case-insensitive.

    :param string: The string to search in
    :param substring: The substring to find in the string
    :return: The number of times the substring appears
