
def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    If the array is empty, return an empty array.

    If the array has any strange number ignore it.

    Parameters:
    arr (List[int]): The input array of integers.

    Returns:
    List[str]: The resulting array with digits replaced by their corresponding names.
    """
    # Define a dictionary for digit to name mapping
    digit_map = {1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six",
                 7: "Seven", 8: "Eight", 9: "Nine"}

    # Filter out non-desired numbers and sort the rest
    filtered_and_sorted = sorted(filter(lambda x: 1 <= x <= 9, arr))[::-1]

    # Replace digits with their corresponding names
    result = [digit_map[num] for num in filtered_and_sorted]

    return result
