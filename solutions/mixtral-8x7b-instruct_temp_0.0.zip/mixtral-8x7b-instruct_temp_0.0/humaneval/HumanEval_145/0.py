
def order_by_points(nums):
    """
    Function to sort a list of integers in ascending order
    according to the sum of their digits, and if there are
    several items with similar sum of their digits, order
    them based on their index in the original list.

    Parameters:
    nums (list): List of integers to be sorted

    Returns:
    list: Sorted list of integers

    Examples:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    # Function to calculate the sum of digits of a number
    def sum_of_digits(n):
        return sum(int(digit) for digit in str(abs(n)))

    # Create a list of tuples, each containing a number and its sum of digits
    nums_with_sums = sorted((num, sum_of_digits(num)) for num in nums)

    # Sort the list of tuples based on the sum of digits, and then by the index
    nums_sorted = [tup[0] for tup in sorted(nums_with_sums, key=lambda x: (x[1], nums.index(x[0])))]

    return nums_sorted
