
def compare(game, guess):
    """
    Compares a given game's scores with a set of guesses and returns an array of differences.

    :param game: list of int, containing the actual scores
    :param guess: list of int, containing the guessed scores
    :return: list of int, the absolute differences between the guesses and actual scores
    """
    return [abs(g - gm) for g, gm in zip(guess, game)]
