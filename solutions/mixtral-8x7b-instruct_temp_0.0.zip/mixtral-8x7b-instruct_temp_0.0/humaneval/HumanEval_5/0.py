from typing import List


def intersperse(numbers: List[int], delimiter: int) -> List[int]:
    """
    Insert a number `delimiter` between every two consecutive elements of input list `numbers`.

    Parameters:
    numbers (List[int]): A list of integers.
    delimiter (int): A number to be inserted between every two consecutive elements of `numbers`.

    Returns:
    List[int]: A new list with `delimiter` inserted between every two consecutive elements of `numbers`.

    Examples:
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if not numbers:
        return numbers
    result = [numbers[0]]
    for num in numbers[1:]:
        result.append(delimiter)
