
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    # Calculate the number of numbers that start with 1
    start_with_one = 9 * (10 ** (n - 1))

    # Calculate the number of numbers that end with 1 (excluding those that start with 1)
    end_with_one = 9 * (10 ** (n - 1)) - 1

    # If n is 1, subtract 1 from end_with_one to avoid double-counting
    if n == 1:
        end_with_one -= 1

    # Add the two counts and return
    return start_with_one + end_with_one
