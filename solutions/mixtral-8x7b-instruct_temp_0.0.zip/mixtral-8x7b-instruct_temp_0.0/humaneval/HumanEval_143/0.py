
def words_in_sentence(sentence):
    """
    Given a string representing a sentence, return a string that contains the words from the original sentence
    whose lengths are prime numbers, maintaining the order of the words.

    Args:
        sentence (str): The sentence to extract prime-length words from.

    Returns:
        str: The string containing the prime-length words.
    """
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    return " ".join(word for word in sentence.split() if is_prime(len(word)))
