
def anti_shuffle(s):
    """
    Function to return an ordered version of a string where all words are
    replaced by a new word with characters arranged in ascending order
    based on ascii value.
    """
    # Split the string into words
    words = s.split()

    # Iterate over the words
    ordered_words = [ ''.join(sorted(word)) for word in words ]

    # Join the ordered words with a space
    ordered_sentence = ' '.join(ordered_words)

    return ordered_sentence


