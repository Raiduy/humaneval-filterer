

def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    """
    # Create an empty set to store unique elements of the list
    unique_elements = set()

    # Loop through each element in the list
    for element in l:
        # If the negative of the element is already in the set
        if -element in unique_elements:
            # Return True since we found a pair that sums to zero
            return True
        # Otherwise, add the element to the set
        unique_elements.add(element)

    # If we didn't find any pair that sums to zero, return False
    return False
