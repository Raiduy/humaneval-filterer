
def find_max(words):
    """
    Function to find the word with maximum number of unique characters.
    If multiple strings have maximum number of unique characters,
    return the one which comes first in lexicographical order.

    Args:
        words (list of strings): List of words to compare unique characters.

    Returns:
        string: Word with maximum number of unique characters.
    """
    if not words:
        return None

    max_word = words[0]
    max_count = len(set(max_word))

    for word in words[1:]:
        word_count = len(set(word))
        if word_count > max_count:
            max_word = word
            max_count = word_count
        elif word_count == max_count and word < max_word:
            max_word = word

    return max_word
