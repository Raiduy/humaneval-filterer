
def digitSum(s):
    """
    Function to return the sum of the upper characters' ASCII codes in a given string.

    Parameters:
    s (str): The input string.

    Returns:
    int: The sum of the upper characters' ASCII codes.
    """
    return sum(ord(c) for c in s if c.isupper())
