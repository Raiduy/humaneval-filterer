
def numerical_letter_grade(grades):
    """Converts a list of GPAs to a list of letter grades using the following table:
             GPA       |    Letter grade
              4.0                A+
            > 3.7                A 
            > 3.3                A- 
            > 3.0                B+
            > 2.7                B 
            > 2.3                B-
            > 2.0                C+
            > 1.7                C
            > 1.3                C-
            > 1.0                D+ 
            > 0.7                D 
            > 0.0                D-
              0.0                E
    """
    letter_grade_table = {
        4.0: 'A+',
        (3.7, 4.0): 'A',
        (3.3, 3.7): 'A-',
        (3.0, 3.3): 'B+',
        (2.7, 3.0): 'B',
        (2.3, 2.7): 'B-',
        (2.0, 2.3): 'C+',
        (1.7, 2.0): 'C',
        (1.3, 1.7): 'C-',
        (1.0, 1.3): 'D+',
        (0.7, 1.0): 'D',
        (0.0, 0.7): 'D-',
        0.0: 'E'
    }

    return [letter_grade_table[grade] if grade in letter_grade_table else 'Invalid GPA' for grade in grades]
