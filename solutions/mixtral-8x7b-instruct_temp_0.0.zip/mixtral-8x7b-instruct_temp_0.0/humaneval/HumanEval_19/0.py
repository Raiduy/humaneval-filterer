from typing import List


def sort_numbers(numbers: str) -> str:
    """
    Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest

    >>> sort_numbers('three one five')
    'one three five'
    """
    # Split the input string into a list of numberals
    numberals = numbers.split()

    # Create a mapping from numberals to their corresponding integer values
    numberal_to_int = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9,
    }

    # Sort the list of numberals using the mapping to convert them to integers
    sorted_numberals = sorted(numberals, key=lambda x: numberal_to_int[x])

    # Join the sorted list of numberals back into a string
    sorted_numbers = ' '.join(sorted_numberals)

    # Return the sorted string
    return sorted_numbers
