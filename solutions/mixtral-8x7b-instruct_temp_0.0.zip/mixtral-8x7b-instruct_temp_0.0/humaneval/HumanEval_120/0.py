
def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    :param arr: list[int], an array of integers
    </s>   :param k: int, a positive integer
    :return: list[int], a sorted list of the maximum k numbers in arr
    """
    # Create a min heap of size k
    max_heap = arr[:k]
    heapq.heapify(max_heap)

    # Iterate through the rest of the array
    for num in arr[k:]:
        # If the number is greater than the smallest number in the heap
        if num > max_heap[0]:
            # Remove the smallest number from the heap
            heapq.heappop(max_heap)
            # Add the new number to the heap
            heapq.heappush(max_heap, num)

    # Return the sorted list of maximum k numbers
    return sorted(max_heap)
