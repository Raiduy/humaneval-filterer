

def count_distinct_characters(string: str) -> int:
    """
    Given a string, find out how many distinct characters (regardless of case) does it consist of
    :param string: str
    :return: int
    """
    return len(set(string.lower()))
