
def prod_signs(arr):
    """
    Given an array arr of integers, return sum of magnitudes of integers
    multiplied by product of all signs of each number in the array,
    represented by 1, -1 or 0.
    Return None for empty arr.

    :param arr: list of integers
    :return: int or None
    """
    if not arr:
        return None

    sign_product = 1
    magnitude_sum = 0

    for num in arr:
        sign_product *= num if num else 1
        magnitude_sum += abs(num)

    return magnitude_sum * sign_product
