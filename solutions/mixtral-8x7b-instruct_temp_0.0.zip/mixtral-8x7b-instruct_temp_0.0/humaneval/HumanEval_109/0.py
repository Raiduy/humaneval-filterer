
def move_one_ball(arr):
    """
    Determines if it is possible to get a non-decreasing sorted array by performing
    right shift operations on the given array.

    :param arr: List of integers
    :return: True if possible, False otherwise
    """

    # If the array is empty, return True
    if not arr:
        return True

    # Initialize the maximum element and its index
    max_elem = max(arr)
    max_index = arr.index(max_elem)

    # If the maximum element is the first element, return True
    if max_index == 0:
        return is_sorted(arr[1:]) or is_sorted(arr[:-1])

