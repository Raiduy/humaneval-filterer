
def encode(message):
    """
    Encodes a message by swapping case of all letters and replacing
    vowels with the letter that appears two places ahead in the
    English alphabet.

    Parameters:
    message (str): The message to encode.

    Returns:
    str: The encoded message.
    """

    # Initialize an empty string to store the encoded message
    encoded_message = ''

    # Iterate over each character in the message
    for char in message:
        # Check if the character is an alphabetic letter
        if char.isalpha():
            # Swap the case of the letter
            char = char.swapcase()

            # Get the index of the letter in the alphabet
            index = ord(char) - ord('a')

            # Check if the letter is a vowel
            if char in 'aeiou':
                # Replace the vowel with the letter that appears
                # two places ahead in the alphabet
                char = chr(index + 2 + ord('a'))

        # Add the encoded character to the encoded message
        encoded_message += char

    # Return the encoded message
    return encoded_message
