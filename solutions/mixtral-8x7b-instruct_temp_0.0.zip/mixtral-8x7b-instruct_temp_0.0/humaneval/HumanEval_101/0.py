
def words_string(s):
    """
    Given a string of words separated by commas or spaces, split the string into
    words and return a list of the words.
    
    Examples:
    words_string("Hi, my name is John") ➞ ["Hi", "my", "name", "is", "John"]
    words_string("One,two,three,four,five,six") ➞ ["One", "two", "three", "four", "five", "six"]
    """
    return s.strip().split(',\s*')
