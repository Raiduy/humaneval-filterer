
def bf(planet1, planet2):
    '''
    Given two planet names as strings planet1 and planet2,
    return a tuple containing all planets whose orbits are
    located between the orbit of planet1 and the orbit of planet2,
    sorted by proximity to the sun.
    Return an empty tuple if planet1 or planet2 are not correct planet names.
    '''
    # Check if both planets are in the list of planets
    if planet1 not in PLANETS_ORDER or planet2 not in PLANETS_ORDER:
        return ()

    # Find the indices of the planets
    index1 = PLANETS_ORDER.index(planet1)
    index2 = PLANETS_ORDER.index(planet2)

    # Calculate the start and end indices
    start_index = max(index1, index2)
    end_index = min(index1, index2) + 1

    # Create the result list with the planets between the two planets
    result = PLANETS_ORDER[start_index:end_index]

    return tuple(result)
