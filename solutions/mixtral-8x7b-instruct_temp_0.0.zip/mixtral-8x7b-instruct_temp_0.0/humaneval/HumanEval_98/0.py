
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    :param s: str, the input string
    :return: int, the number of uppercase vowels in even indices
    
    Examples:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    vowels = 'AEIOU'
    count = 0
    for i in range(len(s)):
        if i % 2 == 0 and s[i] in vowels and s[i].isupper():
            count += 1
    return count
