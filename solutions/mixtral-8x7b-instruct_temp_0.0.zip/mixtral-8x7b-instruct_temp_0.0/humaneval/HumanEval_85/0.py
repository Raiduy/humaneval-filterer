
def add(lst):
    """
    Given a non-empty list of integers lst, add the even elements that are at odd indices.

    Args:
        lst (list): A non-empty list of integers.

    Returns:
        int: The sum of the even elements at odd indices.

    Examples:
        add([4, 2, 6, 7])  -> 2
        add([-1, 3, 8, 9, 12]) -> 12
        add([1, 5, 6, 7, 8])  -> 0
    """
    return sum(x for i, x in enumerate(lst) if i % 2 == 1 and x % 2 == 0)
