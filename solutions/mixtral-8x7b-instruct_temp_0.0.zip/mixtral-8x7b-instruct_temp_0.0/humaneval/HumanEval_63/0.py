

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.

    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    # Initialize the memoization dictionary
    fibfib_memo = {0: 0, 1: 0, 2: 1}

    # Define a recursive function to compute the n-th FibFib number
    def fibfib_recursive(n):
        # If the n-th FibFib number is already computed, return it
        if n in fibfib_memo:
            return fibfib_memo[n]

        # Compute the n-th FibFib number using the previous three numbers
        fibfib_n = fibfib_recursive(n - 1) + fibfib_recursive(n - 2) + fibfib_recursive(n - 3)

        # Memoize the computed value
        fibfib_memo[n] = fibfib_n

        # Return the computed value
        return fibfib_n

    # Compute and return the n-th FibFib number
    return fibfib_recursive(n)
