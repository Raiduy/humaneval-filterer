

def fib4(n: int):
