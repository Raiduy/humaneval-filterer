
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty or the number of keys is less than 3.
    """
    if not dict or len(dict) < 3:
        return False
    case = None
    for k in dict:
        if not isinstance(k, str):
            return False
        if case is None:
            case = k.casefold()
        elif case != k.casefold():
            return False
    return True