
from typing import List


def below_one(operations: List[int]) -> bool:
    """
    Determines if the balance of a bank account falls below one at any point during a series
    of deposit and withdrawal operations, starting with a balance of one.

    Parameters:
    operations (List[int]): A list of integers representing deposit (positive) and
                            withdrawal (negative) operations.

    Returns:
    bool: True if the balance falls below one at any point, False otherwise.

    Examples:
    >>> below_one([1, 2, 3])
    False
    >>> below_one([1, 2, -4, 5])
    True
    """
    balance = 1
    for operation in operations:
        balance += operation
        if balance < 1:
            return True
    return False