

def correct_bracketing(brackets: str):
    """
    Check if every opening bracket has a corresponding closing bracket.

    :param brackets: A string of "[" and "]".
    :return: True if the brackets are correct, False otherwise.
    >>> correct_bracketing("[")
    False
    >>> correct_bracketing("[]")
    True
    >>> correct_bracketing("[[][]]")
    True
    >>> correct_bracketing("][][")
    False
    """
    count = 0
    for bracket in brackets:
        if bracket == '[':
            count += 1
        elif bracket == ']':
            count -= 1
            if count < 0:
                return False
    return count == 0