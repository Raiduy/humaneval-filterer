
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """
    From a list of integers, remove all elements that occur more than once.
    Return the list in the reverse order of the input.

    Args:
    numbers (List[int]): List of integers.

    Returns:
    List[int]: List of integers with no duplicates, in reverse order.

    Examples:
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [4, 3, 1]
    """
    unique_numbers = []
    for number in numbers:
        if number not in unique_numbers:
            unique_numbers.append(number)
    return unique_numbers[::-1]