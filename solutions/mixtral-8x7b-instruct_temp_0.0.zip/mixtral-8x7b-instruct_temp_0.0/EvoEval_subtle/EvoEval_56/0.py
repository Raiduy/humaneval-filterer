
def correct_bracketing(brackets: str):
    """
    Determines if every opening bracket has a corresponding closing bracket.

    :param brackets: A string of "(" and ")".
    :return: True if the brackets are correctly bracketed, False otherwise.
    """
    stack = []
    for bracket in brackets:
        if bracket == '(':
            stack.append(bracket)
        elif bracket == ')':
            if not stack or stack.pop() != '(':
                return False
    return not stack