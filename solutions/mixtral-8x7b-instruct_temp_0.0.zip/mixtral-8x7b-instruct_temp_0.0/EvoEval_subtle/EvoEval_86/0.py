
def anti_shuffle(s):
    """
    Function to return an ordered version of a string where all words are
    replaced by a new word with characters arranged in descending order
    based on ascii value.
    """
    return ' '.join((''.join(sorted(word, reverse=True)) for word in s.split()))