
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters </s>
    shift up by two multiplied to two places.
    For example:
    encrypt('lm') returns 'hi'
    encrypt('ewhjklnop') returns 'asdfghjkl'
    encrypt('kj') returns 'gf'
    encrypt('ix') returns 'et'
    """
    encrypted_text = ''
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    for char in s:
        if char.islower():
            index = (alphabet.index(char) + 2 * 2) % 26
            encrypted_text += alphabet[index]
        else:
            encrypted_text += char
    return encrypted_text