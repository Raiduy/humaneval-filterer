
def total_match(lst1, lst2):
    """
    This function accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list greater than the other list.

    if the two lists have the same number of chars, return the second list.

    Parameters:
    lst1 (list): The first list of strings.
    lst2 (list): The second list of strings.

    Returns:
    list: The list with the total number of chars greater than the other list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'hi', 'admin', 'project']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hi', 'admin']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['1', '2', '3', '4', '5']
    """
    total_chars1 = sum((len(s) for s in lst1))
    total_chars2 = sum((len(s) for s in lst2))
    if total_chars1 > total_chars2:
        return lst1
    elif total_chars1 < total_chars2:
        return lst2
    else:
        return lst2