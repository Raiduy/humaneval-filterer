from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """
    Separates parentheses groups in a given string into a list of separate strings.
    Ignores spaces and returns the list in ascending alphabetical order.

    Parameters:
    paren_string (str): String containing multiple groups of nested parentheses.

    Returns:
    List[str]: List of separated parentheses groups.

    Examples:
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['(()())', '(())', '()']
    """
    paren_string = paren_string.replace(' ', '')
    groups = []
    group = ''
    for char in paren_string:
        if char == '(':
            group += char
        elif char == ')':
            if not group or group[-1] != '(':
                return []
            else:
                groups.append(group)
                group = ''
    if group:
        groups.append(group)
    return sorted(groups)