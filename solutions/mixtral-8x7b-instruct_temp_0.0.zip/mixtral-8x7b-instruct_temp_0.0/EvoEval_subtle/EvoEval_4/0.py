
from typing import List


def median_absolute_deviation(numbers: List[float]) -> float:
    """
    For a given list of input numbers, calculate Median Absolute Deviation
    around the median of this dataset.
    Median Absolute Deviation is the median absolute difference between each
    element and a centerpoint (median in this case):
    MAD = median |x - x_median|
    """
    numbers_median = sorted(numbers)[len(numbers) // 2]
    abs_diffs = [abs(num - numbers_median) for num in numbers]
    abs_diffs_median = sorted(abs_diffs)[len(abs_diffs) // 2]
    return abs_diffs_median