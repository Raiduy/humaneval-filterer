
def count_up_to(n):
    """Return a list of prime numbers less than or equal to n in descending order."""

    def is_prime(num):
        """Return True if num is a prime number, False otherwise."""
        if num < 2:
            return False