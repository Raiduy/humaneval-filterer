

def monotonic(l: list):
    """Return True if list elements are monotonically increasing or decreasing. If the list is empty, return False.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    >>> monotonic([])
    False
    """
    if not l:
        return False
    direction = None
    for i in range(1, len(l)):
        if (l[i] > l[i - 1]) == (direction is not None and direction == 'increasing'):
            return False
        direction = 'increasing' if l[i] > l[i - 1] else 'decreasing'
    return True