def fruit_distribution(s, n):
    """
    Function to find the number of mango fruits in the basket
    :param s: string representing the number of apples and oranges in the basket
    :param n: integer representing the total number of fruits in the basket minus one
    :return: integer representing the number of mango fruits in the basket
    """
    (apples, oranges) = map(int, s.strip(' apples, oranges').split(', '))
    mangoes = n - apples - oranges + 1
    return mangoes