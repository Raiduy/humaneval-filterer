

def triangle_perimeter(a, b, c):
    """Given length of three sides return perimeter for a triangle.

    Parameters:
    a, b, c (int or float): Lengths of the sides of the triangle

    Returns:
    int or float: Perimeter of the triangle

    Example:
    >>> triangle_perimeter(5, 3, 3)
    11
    """
    return a + b + c