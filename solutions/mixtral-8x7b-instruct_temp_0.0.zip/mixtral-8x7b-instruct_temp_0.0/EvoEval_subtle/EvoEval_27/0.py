
def flip_case(string: str, exclusive_case: str='lower') -> str:
    """
    For a given string, flip lowercase characters to uppercase and uppercase to lowercase,
    unless they are in exclusive_case which can be either 'lower' or 'upper'.
    If exclusive_case is 'lower', lowercase letters will remain as they are.
    If exclusive_case is 'upper', uppercase letters will remain as they are.

    Parameters:
    string (str): The string to flip the case of.
    exclusive_case (str): The case to exclude from flipping. Default is 'lower'.

    Returns:
    str: The string with the case flipped, excluding the specified case.

    Examples:
    >>> flip_case('Hello', 'lower')
    'hello'
    """
    if exclusive_case not in ('lower', 'upper'):
        raise ValueError("exclusive_case must be either 'lower' or 'upper'")
    result = []
    for char in string:
        if char.islower() and exclusive_case == 'lower':
            result.append(char)
        elif char.isupper() and exclusive_case == 'upper':
            result.append(char)
        else:
            result.append(char.swapcase())
    return ''.join(result)