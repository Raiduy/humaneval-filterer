
def car_race_collision(n: int):
    """
    Determines the number of collisions between two sets of cars driving in
    opposite directions on a straight, infinitely long line.

    Parameters:
    n (int): The number of cars driving from left to right.

    Returns:
    int: The number of collisions between the two sets of cars.
    """
    cars_right_to_left = 2 * n
    total_collisions = 0
    for car in range(n, 0, -1):
        for other_car in range(cars_right_to_left, 0, -1):
            if car == other_car:
                total_collisions += 1
            cars_right_to_left -= 1
    return total_collisions