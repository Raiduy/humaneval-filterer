

def is_palindrome(text: str, case_sensitive: bool=True) -> bool:
    """
    Checks if given string is a palindrome considering case sensitivity according to the provided parameter
    :param text: The string to check for palindrome
    :param case_sensitive: Whether to consider case sensitivity when checking for palindrome
    :return: True if the string is a palindrome, False otherwise
    >>> is_palindrome('', True)
    True
    >>> is_palindrome('aba', True)
    True
    >>> is_palindrome('Aba', False)
    True
    >>> is_palindrome('aaaaa', True)
    True
    >>> is_palindrome('zbcd', True)
    False
    """
    if not text:
        return True
    if not case_sensitive:
        text = text.lower()
    (left, right) = (0, len(text) - 1)
    while left < right:
        if text[left] != text[right]:
            return False
        left += 1
        right -= 1
    return True