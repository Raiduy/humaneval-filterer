
def multiply(a, b):
    """
    Complete the function that takes two integers and returns 
    the sum of the unit digits of the product.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 10.
    multiply(19, 28) should return 17.
    multiply(2020, 1851) should return 1.
    multiply(14,-15) should return 9.
    """
    product = a * b
    unit_a = a % 10
    unit_b = b % 10
    unit_product = product % 10
    sum_unit_digits = unit_a + unit_b + unit_product
    return sum_unit_digits