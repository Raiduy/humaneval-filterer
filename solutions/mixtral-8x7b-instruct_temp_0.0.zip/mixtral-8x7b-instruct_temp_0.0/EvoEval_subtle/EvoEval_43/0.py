
def pairs_sum_to_one(l):
    """
    pairs_sum_to_one takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to one, and False otherwise.
    """
    return any((i + j == 1 and i != j for i in l for j in l))