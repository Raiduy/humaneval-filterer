
def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime. If the number is even, return None.

    :param n: int - the position of the prime Fibonacci number to return
    :return: int or None - the n-th prime Fibonacci number, or None if n is even
    :examples:

    >>> prime_fib(1)
    None
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    (a, b) = (0, 1)
    while n > 0:
        (a, b) = (b, a + b)
        if a % 2 == 1 and all((a % p for p in range(3, int(a ** 0.5) + 1, 2))):
            n -= 1
    if n % 2 == 0:
        return None
    else:
        return a