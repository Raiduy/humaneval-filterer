
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start with 1 or end with 2.
    """
    start_with_one = int(10 ** (n - 1))
    end_with_two = 9 * int(10 ** (n - 2))
    if n == 1:
        end_with_two -= 1
    return start_with_one + end_with_two