
from typing import List, Tuple


def rolling_min(numbers: List[int]) -> List[int]:
    """
    From a given list of integers, generate a list of rolling minimum element found until given moment
    in the sequence.

    Args:
    numbers (List[int]): List of integers

    Returns:
    List[int]: List of rolling minimums

    Examples:
    >>> rolling_min([1, 2, 3, 2, 3, 4, 2])
    [1, 1, 1, 1, 1, 1, 1]
    """
    rolling_min = [numbers[0]]
    for num in numbers[1:]:
        rolling_min.append(min(rolling_min[-1], num))
    return rolling_min