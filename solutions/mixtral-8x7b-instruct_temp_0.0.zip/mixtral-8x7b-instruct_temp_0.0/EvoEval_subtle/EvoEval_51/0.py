
def remove_consonants(text):
    """
    remove_consonants is a function that takes a string as input and returns a new string with all the consonants removed.
    :param text: str, the input string
    :return: str, the output string with consonants removed
    >>> remove_consonants('')
    ''
    >>> remove_consonants("abcdef
ghijklm")
    'ae
i'
    >>> remove_consonants('abcdef')
    'ae'
    >>> remove_consonants('aaaaa')
    'aaaaa'
    >>> remove_consonants('aaBAA')
    'aaAA'
    >>> remove_consonants('zbcd')
    ''
    """
    return ''.join((c for c in text if c.lower() not in 'bcdfghjklmnpqrstvwxyz'))