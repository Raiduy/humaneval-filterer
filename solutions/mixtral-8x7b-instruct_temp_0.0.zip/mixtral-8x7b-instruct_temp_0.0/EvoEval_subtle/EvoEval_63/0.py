
def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-3) + fibfib(n-2) - fibfib(n-1).
    This function computes the n-th element of the fibfib number sequence.

    >>> fibfib(1)
    0
    >>> fibfib(5)
    -2
    >>> fibfib(8)
    4
    """
    fibfib_dict = {0: 0, 1: 0, 2: 1}

    def fibfib_memo(n):
        if n not in fibfib_dict:
            fibfib_dict[n] = fibfib_memo(n - 3) + fibfib_memo(n - 2) - fibfib_memo(n - 1)
        return fibfib_dict[n]
    return fibfib_memo(n)