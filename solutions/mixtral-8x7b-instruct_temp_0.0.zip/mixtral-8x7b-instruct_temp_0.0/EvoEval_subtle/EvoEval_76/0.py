
def is_simple_power(x, n):
    """
    Determines if a number x is a simple power of n and returns the smallest power that makes x a simple power of n.
    :param x: int or float, the number to check
    :param n: int, the base number
    :return: tuple, (bool, int) where bool is True if x is a simple power of n, and int is the smallest power that makes x a simple power of n.
             If x is not a simple power of n, the int value is None.
    """
    if n <= 0:
        raise ValueError('n must be a positive integer')
    power = 0
    while x % n == 0:
        x = x / n
        power += 1
    if x == 1:
        return (True, power)
    else:
        return (False, None)