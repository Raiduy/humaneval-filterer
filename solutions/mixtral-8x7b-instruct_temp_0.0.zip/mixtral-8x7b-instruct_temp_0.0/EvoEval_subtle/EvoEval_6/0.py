
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses. Additionally, return the list in descending order.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.
    """

    def find_deepest_nesting(paren_sub, level=0):
        if not paren_sub:
            return level
        if paren_sub[0] == '(':
            return find_deepest_nesting(paren_sub[1:], level + 1)
        return find_deepest_nesting(paren_sub[1:], level - 1)
    result = [find_deepest_nesting(paren_group) for paren_group in paren_string.split()]
    return sorted(result, reverse=True)