
def decimal_to_binary(decimal):
    """Converts a decimal number to binary format with extra characters 'db' at the beginning and 'bd' at the end.

    Args:
    decimal (int): The decimal number to be converted to binary.

    Returns:
    str: The binary representation of the given decimal number, prepended with 'db' and appended with 'bd'.

    Examples:
    decimal_to_binary(15)   # returns "db1111bd"
    decimal_to_binary(32)   # returns "db100000bd"
    """
    return 'db' + bin(decimal)[2:] + 'bd'