
def string_sequence(n: int) -> str:
    """
    Return a string containing space-delimited numbers starting from 1 up to n inclusive.

    Parameters:
    n (int): An integer representing the upper limit of the sequence.

    Returns:
    str: A string of space-delimited numbers from 1 to n.

    Examples:
    >>> string_sequence(1)
    '1'
    >>> string_sequence(5)
    '1 2 3 4 5'
    """
    return ' '.join(map(str, range(1, n + 1)))