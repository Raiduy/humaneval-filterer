
def is_bored(S):
    """
    Given a string of words, count the number of boredoms.
    A boredom is a sentence that starts with the word "I" and ends with the word "boredom".
    Sentences are delimited by '.', '?' or '!'.

    Parameters:
    S (str): A string of words.

    Returns:
    int: The number of boredoms in the string.

    Examples:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I am experiencing boredom")
    1
    """
    boredoms = 0
    sentences = S.split('.') + S.split('?') + S.split('!')
    for sentence in sentences:
        sentence = sentence.strip()
        if sentence and sentence[0] == 'I' and sentence.endswith('boredom'):
            boredoms += 1
    return boredoms