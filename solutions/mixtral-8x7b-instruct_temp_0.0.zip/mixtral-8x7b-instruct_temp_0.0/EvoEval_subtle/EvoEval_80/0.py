
def is_happy(s):
    """
    Check if a string is happy or not. A string is considered happy if its length is
    at least 4 and every 4 consecutive letters are distinct.

    :param s: str - the string to check
    :return: bool - True if the string is happy, False otherwise
    """
    if len(s) < 4:
        return False
    i = 0
    j = 3
    while j < len(s):
        if s[i:j + 1] == s[j:j + 4]:
            return False
        i += 1
        j += 1
    return True