
def add(lst):
    """
    Given a non-empty list of integers lst, add the odd elements that are at even indices.

    Args:
        lst (list): A non-empty list of integers.

    Returns:
        int: The sum of the odd elements at even indices. If there are no odd elements at even indices, return 0.

    Examples:
        add([4, 2, 5, 7]) ==> 5
        add([1, 2, 3, 4, 5]) ==> 9
        add([-1, -2, -3, -4, -5]) ==> -9
    """
    return sum((x for (i, x) in enumerate(lst) if i % 2 == 0 and x % 2 != 0))