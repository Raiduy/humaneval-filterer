
def prime_length(string):
    """
    Function to check if the length of a string (ignoring white spaces) is a prime number.

    Parameters:
    string (str): The string to check for prime length.

    Returns:
    bool: True if the string length is a prime number, False otherwise.
    """
    string_length = len(string.strip())
    if string_length < 2:
        return False
    for i in range(2, int(string_length ** 0.5) + 1):
        if string_length % i == 0:
            return False
    return True