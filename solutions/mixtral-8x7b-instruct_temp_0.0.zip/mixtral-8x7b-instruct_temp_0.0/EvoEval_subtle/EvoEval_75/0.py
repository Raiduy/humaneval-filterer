
def is_multiply_prime(a):
    """
    Write a function that returns true if the given number is the multiplication of 4 prime numbers
    and false otherwise.
    Knowing that (a) is less than 100.

    Example:
    is_multiply_prime(90) == True
    90 = 2 * 3 * 3 * 5
    """

    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True
    if a < 2 or a % 2 != 0:
        return False
    prime_factors = []
    for i in range(2, 100):
        if a % i == 0 and is_prime(i):
            prime_factors.append(i)
            a //= i
    return len(prime_factors) == 4