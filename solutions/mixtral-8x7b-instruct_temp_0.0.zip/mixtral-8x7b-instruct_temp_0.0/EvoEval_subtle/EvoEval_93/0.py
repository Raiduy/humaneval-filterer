

def encode(message):
    """
    Encodes a message by swapping case of all letters and replacing
    vowels with the letter that appears 3 places ahead in the
    English alphabet.

    Parameters:
    message (str): The message to encode.

    Returns:
    str: The encoded message.
    """
    result = ''
    vowels = 'aeiouAEIOU'
    alphabet_offset = 3