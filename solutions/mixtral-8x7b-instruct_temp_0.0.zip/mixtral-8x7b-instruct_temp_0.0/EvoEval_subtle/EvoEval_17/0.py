
from typing import List


def parse_music(music_string: str) -> List[int]:
    """
    Function to parse a string representing musical notes in a special ASCII format and return a list of unique
    integers corresponding to how many beats does each note last, sorted in descending order.

    Legend:
    - 'o'   - whole note, lasts four beats
    - 'o|'  - half note, lasts two beats
    - '.|'  - quater note, lasts one beat

    Args:
        music_string (str): String representing musical notes in the special ASCII format.

    Returns:
        List[int]: List of unique integers representing the length of each note in descending order.

    Examples:
        >>> parse_music('o o| .| o| o| .| .| .| .| o o')
        [4, 2, 1]
    """
    note_beats = {'o': 4, 'o|': 2, '.|': 1}
    beats = [note_beats[note] for note in music_string.split()]
    return sorted(list(set(beats)), reverse=True)