
def how_many_times(string: str, substring: str) -> int:
    """
    Find how many times a given substring can be found in the original string. Do not count overlapping cases.

    :param string: The string to search in
    :param substring: The substring to find in the string
    :return: The number of times the substring appears in the string
    """
    if not string or not substring:
        return 0
    start_index = 0
    count = 0
    while True:
        start_index = string.find(substring, start_index)
        if start_index == -1:
            break
        count += 1
        start_index += len(substring)
    return count