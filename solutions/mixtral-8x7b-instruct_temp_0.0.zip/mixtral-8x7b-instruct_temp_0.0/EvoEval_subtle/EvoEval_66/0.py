
def digitSum(s):
    """
    Function to return the sum of the lowercase ASCII values in a string.

    Parameters:
    s (str): The input string.

    Returns:
    int: The sum of the lowercase ASCII values in the input string.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 195
        digitSum("abcCd") => 394
        digitSum("helloE") => 532
        digitSum("woArBld") => 652
        digitSum("aAaaaXa") => 485
    """
    return sum((ord(c) for c in s if c.islower()))