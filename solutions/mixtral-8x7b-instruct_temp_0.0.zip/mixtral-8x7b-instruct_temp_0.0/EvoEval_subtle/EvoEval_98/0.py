
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in odd indices.
    
    :param s: str, the input string
    :return: int, the count of uppercase vowels in odd indices
    
    Examples:
    count_upper('aBCdEf') returns 0
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 1
    """
    vowels = 'AEIOU'
    count = 0
    for i in range(len(s)):
        if i % 2 != 0:
            if s[i].isupper() and s[i] in vowels:
                count += 1
    return count