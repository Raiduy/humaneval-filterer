
def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters and the same length.
    :param s0: The first string to compare
    :param s1: The second string to compare
    :return: True if the strings have the same characters and length, False otherwise
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    False
    >>> same_chars('aaaaaaabcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    False
    >>> same_chars('eabcd', 'ddabc')
    False
    """
    return sorted(s0) == sorted(s1) and len(s0) == len(s1)