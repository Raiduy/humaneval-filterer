FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Return the number of vowels in the given word.
    Vowels are 'a', 'e', 'i', 'o', 'u', and 'y' when it is at the end of the word.
    Only count the lowercase vowels.

    Args:
    s (str): The word to count the vowels of.

    Returns:
    int: The number of vowels in the given word.

    Examples:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("YACED")
    0
    """
    vowels = 'aeiouy'
    count = 0
    for char in s:
        if char in vowels and s.lower().endswith(char) or s.lower().find(char) != len(s) - 1:
            count += 1
    return count